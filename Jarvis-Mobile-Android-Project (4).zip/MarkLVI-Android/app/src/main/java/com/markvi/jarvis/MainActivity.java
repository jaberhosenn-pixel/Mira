package com.markvi.jarvis;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Hosts the Mira HUD (assets/mira.html, the user's own design, unchanged) in a WebView and connects it
 * to the native Gemini Live session and the phone tools through the "Android" JavaScript interface.
 */
public class MainActivity extends Activity implements Bus.Ui {

    private static final String BASE = "https://mira.app/";
    private static final int REQ_FILE = 21;

    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private TextToSpeech tts;
    private boolean ttsReady;
    private ValueCallback<Uri[]> fileCallback;
    private long lastLevelPush;
    private volatile boolean pageReady;
    private boolean askedSetup;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        DebugLog.installCrashHandler(this);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().setStatusBarColor(Color.parseColor("#05080d"));
        getWindow().setNavigationBarColor(Color.parseColor("#05080d"));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#05080d"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#05080d"));
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
            return ins;
        });
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setGeolocationEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String u = req.getUrl().toString();
                if (u.startsWith(BASE)) return false;
                openExternal(u);
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                cb.invoke(origin, true, false);
            }

            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                        openExternal(r.getUrl().toString());
                        v.destroy();
                        return true;
                    }

                    @Override
                    public void onPageStarted(WebView v, String url, Bitmap f) {
                        if (url != null && !url.equals("about:blank")) {
                            openExternal(url);
                            v.stopLoading();
                            v.destroy();
                        }
                    }
                });
                WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
                t.setWebView(tmp);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public boolean onConsoleMessage(android.webkit.ConsoleMessage m) {
                if (m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR) {
                    DebugLog.add("JS error: " + m.message() + " (line " + m.lineNumber() + ")");
                }
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        tts = new TextToSpeech(getApplicationContext(), status -> ttsReady = status == TextToSpeech.SUCCESS);
        loadPage();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void loadPage() {
        String html = readAsset("mira.html");
        // two tiny hooks so the 3D head's mouth follows the real voice level and telemetry uses live data
        html = html.replace(
                "targetMouth = Math.max(0, Math.min(1, (syl + 0.35) * 0.85 * stopClosure));",
                "targetMouth = Math.max(0, Math.min(1, (syl + 0.35) * 0.85 * stopClosure"
                        + " * (window.__nativeLevel != null ? Math.min(1.4, 0.35 + 1.6 * window.__nativeLevel) : 1)));");
        html = html.replace("setInterval(updateHardwareTelemetry, 2000);",
                "setInterval(function () { updateHardwareTelemetry(); }, 2000);");
        String js = readAsset("native_bridge.js");
        int at = html.lastIndexOf("</body>");
        String inject = "<script>" + js + "</script>";
        html = at >= 0 ? html.substring(0, at) + inject + html.substring(at) : html + inject;
        web.loadDataWithBaseURL(BASE, html, "text/html", "UTF-8", null);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Bus.ui = this;
    }

    @Override
    protected void onResume() {
        super.onResume();
        final android.content.Context ac = getApplicationContext();
        new Thread(() -> JarvisAccessibility.ensureEnabled(ac)).start();
        new Thread(() -> Sip.ensure(ac)).start();
        maybeSetup();
        handleAssist();
        FindPhone.stop();
        startInAppWake();
        try {
            native_("state", q(Bus.lastState));
        } catch (Throwable ignored) {
        }
    }

    private boolean autoWake;

    /**
     * While the Mira screen is open, keep the wake word listening and the screen on, so the phone can be put down
     * and "Hey Mira" still starts a conversation. Turned off again when the screen is left.
     */
    private void startInAppWake() {
        try {
            if (!Prefs.sp(this).getBoolean("inapp_wake", true)) {
                DebugLog.add("In-app wake: switched off in settings");
                return;
            }
            if (Prefs.apiKey(this).isEmpty()) {
                DebugLog.add("In-app wake: no API key yet");
                return;
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                DebugLog.add("In-app wake: microphone permission missing");
                return;
            }
            getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            JarvisService js = JarvisService.get();
            if (js != null && (js.isLive() || js.hasSession())) return;
            if (!Prefs.sp(this).getBoolean("wake_enabled", false)) autoWake = true;
            // always (re)ask: starting the listener is harmless when it already runs, and a stale "enabled" flag
            // must never leave the app deaf to "Hey Mira"
            startForegroundService(new Intent(this, JarvisService.class).setAction(JarvisService.ACTION_WAKE_ON));
            DebugLog.add("In-app wake: listening for Hey Mira / Hey Jarvis");
        } catch (Throwable t) {
            DebugLog.add("In-app wake word failed: " + t);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    /** Opened by the assistant gesture or the home widget: start listening right away. */
    private void handleAssist() {
        try {
            Intent it = getIntent();
            if (it == null || !it.getBooleanExtra("assist", false)) return;
            it.removeExtra("assist");
            if (Prefs.apiKey(this).isEmpty()
                    || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
            if (JarvisService.get() != null && JarvisService.get().isLive()) return;
            startForegroundService(new Intent(this, JarvisService.class).setAction(JarvisService.ACTION_START));
        } catch (Throwable t) {
            DebugLog.add("Assist start failed: " + t);
        }
    }

    private void maybeSetup() {
        if (askedSetup || !pageReady) return;
        boolean first = !Prefs.sp(this).getBoolean("setup_seen", false);
        if (first || JarvisAccessibility.get() == null) {
            askedSetup = true;
            startActivity(new Intent(this, SetupActivity.class));
        }
    }

    @Override
    protected void onStop() {
        if (Bus.ui == this) Bus.ui = null;
        try {
            getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (autoWake) {
                autoWake = false;
                startService(new Intent(this, JarvisService.class).setAction(JarvisService.ACTION_WAKE_OFF));
            }
        } catch (Throwable t) {
            DebugLog.add("In-app wake word stop failed: " + t);
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        pool.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    private void requestAllPermissions() {
        List<String> need = new ArrayList<>();
        String[] wanted = {
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR,
                Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_SMS,
                Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS,
                Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
        };
        for (String p : wanted) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) need.add(p);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), 11);
    }

    private void openExternal(String url) {
        try {
            Intent i;
            if (url.startsWith("intent:")) i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
            else i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            i.setSelector(null);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not open the link", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------ JS helpers

    private void js(final String code) {
        ui.post(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    private static String q(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    private void native_(String method, String args) {
        js("window.__miraNative&&window.__miraNative." + method + "(" + args + ")");
    }

    private void done(String id, String payload) {
        js("window.__nativeDone&&window.__nativeDone(" + q(id) + "," + q(payload) + ")");
    }

    // ------------------------------------------------------------------ Bus.Ui (events from the live session)

    @Override
    public void onState(String state) {
        native_("state", q(state));
    }

    @Override
    public void onUserText(String text, boolean finished) {
        native_("user", q(text) + "," + finished);
    }

    @Override
    public void onAssistantText(String text, boolean finished) {
        native_("asst", q(text) + "," + finished);
    }

    @Override
    public void onLevels(float micLevel, float speakerLevel) {
        long now = System.currentTimeMillis();
        if (now - lastLevelPush < 60) return;
        lastLevelPush = now;
        native_("level", micLevel + "," + speakerLevel);
    }

    @Override
    public void onLog(String line) {
        if (line != null && line.startsWith("HEARD: ")) {
            native_("heard", q(line.substring(7)));
            return;
        }
        if (line != null && (line.startsWith("Wake word") || line.startsWith("Could not start listening"))) {
            native_("error", q(line));
            return;
        }
        if (line != null && (line.startsWith("Rejected") || line.startsWith("Session ended")
                || line.contains("permission") || line.startsWith("Microphone"))) {
            native_("error", q(line));
        }
    }

    @Override
    public void onImage(Bitmap bmp, String label) {
        // the HUD has its own camera/screen overlay; nothing to draw natively
    }

    @Override
    public void onMemory(String cat, String key, String value) {
        native_("memory", q(cat) + "," + q(key) + "," + q(value));
    }

    @Override
    public boolean confirm(final String message) {
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] answer = new boolean[1];
        final AlertDialog[] dlg = new AlertDialog[1];
        ui.post(() -> {
            try {
                dlg[0] = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("CONFIRMATION GATE")
                        .setMessage(message)
                        .setCancelable(false)
                        .setPositiveButton("Approve & Run", (d, w) -> {
                            answer[0] = true;
                            latch.countDown();
                        })
                        .setNegativeButton("Deny", (d, w) -> latch.countDown())
                        .show();
            } catch (Exception e) {
                latch.countDown();
            }
        });
        try {
            if (!latch.await(45, TimeUnit.SECONDS)) {
                ui.post(() -> {
                    if (dlg[0] != null && dlg[0].isShowing()) dlg[0].dismiss();
                });
                return false;
            }
        } catch (InterruptedException e) {
            return false;
        }
        return answer[0];
    }

    // ------------------------------------------------------------------ the "Android" object in JavaScript

    private final class Bridge {

        @JavascriptInterface
        public boolean isNative() {
            return true;
        }

        @JavascriptInterface
        public void pageReady() {
            pageReady = true;
            ui.post(MainActivity.this::maybeSetup);
        }

        @JavascriptInterface
        public String getApiKey() {
            return Prefs.apiKey(MainActivity.this);
        }

        @JavascriptInterface
        public void syncSettings(String key, String assistant, String user) {
            if (key != null && !key.trim().isEmpty()) Prefs.setApiKey(MainActivity.this, key);
            android.content.SharedPreferences.Editor e = Prefs.sp(MainActivity.this).edit();
            if (assistant != null && !assistant.trim().isEmpty()) e.putString("assistant_name", assistant.trim());
            if (user != null && !user.trim().isEmpty()) {
                e.putString("user_name", user.trim());
                Memory.save(MainActivity.this, "identity", "owner_name", user.trim());
            }
            e.apply();
        }

        @JavascriptInterface
        public boolean isSerious() {
            return SeriousMode.active(MainActivity.this);
        }

        @JavascriptInterface
        public boolean setSerious(boolean on) {
            if (on && !SeriousMode.providerReady(MainActivity.this)) return false;
            SeriousMode.set(MainActivity.this, on);
            return true;
        }

        @JavascriptInterface
        public String seriousHistory() {
            return SeriousMode.history(MainActivity.this).toString();
        }

        @JavascriptInterface
        public String getSip() {
            JSONObject o = Sip.config(MainActivity.this);
            J.put(o, "status", Sip.status);
            return o.toString();
        }

        @JavascriptInterface
        public void setSip(boolean on, String server, int port, String user, String auth, String pass) {
            Sip.save(MainActivity.this, on, server, port, user, auth, pass);
        }

        @JavascriptInterface
        public String sipStatus() {
            return Sip.status;
        }

        @JavascriptInterface
        public String backupExport(String localJson, boolean withKeys) {
            try {
                return Backup.export(MainActivity.this, localJson, withKeys);
            } catch (Exception e) {
                return "ERR:" + e.getMessage();
            }
        }

        @JavascriptInterface
        public String backupRestore() {
            return Backup.restore(MainActivity.this).toString();
        }

        @JavascriptInterface
        public String takeBackupAction() {
            String p = Backup.pending;
            Backup.pending = null;
            return p == null ? "" : p;
        }

        @JavascriptInterface
        public String readSeriousFile(String path) {
            String t = SeriousMode.readText(path);
            return t == null ? "" : t;
        }

        @JavascriptInterface
        public String takePreview() {
            String p = SeriousMode.pendingPreview;
            SeriousMode.pendingPreview = null;
            return p == null ? "" : p;
        }

        @JavascriptInterface
        public void openSeriousFile(String path) {
            try {
                SeriousMode.open(MainActivity.this, path);
            } catch (Exception e) {
                native_("error", q("Could not open: " + e.getMessage()));
            }
        }

        @JavascriptInterface
        public String getProvider() {
            return J.obj("on", Prefs.customOn(MainActivity.this), "base", Prefs.customBase(MainActivity.this),
                    "key", Prefs.customKey(MainActivity.this), "model", Prefs.customModel(MainActivity.this)).toString();
        }

        @JavascriptInterface
        public void setProvider(boolean on, String base, String key, String model) {
            Prefs.sp(MainActivity.this).edit()
                    .putBoolean("custom_on", on)
                    .putString("custom_base", base == null ? "" : base.trim())
                    .putString("custom_key", key == null ? "" : key.trim())
                    .putString("custom_model", model == null ? "" : model.trim())
                    .putBoolean("custom_model_auto", model == null || model.trim().isEmpty()).apply();
            Agent.reset();
            DebugLog.add("AI provider: " + (on ? "custom " + (base == null ? "" : base.trim()) : "Gemini"));
        }

        @JavascriptInterface
        public void listProviderModels(final String id) {
            pool.execute(() -> {
                boolean ok = true;
                String out;
                try {
                    java.util.List<String> ids = CustomAgent.listModels(getApplicationContext());
                    out = J.obj("models", new org.json.JSONArray(ids), "auto", CustomAgent.pickBest(ids)).toString();
                } catch (Exception e) {
                    ok = false;
                    out = String.valueOf(e.getMessage());
                }
                done(id, J.obj("ok", ok, "text", out).toString());
            });
        }

        @JavascriptInterface
        public void testProvider(final String id) {
            pool.execute(() -> {
                boolean ok = true;
                String out;
                try {
                    out = CustomAgent.simple(getApplicationContext(), "Reply with the single word OK.");
                    if (out.isEmpty()) out = "(empty answer)";
                    out = out + "  [model: " + CustomAgent.currentModel(getApplicationContext()) + "]";
                } catch (Exception e) {
                    ok = false;
                    out = String.valueOf(e.getMessage());
                }
                DebugLog.add("Provider test: " + (ok ? "OK -> " : "FAILED -> ") + out);
                done(id, J.obj("ok", ok, "text", out).toString());
            });
        }

        @JavascriptInterface
        public void setVoice(String name) {
            if (name != null && !name.trim().isEmpty()) Prefs.sp(MainActivity.this).edit().putString("voice", name.trim()).apply();
        }

        @JavascriptInterface
        public void cacheLocal(String json) {
            try {
                if (json == null || json.length() > 4000000) return;
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(new java.io.File(getFilesDir(), "local_cache.json"))) {
                    o.write(json.getBytes("UTF-8"));
                }
            } catch (Throwable ignored) {
            }
        }

        @JavascriptInterface
        public void openEarth() {
            ui.post(() -> startActivity(new Intent(MainActivity.this, EarthActivity.class)));
        }

        @JavascriptInterface
        public void setSeriousVoice(String name) {
            if (name != null && !name.trim().isEmpty()) Prefs.sp(MainActivity.this).edit().putString("serious_voice", name.trim()).apply();
        }

        @JavascriptInterface
        public String getSeriousVoice() {
            return Prefs.seriousVoice(MainActivity.this);
        }

        @JavascriptInterface
        public void setLiveModel(String model) {
            Prefs.sp(MainActivity.this).edit().putString("model", model == null ? "" : model.trim()).apply();
        }

        @JavascriptInterface
        public String getLiveModel() {
            return Prefs.model(MainActivity.this);
        }

        @JavascriptInterface
        public boolean isWake() {
            return Prefs.sp(MainActivity.this).getBoolean("wake_enabled", false) && WakeEngine.isRunning();
        }

        @JavascriptInterface
        public void setWake(final boolean on) {
            DebugLog.add("Wake word switch -> " + (on ? "ON" : "OFF"));
            if (!on) {
                Prefs.sp(MainActivity.this).edit().putBoolean("wake_enabled", false).apply();
                ui.post(() -> startService(new Intent(MainActivity.this, JarvisService.class)
                        .setAction(JarvisService.ACTION_WAKE_OFF)));
                native_("info", q("Hey Mira is off"));
                return;
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestAllPermissions();
                native_("error", q("Allow the microphone first, then switch Hey Mira on again"));
                native_("wakeState", "false");
                return;
            }
            pool.execute(() -> {
                try {
                    if (!WakeEngine.hasModel(MainActivity.this)) {
                        native_("info", q("Downloading the wake word model (about 40 MB). Please wait..."));
                        WakeEngine.downloadModel(getApplicationContext());
                    }
                } catch (Exception e) {
                    DebugLog.add("Wake model download FAILED: " + e);
                    native_("info", q("Offline model not downloaded; using the phone's own recognizer for now"));
                }
                ui.post(() -> {
                    DebugLog.add("Wake model ready, starting listener service");
                    startForegroundService(new Intent(MainActivity.this, JarvisService.class)
                            .setAction(JarvisService.ACTION_WAKE_ON));
                    native_("wakeState", "true");
                    native_("info", q("Hey Mira is on. Say \"Hey Mira\" or \"Hey Jarvis\"."));
                });
            });
        }

        @JavascriptInterface
        public void liveStart() {
            VoiceTts.stop();
            ui.post(() -> {
                if (Prefs.apiKey(MainActivity.this).isEmpty()) {
                    native_("error", q("Add your Gemini API key in Settings first"));
                    native_("state", q("IDLE"));
                    return;
                }
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestAllPermissions();
                    native_("error", q("Microphone permission is required"));
                    native_("state", q("IDLE"));
                    return;
                }
                startForegroundService(new Intent(MainActivity.this, JarvisService.class)
                        .setAction(JarvisService.ACTION_START));
            });
        }

        @JavascriptInterface
        public void liveStop() {
            ui.post(() -> startService(new Intent(MainActivity.this, JarvisService.class)
                    .setAction(JarvisService.ACTION_STOP)));
        }

        @JavascriptInterface
        public void liveText(String text) {
            JarvisService s = JarvisService.get();
            if (s != null) s.sendText(text);
        }

        @JavascriptInterface
        public void chat(final String id, final String text) {
            pool.execute(() -> {
                boolean ok = true;
                String out;
                try {
                    out = Agent.chat(getApplicationContext(), text);
                } catch (Exception e) {
                    ok = false;
                    out = String.valueOf(e.getMessage());
                }
                done(id, J.obj("ok", ok, "text", out).toString());
            });
        }

        @JavascriptInterface
        public void ask(final String id, final String prompt) {
            pool.execute(() -> {
                boolean ok = true;
                String out;
                try {
                    out = SeriousMode.active(getApplicationContext()) && SeriousMode.providerReady(getApplicationContext())
                            ? CustomAgent.simple(getApplicationContext(), prompt)
                            : GeminiRest.generate(getApplicationContext(), prompt);
                } catch (Exception e) {
                    ok = false;
                    out = String.valueOf(e.getMessage());
                }
                done(id, J.obj("ok", ok, "text", out).toString());
            });
        }

        @JavascriptInterface
        public void tool(final String id, final String name, final String argsJson) {
            pool.execute(() -> {
                JSONObject r = Tools.dispatch(getApplicationContext(), name, J.parse(argsJson));
                done(id, r.toString());
            });
        }

        @JavascriptInterface
        public void speak(final String text) {
            speakWith(text, Prefs.activeVoice(MainActivity.this));
        }

        @JavascriptInterface
        public void demoVoice(final String voice, final String text) {
            speakWith(text, voice);
        }

        @JavascriptInterface
        public void stopSpeak() {
            VoiceTts.stop();
            ui.post(() -> {
                if (tts != null) tts.stop();
            });
        }

        private void speakWith(final String text, final String voice) {
            VoiceTts.stop();
            pool.execute(() -> {
                boolean played = false;
                try {
                    played = VoiceTts.speak(getApplicationContext(), text, voice);
                } catch (Exception ignored) {
                }
                if (played) {
                    native_("ttsDone", "");
                    return;
                }
                // no key or no network: fall back to the phone's own voice (and say why)
                String why = VoiceTts.lastError;
                native_("error", q("Gemini voice unavailable" + (why == null || why.isEmpty() ? "" : ": " + why)
                        + ". Using the phone's basic voice instead."));
                ui.post(() -> deviceSpeak(text));
            });
        }

        private void deviceSpeak(final String text) {
            if (!ttsReady) {
                native_("ttsDone", "");
                return;
            }
            boolean bangla = text.matches("(?s).*[\\u0980-\\u09FF].*");
            Locale loc = bangla ? new Locale("bn", "BD") : Locale.US;
            if (tts.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) tts.setLanguage(loc);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                }

                @Override
                public void onDone(String utteranceId) {
                    native_("ttsDone", "");
                }

                @Override
                public void onError(String utteranceId) {
                    native_("ttsDone", "");
                }
            });
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mira");
        }

        @JavascriptInterface
        public String status() {
            try {
                JSONObject s = ToolsCore.systemStatus(MainActivity.this);
                long total = s.optLong("ram_total_mb", 1);
                long free = s.optLong("ram_free_mb", 0);
                int cores = Runtime.getRuntime().availableProcessors();
                int cpu = -1;
                try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader("/proc/loadavg"))) {
                    String line = br.readLine();
                    if (line != null) {
                        double load = Double.parseDouble(line.split(" ")[0]);
                        cpu = (int) Math.min(100, Math.round(load / cores * 100));
                    }
                } catch (Exception ignored) {
                }
                Runtime rt = Runtime.getRuntime();
                return J.obj(
                        "bat", s.optInt("battery_percent", 50),
                        "charging", s.optBoolean("charging", false),
                        "ram", total > 0 ? Math.round(100.0 * (total - free) / total) : 0,
                        "ramGb", Math.round(total / 1024.0),
                        "cores", cores,
                        "cpu", cpu,
                        "heapMb", (rt.totalMemory() - rt.freeMemory()) / 1048576L).toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public String notifications() {
            return NotifCatcher.json();
        }

        @JavascriptInterface
        public boolean notificationAccess() {
            return NotifCatcher.hasAccess(MainActivity.this);
        }

        @JavascriptInterface
        public void openNotifAccess() {
            ui.post(() -> startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        }

        @JavascriptInterface
        public void openDebug() {
            ui.post(() -> startActivity(new Intent(MainActivity.this, DebugActivity.class)));
        }

        @JavascriptInterface
        public void openNativeSettings() {
            ui.post(() -> startActivity(new Intent(MainActivity.this, SetupActivity.class)));
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v != null) v.vibrate(VibrationEffect.createOneShot(Math.max(10, ms), VibrationEffect.DEFAULT_AMPLITUDE));
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public String saveNote(String name, String text) {
            try {
                File dir = ToolsFiles.jarvisDir(MainActivity.this);
                File f = new File(dir, new File(name).getName());
                try (FileOutputStream fo = new FileOutputStream(f)) {
                    fo.write(text.getBytes("UTF-8"));
                }
                return f.getAbsolutePath();
            } catch (Exception e) {
                return "failed: " + e.getMessage();
            }
        }

        @JavascriptInterface
        public void importMemories(String json) {
            try {
                org.json.JSONArray a = new org.json.JSONArray(json);
                for (int i = 0; i < a.length() && i < 80; i++) {
                    JSONObject m = a.getJSONObject(i);
                    Memory.save(MainActivity.this, "notes", "mira_" + m.optString("id"),
                            "[" + m.optString("cat") + "] " + m.optString("text"));
                }
            } catch (Exception ignored) {
            }
        }
    }
}
