package com.markvi.jarvis;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Deque;
import java.util.Locale;

/** Small shared helpers: notifications, launching activities, contacts, undo. */
public final class Util {
    private Util() {}

    public static final String CHANNEL = "jarvis_main";
    public static final String CHANNEL_ALERT = "mira_alerts_v2";

    public static void ensureChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        try { nm.deleteNotificationChannel("jarvis_alert"); } catch (Exception ignored) {}
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Mira running", NotificationManager.IMPORTANCE_LOW));
        NotificationChannel a = new NotificationChannel(CHANNEL_ALERT, "Task results, reminders and alerts", NotificationManager.IMPORTANCE_HIGH);
        a.enableVibration(true);
        a.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        a.setShowBadge(true);
        nm.createNotificationChannel(a);
    }

    public static void notifyAlert(Context c, int id, String title, String text) {
        notifyAlertResult(c, id, title, text);
    }

    /** Posts a notification and returns "ok" or the exact reason it could not be shown. Always logged on failure. */
    public static String notifyAlertResult(Context c, int id, String title, String text) {
        String why = null;
        try {
            ensureChannels(c);
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (Build.VERSION.SDK_INT >= 33
                    && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                why = "Notification permission is not granted (Settings > Apps > Mira > Notifications).";
            } else if (nm == null || !nm.areNotificationsEnabled()) {
                why = "Notifications for Mira are switched OFF in Android settings.";
            } else if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel ch = nm.getNotificationChannel(CHANNEL_ALERT);
                if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) {
                    why = "The 'Task results, reminders and alerts' channel is switched OFF in Android settings.";
                }
            }
            if (why == null) {
                Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                android.app.PendingIntent pi = android.app.PendingIntent.getActivity(c, id, open,
                        android.app.PendingIntent.FLAG_UPDATE_CURRENT | android.app.PendingIntent.FLAG_IMMUTABLE);
                Notification.Builder b = Build.VERSION.SDK_INT >= 26
                        ? new Notification.Builder(c, CHANNEL_ALERT) : new Notification.Builder(c);
                b.setSmallIcon(c.getApplicationInfo().icon != 0 ? c.getApplicationInfo().icon : android.R.drawable.ic_dialog_info)
                        .setContentTitle(title)
                        .setContentText(text)
                        .setStyle(new Notification.BigTextStyle().bigText(text))
                        .setContentIntent(pi)
                        .setCategory(Notification.CATEGORY_MESSAGE)
                        .setVisibility(Notification.VISIBILITY_PUBLIC)
                        .setWhen(System.currentTimeMillis())
                        .setAutoCancel(true);
                if (Build.VERSION.SDK_INT < 26) {
                    b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
                }
                nm.notify(id, b.build());
                DebugLog.add("Notification shown: " + title);
                return "ok";
            }
        } catch (Throwable t) {
            why = "Notification failed: " + t;
        }
        DebugLog.add("NOTIFICATION NOT SHOWN: " + why);
        return why;
    }

    /** Human-readable notification health report with the exact fix for each problem. */
    public static String notifDiagnose(Context c) {
        StringBuilder sb = new StringBuilder();
        try {
            ensureChannels(c);
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            boolean perm = Build.VERSION.SDK_INT < 33
                    || c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED;
            sb.append("Permission: ").append(perm ? "OK" : "MISSING -> allow Notifications for Mira").append('\n');
            boolean on = nm != null && nm.areNotificationsEnabled();
            sb.append("App notifications: ").append(on ? "ON" : "OFF -> turn on in Settings > Apps > Mira > Notifications").append('\n');
            if (Build.VERSION.SDK_INT >= 26 && nm != null) {
                NotificationChannel ch = nm.getNotificationChannel(CHANNEL_ALERT);
                int imp = ch == null ? -1 : ch.getImportance();
                sb.append("Alert channel: ").append(ch == null ? "missing" : imp == 0 ? "OFF -> turn on" : imp >= 4 ? "OK (pop-up)" : "ON but quiet (importance " + imp + ") -> set to Urgent/High").append('\n');
            }
            if (nm != null) {
                int f = nm.getCurrentInterruptionFilter();
                sb.append("Do Not Disturb: ").append(f == NotificationManager.INTERRUPTION_FILTER_ALL || f == 0 ? "off" : "ON (sound/pop-ups may be hidden)").append('\n');
            }
            android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
            boolean ign = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
            sb.append("Battery: ").append(ign ? "unrestricted OK" : "optimized -> Android may kill Mira in background; set Battery to Unrestricted").append('\n');
            if (Build.VERSION.SDK_INT >= 31) {
                android.app.AlarmManager am = (android.app.AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
                sb.append("Exact alarms (reminders): ").append(am != null && am.canScheduleExactAlarms() ? "OK" : "NOT allowed -> reminders may be late").append('\n');
            }
        } catch (Throwable t) {
            sb.append("Diagnose error: ").append(t);
        }
        return sb.toString().trim();
    }

    /** Opens the system page where notifications for Mira can be switched on. */
    public static void openNotifSettings(Context c) {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, c.getPackageName())
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            DebugLog.add("Could not open notification settings: " + e);
        }
    }

    /** Starts an activity from anywhere (service, receiver). */
    public static void launch(Context c, Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }

    // ------------------------------------------------------------------ contacts

    /** Finds contacts whose name contains the query. Returns [{name, number}]. */
    public static JSONArray findContacts(Context c, String query) {
        JSONArray out = new JSONArray();
        if (query == null || query.trim().isEmpty()) return out;
        ContentResolver cr = c.getContentResolver();
        String q = query.trim();
        try (Cursor cur = cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER},
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                new String[]{"%" + q + "%"}, null)) {
            if (cur != null) {
                while (cur.moveToNext() && out.length() < 8) {
                    out.put(J.obj("name", cur.getString(0), "number", cur.getString(1)));
                }
            }
        }
        return out;
    }

    public static boolean looksLikeNumber(String s) {
        if (s == null) return false;
        String t = s.replaceAll("[\\s\\-()]", "");
        return t.matches("\\+?\\d{5,}");
    }

    // ------------------------------------------------------------------ fuzzy names (Bangla / English, spelling differences)

    private static final String[][] BN = {
            {"অ", "a"}, {"আ", "a"}, {"ই", "i"}, {"ঈ", "i"}, {"উ", "u"}, {"ঊ", "u"}, {"ঋ", "ri"}, {"এ", "e"}, {"ঐ", "oi"}, {"ও", "o"}, {"ঔ", "ou"},
            {"া", "a"}, {"ি", "i"}, {"ী", "i"}, {"ু", "u"}, {"ূ", "u"}, {"ৃ", "ri"}, {"ে", "e"}, {"ৈ", "oi"}, {"ো", "o"}, {"ৌ", "ou"},
            {"ক", "k"}, {"খ", "kh"}, {"গ", "g"}, {"ঘ", "gh"}, {"ঙ", "ng"}, {"চ", "c"}, {"ছ", "ch"}, {"জ", "j"}, {"ঝ", "jh"}, {"ঞ", "n"},
            {"ট", "t"}, {"ঠ", "th"}, {"ড", "d"}, {"ঢ", "dh"}, {"ণ", "n"}, {"ত", "t"}, {"থ", "th"}, {"দ", "d"}, {"ধ", "dh"}, {"ন", "n"},
            {"প", "p"}, {"ফ", "f"}, {"ব", "b"}, {"ভ", "bh"}, {"ম", "m"}, {"য", "j"}, {"র", "r"}, {"ল", "l"}, {"শ", "s"}, {"ষ", "s"}, {"স", "s"},
            {"হ", "h"}, {"ড়", "r"}, {"ঢ়", "r"}, {"য়", "y"}, {"ৎ", "t"}, {"ং", "ng"}, {"ঃ", "h"}, {"ঁ", ""}, {"্", ""}};

    /** A rough sound-key of a name: Bangla is turned into Latin letters, then vowels, h, repeated letters are dropped (Jarif, Zarif, জারিফ all give "jrf"). */
    public static String skeleton(String name) {
        if (name == null) return "";
        String t = name.toLowerCase(Locale.ROOT);
        for (String[] m : BN) t = t.replace(m[0], m[1]);
        t = t.replace("ph", "f").replace("z", "j").replace("q", "k").replace("w", "o").replace("x", "ks").replace("c", "k");
        t = t.replaceAll("[^a-z]", "").replaceAll("[aeiouyh]", "").replaceAll("(.)\\1+", "$1");
        return t;
    }

    private static int edit(String a, String b) {
        int[] p = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) p[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            int prev = p[0];
            p[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int tmp = p[j];
                p[j] = Math.min(Math.min(p[j] + 1, p[j - 1] + 1), prev + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
                prev = tmp;
            }
        }
        return p[b.length()];
    }

    /** 0 = no match, higher = better. Compares sound-keys word by word. */
    public static int nameScore(String query, String candidate) {
        if (query == null || candidate == null) return 0;
        if (candidate.trim().equalsIgnoreCase(query.trim())) return 100;
        String[] qs = query.trim().split("\\s+");
        String[] cs = candidate.trim().split("\\s+");
        int best = 0;
        for (String q : qs) {
            String qk = skeleton(q);
            if (qk.length() < 2) continue;
            for (String w : cs) {
                String wk = skeleton(w);
                if (wk.isEmpty()) continue;
                int sc = 0;
                if (wk.equals(qk)) sc = 80;
                else if (qk.length() >= 3 && (wk.startsWith(qk) || qk.startsWith(wk)) && wk.length() >= 3) sc = 60;
                else if (qk.length() >= 3 && wk.length() >= 3 && edit(qk, wk) <= 1) sc = 50;
                best = Math.max(best, sc);
            }
        }
        return best;
    }

    /** Best matching contact by sound, [name, number] or null. */
    public static String[] fuzzyContact(Context c, String who) {
        if (who == null || who.trim().isEmpty()) return null;
        String[] best = null;
        int bestScore = 0;
        try (Cursor cur = c.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null)) {
            while (cur != null && cur.moveToNext()) {
                String nm = cur.getString(0);
                int sc = nameScore(who, nm);
                if (sc > bestScore) {
                    bestScore = sc;
                    best = new String[]{nm, cur.getString(1)};
                }
            }
        } catch (Exception ignored) {
        }
        return bestScore >= 50 ? best : null;
    }

    /** Resolves a name or number to a phone number, or null. */
    public static String resolveNumber(Context c, String who) {
        if (who == null) return null;
        if (looksLikeNumber(who)) return who.replaceAll("[\\s\\-()]", "");
        JSONArray a = findContacts(c, who);
        if (a.length() == 0) {
            String[] f = fuzzyContact(c, who);
            if (f != null) return f[1].replaceAll("[\\s\\-()]", "");
        }
        if (a.length() == 0) {
            for (String v : nameVariants(c, who)) {
                a = findContacts(c, v);
                if (a.length() > 0) break;
            }
        }
        if (a.length() == 0) return null;
        // prefer an exact name match
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optString("name").equalsIgnoreCase(who.trim())) {
                return o.optString("number").replaceAll("[\\s\\-()]", "");
            }
        }
        JSONObject o = a.optJSONObject(0);
        return o == null ? null : o.optString("number").replaceAll("[\\s\\-()]", "");
    }

    /** Adds the country code using the SIM's country (01712... becomes +880 1712...). Leaves numbers that already have + alone. */
    public static String e164(Context c, String number) {
        if (number == null || number.startsWith("+")) return number;
        try {
            String iso = ((android.telephony.TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE)).getSimCountryIso();
            if (iso != null && !iso.isEmpty()) {
                String r = android.telephony.PhoneNumberUtils.formatNumberToE164(number, iso.toUpperCase(java.util.Locale.ROOT));
                if (r != null) return r;
            }
        } catch (Exception ignored) {
        }
        return number;
    }

    public static String digitsOnly(String number) {
        return number == null ? "" : number.replaceAll("[^0-9]", "");
    }

    // ------------------------------------------------------------------ name spellings

    private static final Map<String, List<String>> VARIANTS = new HashMap<>();

    /** The name as given plus other spellings (Bangla / English) so a contact saved in another script is still found. */
    public static synchronized List<String> nameVariants(Context c, String who) {
        List<String> out = new ArrayList<>();
        if (who == null || who.trim().isEmpty()) return out;
        String w = who.trim();
        out.add(w);
        List<String> cached = VARIANTS.get(w.toLowerCase(Locale.ROOT));
        if (cached != null) return cached;
        try {
            if (!Prefs.apiKey(c).isEmpty()) {
                String r = GeminiRest.generate(c, "A person's name is written: \"" + w + "\". Reply with only a comma separated list of "
                        + "the most likely spellings of this same name in English letters and in Bangla script (max 6), no explanation.");
                for (String part : r.split("[,\n،]")) {
                    String t = part.trim().replaceAll("^[\"'*\\-\\s]+|[\"'*\\s]+$", "");
                    if (!t.isEmpty() && t.length() < 40 && !containsIgnoreCase(out, t)) out.add(t);
                }
            }
        } catch (Exception ignored) {
        }
        VARIANTS.put(w.toLowerCase(Locale.ROOT), out);
        return out;
    }

    private static boolean containsIgnoreCase(List<String> l, String t) {
        for (String x : l) if (x.equalsIgnoreCase(t)) return true;
        return false;
    }

    // ------------------------------------------------------------------ undo

    private static final Deque<Object[]> UNDO = new ArrayDeque<>();

    public static synchronized void pushUndo(String description, Runnable revert) {
        UNDO.push(new Object[]{description, revert});
        while (UNDO.size() > 20) UNDO.removeLast();
    }

    public static synchronized String undoLast() {
        if (UNDO.isEmpty()) return null;
        Object[] e = UNDO.pop();
        try {
            ((Runnable) e[1]).run();
            return (String) e[0];
        } catch (Exception ex) {
            return "failed to undo " + e[0] + ": " + ex.getMessage();
        }
    }

    public static synchronized JSONArray undoList() {
        JSONArray a = new JSONArray();
        for (Object[] e : UNDO) a.put(e[0]);
        return a;
    }

    public static String lower(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT);
    }

    public static Uri uri(String s) {
        return Uri.parse(s);
    }
}
