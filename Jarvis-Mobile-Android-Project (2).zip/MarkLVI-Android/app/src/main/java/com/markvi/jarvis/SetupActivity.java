package com.markvi.jarvis;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** One screen that shows every permission Mira needs, whether it is on, and takes you straight to the switch. */
public class SetupActivity extends Activity {

    private static final int REQ = 31;
    private LinearLayout list;
    private TextView summary;

    private static final String[] RUNTIME = {
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#05080d"));
        getWindow().setNavigationBarColor(Color.parseColor("#05080d"));
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#05080d"));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        int p = dp(16);
        col.setPadding(p, dp(36), p, dp(28));
        sv.addView(col);

        TextView t = new TextView(this);
        t.setText("Mira setup");
        t.setTextColor(Color.WHITE);
        t.setTextSize(24);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(t);

        summary = new TextView(this);
        summary.setTextColor(Color.parseColor("#8FB3BD"));
        summary.setTextSize(13);
        summary.setPadding(0, dp(6), 0, dp(14));
        col.addView(summary);

        col.addView(button("Allow all basic permissions (one tap)", Color.parseColor("#00B8D4"), v -> requestBasics()));

        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list);

        col.addView(button("Done, open Mira", Color.parseColor("#1E8E5A"), v -> {
            Prefs.sp(this).edit().putBoolean("setup_seen", true).apply();
            finish();
        }));
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        boolean denied = false;
        for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) denied = true;
        if (denied) {
            Toast.makeText(this, "Some are still off. Open the phone's App info > Permissions for Mira and allow them (Calendar, Phone, Call logs, Contacts, SMS).", Toast.LENGTH_LONG).show();
        }
        refresh();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private Button button(String text, int color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBasics() {
        List<String> need = new ArrayList<>();
        for (String p : RUNTIME) if (!has(p)) need.add(p);
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (need.isEmpty()) {
            Toast.makeText(this, "All basic permissions are already on", Toast.LENGTH_SHORT).show();
            return;
        }
        requestPermissions(need.toArray(new String[0]), REQ);
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            } catch (Exception ignored) {
                Toast.makeText(this, "This page is not available on your phone", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void refresh() {
        list.removeAllViews();
        int missing = 0;
        boolean critical = false;

        boolean mic = has(Manifest.permission.RECORD_AUDIO);
        boolean cam = has(Manifest.permission.CAMERA);
        boolean con = has(Manifest.permission.READ_CONTACTS);
        boolean call = has(Manifest.permission.CALL_PHONE);
        boolean sms = has(Manifest.permission.SEND_SMS);
        boolean loc = has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION);
        boolean notif = Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS);
        Intent appInfo = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));

        header("BASIC (asked in one tap)");
        missing += row("Microphone", "Voice conversation with Mira", mic, v -> requestBasics(), true);
        missing += row("Camera", "Look through the camera, flashlight", cam, v -> requestBasics(), false);
        boolean hasFlash = getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);
        missing += row("Flashlight", hasFlash
                        ? "Android grants this automatically (no pop-up exists). Tap to test: the torch blinks once."
                        : "This phone has no flashlight",
                hasFlash, v -> {
                    new Thread(() -> {
                        try {
                            ToolsPhone.torch(getApplicationContext(), true);
                            Thread.sleep(700);
                            ToolsPhone.torch(getApplicationContext(), false);
                            runOnUiThread(() -> Toast.makeText(this, "Flashlight works", Toast.LENGTH_SHORT).show());
                        } catch (Throwable t) {
                            runOnUiThread(() -> Toast.makeText(this, "Flashlight failed: " + t.getMessage(), Toast.LENGTH_LONG).show());
                        }
                    }).start();
                }, false);
        missing += row("Contacts", "Find who to call or message", con, v -> requestBasics(), false);
        missing += row("Phone calls", "Call people after your approval", call, v -> requestBasics(), false);
        missing += row("SMS", "Send text messages after your approval", sms, v -> requestBasics(), false);
        missing += row("Location", "Where am I, maps, weather", loc, v -> requestBasics(), false);
        boolean cal = has(Manifest.permission.READ_CALENDAR) && has(Manifest.permission.WRITE_CALENDAR);
        boolean calls = has(Manifest.permission.ANSWER_PHONE_CALLS) && has(Manifest.permission.READ_PHONE_STATE) && has(Manifest.permission.READ_CALL_LOG);
        missing += row("Calendar", "Read and add Google Calendar events", cal, v -> requestBasics(), false);
        missing += row("Incoming calls", "Say who is calling, answer or decline when you ask (phone state, call log, answer calls)", calls, v -> requestBasics(), false);
        missing += row("Save contacts", "Save a new contact when you say so", has(Manifest.permission.WRITE_CONTACTS), v -> requestBasics(), false);
        missing += row("Read SMS", "Read your latest text messages and OTP when you ask", has(Manifest.permission.READ_SMS), v -> requestBasics(), false);
        missing += row("Notifications", "Reminders and the listening notice", notif, v -> requestBasics(), false);

        header("SPECIAL (Android needs you to flip each switch)");
        boolean acc = JarvisAccessibility.get() != null;
        missing += row("Accessibility", "Taps Send, types in search boxes, reads the screen, screenshots. Find \"Mira\" in the list and turn it on.",
                acc, v -> open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)), true);
        missing += row("Notification access", "Lets the Smart Notification Filter read your real notifications",
                NotifCatcher.hasAccess(this), v -> open(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")), false);
        missing += row("Display over other apps", "Needed to open WhatsApp, Messenger and others while Mira works in the background",
                Settings.canDrawOverlays(this),
                v -> open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))), true);
        boolean files = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager();
        missing += row("All files access", "Read, move and organise files for the file tools",
                files, v -> open(Build.VERSION.SDK_INT >= 30
                        ? new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()))
                        : appInfo), false);
        missing += row("Modify system settings", "Change brightness",
                Settings.System.canWrite(this),
                v -> open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName()))), false);
        NotificationManager nm = getSystemService(NotificationManager.class);
        missing += row("Notifications", "Task results, reminders and call alerts",
                nm != null && nm.areNotificationsEnabled() && (Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS)),
                v -> Util.openNotifSettings(this), false);
        missing += row("Do Not Disturb access", "Silent mode and Do Not Disturb",
                nm != null && nm.isNotificationPolicyAccessGranted(),
                v -> open(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)), false);
        boolean usage = false;
        try {
            android.app.AppOpsManager ao = (android.app.AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            usage = ao.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), getPackageName()) == android.app.AppOpsManager.MODE_ALLOWED;
        } catch (Exception ignored) {
        }
        missing += row("Usage access", "Screen time: which apps you used most", usage, v -> open(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)), false);
        boolean secure = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED;
        row("Auto-keep Accessibility (optional, advanced)", secure ? "ON: Mira switches Accessibility back on by herself"
                : "One-time, from a computer with USB debugging:  adb shell pm grant com.markvi.jarvis android.permission.WRITE_SECURE_SETTINGS", secure, v -> Toast.makeText(this,
                "Run on a computer: adb shell pm grant com.markvi.jarvis android.permission.WRITE_SECURE_SETTINGS", Toast.LENGTH_LONG).show(), false);
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        missing += row("Unrestricted battery", "Keeps Mira alive in the background",
                pm != null && pm.isIgnoringBatteryOptimizations(getPackageName()),
                v -> open(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))), false);
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = getSystemService(AlarmManager.class);
            missing += row("Exact alarms", "Reminders that fire on time",
                    am != null && am.canScheduleExactAlarms(),
                    v -> open(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getPackageName()))), false);
        }

        critical = !mic || !acc;
        summary.setText(missing == 0 ? "Everything is on. Mira can do all of it."
                : missing + " switch" + (missing == 1 ? "" : "es") + " still off. "
                + (critical ? "Microphone and Accessibility matter most." : "The most important ones are on."));
    }

    private void header(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.parseColor("#00E5FF"));
        t.setTextSize(11);
        t.setLetterSpacing(0.1f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(20), 0, dp(4));
        list.addView(t);
    }

    /** Returns 1 when the permission is missing (for the counter), else 0. */
    private int row(String name, String why, boolean on, View.OnClickListener l, boolean important) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#0C141D"));
        g.setCornerRadius(dp(14));
        g.setStroke(dp(1), Color.parseColor(on ? "#1B4D3A" : important ? "#7A3B3B" : "#1D2A38"));
        r.setBackground(g);
        r.setPadding(dp(12), dp(10), dp(12), dp(10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(8);
        r.setLayoutParams(lp);

        LinearLayout txt = new LinearLayout(this);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        TextView n = new TextView(this);
        n.setText((on ? "✅  " : "⚠️  ") + name);
        n.setTextColor(Color.WHITE);
        n.setTextSize(14);
        n.setTypeface(Typeface.DEFAULT_BOLD);
        TextView w = new TextView(this);
        w.setText(why);
        w.setTextColor(Color.parseColor("#7F98A3"));
        w.setTextSize(11);
        txt.addView(n);
        txt.addView(w);
        r.addView(txt);

        if (!on) {
            Button b = new Button(this);
            b.setText("Allow");
            b.setAllCaps(false);
            b.setTextColor(Color.WHITE);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(Color.parseColor("#00B8D4"));
            bg.setCornerRadius(dp(10));
            b.setBackground(bg);
            b.setLayoutParams(new LinearLayout.LayoutParams(dp(78), dp(38)));
            b.setOnClickListener(l);
            r.addView(b);
        }
        list.addView(r);
        return on ? 0 : 1;
    }
}
