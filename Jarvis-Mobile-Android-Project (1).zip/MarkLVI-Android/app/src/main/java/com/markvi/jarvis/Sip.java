package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONObject;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Mira's IP phone: keeps a SIP line registered, tells the user about calls on it, answers or declines them on command, and plays Mira's voice into the call. */
public final class Sip {
    private Sip() {}

    private static SipClient client;
    private static String cfgKey = "";
    public static volatile String status = "off";

    public static JSONObject config(Context c) {
        android.content.SharedPreferences p = Prefs.sp(c);
        return J.obj("on", p.getBoolean("sip_on", false), "server", p.getString("sip_server", ""), "port", p.getInt("sip_port", 5060),
                "user", p.getString("sip_user", ""), "auth", p.getString("sip_auth", ""), "pass", p.getString("sip_pass", ""));
    }

    public static void save(Context c, boolean on, String server, int port, String user, String auth, String pass) {
        Prefs.sp(c).edit().putBoolean("sip_on", on).putString("sip_server", server.trim()).putInt("sip_port", port <= 0 ? 5060 : port)
                .putString("sip_user", user.trim()).putString("sip_auth", auth.trim()).putString("sip_pass", pass).apply();
        ensure(c);
    }

    /** Starts, restarts (settings changed) or stops the line. Safe to call often. */
    public static synchronized void ensure(final Context ctx) {
        final Context c = ctx.getApplicationContext();
        JSONObject cfg = config(c);
        boolean ready = cfg.optBoolean("on") && !cfg.optString("server").isEmpty() && !cfg.optString("user").isEmpty();
        String key = cfg.toString();
        if (!ready) {
            if (client != null) {
                client.stop();
                client = null;
            }
            cfgKey = "";
            status = "off";
            return;
        }
        if (client != null && key.equals(cfgKey)) return;
        if (client != null) client.stop();
        cfgKey = key;
        status = "connecting";
        client = new SipClient(cfg.optString("server"), cfg.optInt("port", 5060), cfg.optString("user"), cfg.optString("auth"), cfg.optString("pass"),
                new SipClient.Listener() {
                    @Override
                    public void onLog(String s) {
                        DebugLog.add(s);
                    }

                    @Override
                    public void onState(String s) {
                        status = s;
                    }

                    @Override
                    public void onRing(String from) {
                        status = "ringing";
                        String who = pretty(from);
                        Util.notifyAlert(c, 4730, "IP call", "Incoming IP call from " + who);
                        JarvisService svc = JarvisService.get();
                        if (svc != null && svc.isLive()) svc.alert("An IP phone call is ringing from " + who + ". Ask the user what to do; do not answer by yourself.");
                    }
                });
        client.start();
    }

    static String pretty(String from) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"([^\"]+)\"").matcher(from == null ? "" : from);
        if (m.find()) return m.group(1);
        m = java.util.regex.Pattern.compile("sip:([^@;>]+)").matcher(from == null ? "" : from);
        return m.find() ? m.group(1) : String.valueOf(from);
    }

    static void register() {
        reg("sip_status",
                "Tells whether Mira's IP phone line (SIP) is connected and whether an IP call is ringing and from whom.",
                schema(""),
                (c, a) -> {
                    ensure(c);
                    boolean ring = client != null && client.isRinging();
                    return J.ok("line", status, "registered", client != null && client.isRegistered(), "ringing", ring,
                            "from", ring ? pretty(client.callerName()) : "");
                });

        reg("sip_answer_say_busy",
                "Answers the ringing IP phone call (SIP line) and plays Mira's voice to the caller, then hangs up. This one the caller really hears. "
                        + "Only when the user asks. text is optional (default: a polite Bangla line saying the user is busy).",
                schema("", "text:STRING:what Mira says to the caller", "hang_up:BOOLEAN:default true"),
                (c, a) -> {
                    if (client == null || !client.isRinging()) return J.fail("no IP call is ringing");
                    String text = a.optString("text").trim();
                    if (text.isEmpty()) text = ToolsCalls.BUSY_TEXT_BN;
                    byte[] pcm = VoiceTts.render(c, text, Prefs.voice(c));
                    if (pcm == null) return J.fail("could not prepare Mira's voice (" + VoiceTts.lastError + "); the call was not answered");
                    if (!client.isRinging()) return J.fail("the caller hung up meanwhile");
                    boolean ok = client.answerAndPlay(VoiceTts.boost(pcm), a.optBoolean("hang_up", true));
                    return ok ? J.obj("status", "unverified", "note", "answered and played Mira's voice to the caller; nobody can confirm they heard it") : J.fail("could not answer");
                });

        reg("sip_reject",
                "Declines the ringing IP phone call (SIP line).",
                schema(""),
                (c, a) -> {
                    if (client == null || !client.isRinging()) return J.fail("no IP call is ringing");
                    client.reject();
                    return J.ok("note", "IP call declined");
                });
    }
}
