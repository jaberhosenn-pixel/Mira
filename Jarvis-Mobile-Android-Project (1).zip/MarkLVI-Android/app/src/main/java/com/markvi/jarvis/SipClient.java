package com.markvi.jarvis;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * A small SIP phone (UDP): registers to a SIP server, receives calls, answers them and plays voice (G.711 mu-law) to the caller.
 * No Android classes here on purpose, so it can be tested on a computer.
 */
public class SipClient {

    public interface Listener {
        void onLog(String s);

        void onState(String s);

        void onRing(String from);
    }

    private final String server, user, authUser, pass, domain;
    private final int port;
    private final Listener ls;
    private DatagramSocket sip;
    private volatile boolean running, registered;
    private volatile Thread loop;
    private final Random rnd = new Random();
    private final String tag = Integer.toHexString(rnd.nextInt() & 0xffffff);
    private String callId = Long.toHexString(rnd.nextLong() & 0xffffffffffL) + "@mira";
    private int cseq = 1;
    private InetAddress serverAddr;
    private String localIp = "0.0.0.0";

    // current incoming call
    private volatile Map<String, String> inv;      // headers of the INVITE
    private volatile InetSocketAddress invFrom;
    private volatile String remoteRtpIp;
    private volatile int remoteRtpPort;
    private volatile String toTag;
    private volatile boolean inCall;
    private volatile boolean cancelled;

    public SipClient(String server, int port, String user, String authUser, String pass, Listener ls) {
        this.server = server;
        this.port = port <= 0 ? 5060 : port;
        this.user = user;
        this.authUser = authUser == null || authUser.isEmpty() ? user : authUser;
        this.pass = pass == null ? "" : pass;
        this.domain = server;
        this.ls = ls;
    }

    public boolean isRegistered() {
        return registered;
    }

    public boolean isRinging() {
        return inv != null && !inCall && !cancelled;
    }

    public String callerName() {
        Map<String, String> i = inv;
        return i == null ? "" : i.getOrDefault("from", "");
    }

    // ------------------------------------------------------------------ lifecycle

    public void start() {
        if (running) return;
        running = true;
        loop = new Thread(this::run, "sip");
        loop.setDaemon(true);
        loop.start();
    }

    public void stop() {
        running = false;
        registered = false;
        try {
            if (sip != null) sip.close();
        } catch (Exception ignored) {
        }
    }

    private void log(String s) {
        if (ls != null) ls.onLog(s);
    }

    private void state(String s) {
        if (ls != null) ls.onState(s);
    }

    private void run() {
        long lastReg = 0;
        int fails = 0;
        while (running) {
            try {
                if (sip == null || sip.isClosed()) {
                    serverAddr = InetAddress.getByName(server);
                    sip = new DatagramSocket();
                    sip.setSoTimeout(1000);
                    try (DatagramSocket probe = new DatagramSocket()) {
                        probe.connect(serverAddr, port);
                        localIp = probe.getLocalAddress().getHostAddress();
                    }
                    registered = false;
                    lastReg = 0;
                }
                if (System.currentTimeMillis() - lastReg > (registered ? 100000 : 15000)) {
                    lastReg = System.currentTimeMillis();
                    boolean ok = register();
                    if (ok) {
                        fails = 0;
                    } else if (++fails % 3 == 0) {
                        state("register failed");
                    }
                }
                byte[] buf = new byte[4096];
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                try {
                    sip.receive(p);
                } catch (java.net.SocketTimeoutException t) {
                    continue;
                }
                handle(new String(p.getData(), 0, p.getLength(), "UTF-8"), new InetSocketAddress(p.getAddress(), p.getPort()));
            } catch (Exception e) {
                if (!running) return;
                log("SIP error: " + e);
                registered = false;
                try {
                    if (sip != null) sip.close();
                } catch (Exception ignored) {
                }
                sip = null;
                sleep(5000);
            }
        }
    }

    // ------------------------------------------------------------------ messages

    private static String md5(String s) throws Exception {
        byte[] d = MessageDigest.getInstance("MD5").digest(s.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static Map<String, String> parse(String msg) {
        Map<String, String> h = new HashMap<>();
        String[] lines = msg.split("\r\n");
        h.put("_start", lines[0]);
        StringBuilder vias = new StringBuilder();
        int i = 1;
        for (; i < lines.length && !lines[i].isEmpty(); i++) {
            int c = lines[i].indexOf(':');
            if (c < 0) continue;
            String k = lines[i].substring(0, c).trim().toLowerCase(Locale.ROOT);
            String v = lines[i].substring(c + 1).trim();
            if (k.equals("v")) k = "via";
            if (k.equals("f")) k = "from";
            if (k.equals("t")) k = "to";
            if (k.equals("i")) k = "call-id";
            if (k.equals("m")) k = "contact";
            if (k.equals("via")) {
                if (vias.length() > 0) vias.append("\r\nVia: ");
                vias.append(v);
            } else {
                h.put(k, v);
            }
        }
        h.put("via", vias.toString());
        int bi = msg.indexOf("\r\n\r\n");
        h.put("_body", bi < 0 ? "" : msg.substring(bi + 4));
        return h;
    }

    private void send(String msg, InetSocketAddress to) throws Exception {
        byte[] b = msg.getBytes("UTF-8");
        sip.send(new DatagramPacket(b, b.length, to));
    }

    private InetSocketAddress srv() {
        return new InetSocketAddress(serverAddr, port);
    }

    private String via() {
        return "SIP/2.0/UDP " + localIp + ":" + sip.getLocalPort() + ";rport;branch=z9hG4bK" + Long.toHexString(rnd.nextLong() & 0xffffffffL);
    }

    private String contact() {
        return "<sip:" + user + "@" + localIp + ":" + sip.getLocalPort() + ">";
    }

    private String registerMsg(String authHeader) {
        return "REGISTER sip:" + domain + " SIP/2.0\r\nVia: " + via() + "\r\nMax-Forwards: 70\r\nFrom: <sip:" + user + "@" + domain + ">;tag=" + tag
                + "\r\nTo: <sip:" + user + "@" + domain + ">\r\nCall-ID: " + callId + "\r\nCSeq: " + (cseq++) + " REGISTER\r\nContact: " + contact()
                + ";expires=300\r\nExpires: 300\r\nUser-Agent: Mira\r\n" + (authHeader == null ? "" : authHeader + "\r\n") + "Content-Length: 0\r\n\r\n";
    }

    private boolean register() throws Exception {
        send(registerMsg(null), srv());
        for (int round = 0; round < 2; round++) {
            Map<String, String> r = waitResponse(4000);
            if (r == null) return false;
            String st = r.get("_start");
            if (st.contains(" 200")) {
                if (!registered) {
                    registered = true;
                    state("registered");
                    log("SIP registered as " + user + " on " + server);
                }
                return true;
            }
            if (st.contains(" 401") || st.contains(" 407")) {
                String ch = r.getOrDefault(st.contains(" 401") ? "www-authenticate" : "proxy-authenticate", "");
                String realm = field(ch, "realm"), nonce = field(ch, "nonce"), opaque = field(ch, "opaque"), qop = field(ch, "qop");
                String uri = "sip:" + domain;
                String ha1 = md5(authUser + ":" + realm + ":" + pass), ha2 = md5("REGISTER:" + uri);
                String resp, extra = "";
                if (qop.contains("auth")) {
                    String cn = Long.toHexString(rnd.nextLong() & 0xffffffffL);
                    resp = md5(ha1 + ":" + nonce + ":00000001:" + cn + ":auth:" + ha2);
                    extra = ", qop=auth, nc=00000001, cnonce=\"" + cn + "\"";
                } else {
                    resp = md5(ha1 + ":" + nonce + ":" + ha2);
                }
                String auth = (st.contains(" 401") ? "Authorization" : "Proxy-Authorization") + ": Digest username=\"" + authUser + "\", realm=\"" + realm
                        + "\", nonce=\"" + nonce + "\", uri=\"" + uri + "\", response=\"" + resp + "\", algorithm=MD5" + extra
                        + (opaque.isEmpty() ? "" : ", opaque=\"" + opaque + "\"");
                send(registerMsg(auth), srv());
                continue;
            }
            log("SIP register answer: " + st);
            return false;
        }
        return false;
    }

    private static String field(String h, String name) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(name + "=\"?([^\",]*)\"?").matcher(h);
        return m.find() ? m.group(1) : "";
    }

    /** Waits for a SIP response (status line), handling other traffic meanwhile. */
    private Map<String, String> waitResponse(long ms) throws Exception {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            byte[] buf = new byte[4096];
            DatagramPacket p = new DatagramPacket(buf, buf.length);
            try {
                sip.receive(p);
            } catch (java.net.SocketTimeoutException t) {
                continue;
            }
            String msg = new String(p.getData(), 0, p.getLength(), "UTF-8");
            if (msg.startsWith("SIP/2.0")) return parse(msg);
            handle(msg, new InetSocketAddress(p.getAddress(), p.getPort()));
        }
        return null;
    }

    private void handle(String msg, InetSocketAddress from) throws Exception {
        if (msg.trim().isEmpty() || msg.startsWith("SIP/2.0")) return;
        Map<String, String> h = parse(msg);
        String start = h.get("_start");
        String method = start.split(" ")[0];
        switch (method) {
            case "OPTIONS":
                reply(h, from, "200 OK", null, null);
                break;
            case "INVITE":
                if (inv != null && !cancelled && h.getOrDefault("call-id", "").equals(inv.get("call-id"))) return; // retransmission
                if (inCall) {
                    reply(h, from, "486 Busy Here", null, null);
                    return;
                }
                inv = h;
                invFrom = from;
                cancelled = false;
                toTag = Integer.toHexString(rnd.nextInt() & 0xffffff);
                parseSdp(h.get("_body"));
                reply(h, from, "180 Ringing", toTag, null);
                log("SIP incoming call from " + h.getOrDefault("from", ""));
                if (ls != null) ls.onRing(h.getOrDefault("from", ""));
                break;
            case "CANCEL":
                if (inv != null && h.getOrDefault("call-id", "").equals(inv.get("call-id"))) {
                    reply(h, from, "200 OK", null, null);
                    if (!inCall) {
                        reply(inv, invFrom, "487 Request Terminated", toTag, null);
                        cancelled = true;
                        state("missed");
                    }
                }
                break;
            case "BYE":
                reply(h, from, "200 OK", null, null);
                inCall = false;
                cancelled = true;
                state("call ended");
                break;
            case "ACK":
                break;
            default:
                reply(h, from, "501 Not Implemented", null, null);
        }
    }

    private void parseSdp(String sdp) {
        remoteRtpIp = null;
        remoteRtpPort = 0;
        for (String l : sdp.split("\r?\n")) {
            if (l.startsWith("c=IN IP4 ")) remoteRtpIp = l.substring(9).trim();
            if (l.startsWith("m=audio ")) remoteRtpPort = Integer.parseInt(l.split(" ")[1]);
        }
    }

    private void reply(Map<String, String> h, InetSocketAddress to, String status, String tTag, String body) throws Exception {
        String toHdr = h.getOrDefault("to", "");
        if (tTag != null && !toHdr.contains("tag=")) toHdr += ";tag=" + tTag;
        StringBuilder sb = new StringBuilder("SIP/2.0 " + status + "\r\nVia: " + h.getOrDefault("via", "") + "\r\nFrom: " + h.getOrDefault("from", "")
                + "\r\nTo: " + toHdr + "\r\nCall-ID: " + h.getOrDefault("call-id", "") + "\r\nCSeq: " + h.getOrDefault("cseq", "") + "\r\nUser-Agent: Mira\r\n");
        if (body != null) sb.append("Contact: ").append(contact()).append("\r\nContent-Type: application/sdp\r\n");
        sb.append("Content-Length: ").append(body == null ? 0 : body.getBytes("UTF-8").length).append("\r\n\r\n");
        if (body != null) sb.append(body);
        send(sb.toString(), to);
    }

    // ------------------------------------------------------------------ call actions

    public void reject() throws Exception {
        if (!isRinging()) return;
        reply(inv, invFrom, "486 Busy Here", toTag, null);
        cancelled = true;
        state("rejected");
    }

    /** Answers the ringing call, plays the 24 kHz 16-bit mono PCM to the caller, then hangs up when asked. */
    public boolean answerAndPlay(byte[] pcm24k, boolean hangUp) throws Exception {
        if (!isRinging()) return false;
        final Map<String, String> h = inv;
        DatagramSocket rtp = new DatagramSocket();
        try {
            String sdp = "v=0\r\no=mira " + (System.currentTimeMillis() / 1000) + " 1 IN IP4 " + localIp + "\r\ns=Mira\r\nc=IN IP4 " + localIp + "\r\nt=0 0\r\nm=audio "
                    + rtp.getLocalPort() + " RTP/AVP 0\r\na=rtpmap:0 PCMU/8000\r\na=ptime:20\r\na=sendrecv\r\n";
            inCall = true;
            reply(h, invFrom, "200 OK", toTag, sdp);
            state("in call");
            if (remoteRtpIp == null || remoteRtpPort == 0) throw new Exception("caller gave no media address");
            InetSocketAddress dest = new InetSocketAddress(remoteRtpIp, remoteRtpPort);
            rtp.setSoTimeout(1);
            byte[] ulaw = toUlaw(pcm24k);
            int seq = rnd.nextInt(60000), ts = rnd.nextInt(1 << 20), ssrc = rnd.nextInt();
            long t0 = System.nanoTime();
            int frames = ulaw.length / 160 + 25;      // + ~0.5 s of silence at the end
            byte[] silence = new byte[160];
            java.util.Arrays.fill(silence, (byte) 0xff);
            // a short lead-in of silence opens the NAT and lets the line settle (0.4 s)
            int lead = 20;
            for (int f = 0; f < lead + frames && inCall && running; f++) {
                byte[] pay = new byte[160];
                int idx = (f - lead) * 160;
                if (idx >= 0 && idx + 160 <= ulaw.length) System.arraycopy(ulaw, idx, pay, 0, 160);
                else System.arraycopy(silence, 0, pay, 0, 160);
                byte[] pk = new byte[172];
                pk[0] = (byte) 0x80;
                pk[1] = 0;
                pk[2] = (byte) (seq >> 8);
                pk[3] = (byte) seq;
                pk[4] = (byte) (ts >> 24);
                pk[5] = (byte) (ts >> 16);
                pk[6] = (byte) (ts >> 8);
                pk[7] = (byte) ts;
                pk[8] = (byte) (ssrc >> 24);
                pk[9] = (byte) (ssrc >> 16);
                pk[10] = (byte) (ssrc >> 8);
                pk[11] = (byte) ssrc;
                System.arraycopy(pay, 0, pk, 12, 160);
                rtp.send(new DatagramPacket(pk, pk.length, dest));
                seq = (seq + 1) & 0xffff;
                ts += 160;
                long due = t0 + (f + 1) * 20_000_000L;
                long wait = due - System.nanoTime();
                if (wait > 0) Thread.sleep(wait / 1_000_000L, (int) (wait % 1_000_000L));
                // symmetric RTP: if the caller's media arrives from another address, follow it
                try {
                    DatagramPacket in = new DatagramPacket(new byte[400], 400);
                    rtp.receive(in);
                    if (!in.getAddress().equals(dest.getAddress()) || in.getPort() != dest.getPort()) dest = new InetSocketAddress(in.getAddress(), in.getPort());
                } catch (java.net.SocketTimeoutException ignored) {
                }
            }
        } finally {
            rtp.close();
        }
        if (hangUp && inCall) bye();
        return true;
    }

    private void bye() throws Exception {
        Map<String, String> h = inv;
        if (h == null) return;
        String contactUri = h.getOrDefault("contact", "");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("<([^>]+)>").matcher(contactUri);
        String target = m.find() ? m.group(1) : contactUri;
        String from = h.getOrDefault("from", "");
        String to = h.getOrDefault("to", "");
        if (!to.contains("tag=")) to += ";tag=" + toTag;
        // we are the callee: our "From" in BYE is the INVITE's To, and "To" is the INVITE's From
        String msg = "BYE " + target + " SIP/2.0\r\nVia: " + via() + "\r\nMax-Forwards: 70\r\nFrom: " + to + "\r\nTo: " + from + "\r\nCall-ID: " + h.get("call-id")
                + "\r\nCSeq: 1 BYE\r\nUser-Agent: Mira\r\nContent-Length: 0\r\n\r\n";
        send(msg, invFrom);
        inCall = false;
        state("call ended");
    }

    // ------------------------------------------------------------------ audio

    static byte[] toUlaw(byte[] pcm24k) {
        int n = pcm24k.length / 2 / 3;                 // 24 kHz -> 8 kHz: average every 3 samples
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) {
            int sum = 0;
            for (int k = 0; k < 3; k++) {
                int j = (i * 3 + k) * 2;
                sum += (short) ((pcm24k[j] & 0xff) | (pcm24k[j + 1] << 8));
            }
            out[i] = lin2ulaw(sum / 3);
        }
        return out;
    }

    private static byte lin2ulaw(int s) {
        final int BIAS = 0x84, CLIP = 32635;
        int sign = (s >> 8) & 0x80;
        if (sign != 0) s = -s;
        if (s > CLIP) s = CLIP;
        s += BIAS;
        int exp = 7;
        for (int mask = 0x4000; (s & mask) == 0 && exp > 0; exp--, mask >>= 1) {
        }
        int mant = (s >> (exp + 3)) & 0x0f;
        return (byte) ~(sign | (exp << 4) | mant);
    }

    private static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }
}
