package com.markvi.jarvis;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Rings the phone at full alarm volume for about a minute, so a lost phone can be found. */
public final class FindPhone {
    private FindPhone() {}

    private static volatile boolean ringing;
    private static MediaPlayer mp;

    static boolean isRinging() {
        return ringing;
    }

    static synchronized void start(final Context ctx) {
        if (ringing) return;
        ringing = true;
        final Context c = ctx.getApplicationContext();
        new Thread(() -> {
            PowerManager.WakeLock wl = null;
            AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int oldVol = -1;
            try {
                wl = ((PowerManager) c.getSystemService(Context.POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mira:find");
                wl.acquire(100000L);
                oldVol = am.getStreamVolume(AudioManager.STREAM_ALARM);
                am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
                Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                if (u == null) u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                MediaPlayer p = new MediaPlayer();
                p.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                p.setDataSource(c, u);
                p.setLooping(true);
                p.prepare();
                p.start();
                synchronized (FindPhone.class) {
                    mp = p;
                }
                Vibrator vb = (Vibrator) c.getSystemService(Context.VIBRATOR_SERVICE);
                long until = System.currentTimeMillis() + 60000L;
                while (ringing && System.currentTimeMillis() < until) {
                    try {
                        if (vb != null) vb.vibrate(VibrationEffect.createOneShot(700, VibrationEffect.DEFAULT_AMPLITUDE));
                        Thread.sleep(1200);
                    } catch (InterruptedException ie) {
                        break;
                    }
                }
            } catch (Throwable t) {
                DebugLog.add("Find phone ring failed: " + t);
            } finally {
                stop();
                try {
                    if (oldVol >= 0) am.setStreamVolume(AudioManager.STREAM_ALARM, oldVol, 0);
                } catch (Throwable ignored) {
                }
                if (wl != null && wl.isHeld()) wl.release();
            }
        }, "mira-find").start();
    }

    static synchronized void stop() {
        ringing = false;
        try {
            if (mp != null) {
                mp.stop();
                mp.release();
            }
        } catch (Throwable ignored) {
        }
        mp = null;
    }
}
