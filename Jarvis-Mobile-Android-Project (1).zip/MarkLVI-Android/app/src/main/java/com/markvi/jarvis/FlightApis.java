package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;

import okhttp3.Request;
import okhttp3.Response;

/**
 * Optional paid / free-tier flight APIs the user adds in Settings (schedules, delays, gates).
 * Tried in order; the first one that answers wins. Without any key nothing here runs.
 * Response parsing is defensive: a missing field is simply left out, never guessed.
 */
final class FlightApis {
    private FlightApis() {}

    static final String[] NAMES = {"aerodatabox", "airlabs"};

    static String key(Context c, String name) {
        return Prefs.sp(c).getString("flightapi_" + name, "").trim();
    }

    static void setKeys(Context c, String aerodatabox, String airlabs) {
        Prefs.sp(c).edit().putString("flightapi_aerodatabox", aerodatabox == null ? "" : aerodatabox.trim())
                .putString("flightapi_airlabs", airlabs == null ? "" : airlabs.trim()).apply();
    }

    static boolean any(Context c) {
        for (String n : NAMES) if (!key(c, n).isEmpty()) return true;
        return false;
    }

    private static String get(String url, String... headers) throws Exception {
        Request.Builder b = new Request.Builder().url(url).header("User-Agent", "Mira/1.0").header("Accept", "application/json");
        for (int i = 0; i + 1 < headers.length; i += 2) b.header(headers[i], headers[i + 1]);
        try (Response r = GeminiRest.HTTP.newCall(b.build()).execute()) {
            String t = r.body() == null ? "" : r.body().string();
            if (r.code() == 401 || r.code() == 403) throw new Exception("The key was refused (HTTP " + r.code() + "). Check the key and that you subscribed to the API.");
            if (r.code() == 429) throw new Exception("Quota finished for now (HTTP 429).");
            if (r.code() == 404) return "";
            if (!r.isSuccessful()) throw new Exception("HTTP " + r.code());
            return t;
        }
    }

    /** Checks one key with the cheapest real call. Returns a short human sentence; throws when it does not work. */
    static String test(Context c, String name) throws Exception {
        String k = key(c, name);
        if (k.isEmpty()) throw new Exception("No key saved for " + name + ".");
        if ("airlabs".equals(name)) {
            String t = get("https://airlabs.co/api/v9/airlines?iata_code=EK&api_key=" + URLEncoder.encode(k, "UTF-8"));
            JSONObject j = new JSONObject(t);
            if (j.has("error")) throw new Exception(j.optJSONObject("error") != null ? j.optJSONObject("error").optString("message", j.optJSONObject("error").optString("code")) : "AirLabs refused the key");
            return "AirLabs key works.";
        }
        String t = get("https://aerodatabox.p.rapidapi.com/airports/iata/DAC", "X-RapidAPI-Key", k, "X-RapidAPI-Host", "aerodatabox.p.rapidapi.com");
        if (t.isEmpty()) throw new Exception("AeroDataBox answered but found nothing; check the key.");
        JSONObject j = new JSONObject(t);
        return "AeroDataBox key works" + (j.optString("fullName").isEmpty() ? "." : " (" + j.optString("fullName") + ").");
    }

    /** Schedule / status for one IATA flight number (EK585), or null when no API has it or no key is set. */
    static JSONObject lookup(Context c, String iataFlight) {
        if (iataFlight == null || !iataFlight.matches("[A-Z0-9]{2}\\d{1,4}[A-Z]?")) return null;
        for (String n : NAMES) {
            String k = key(c, n);
            if (k.isEmpty()) continue;
            try {
                JSONObject o = "airlabs".equals(n) ? airlabs(k, iataFlight) : aerodatabox(k, iataFlight);
                if (o != null) {
                    o.put("source", n.equals("airlabs") ? "AirLabs" : "AeroDataBox");
                    return o;
                }
            } catch (Throwable t) {
                DebugLog.add("Flight API " + n + " failed: " + t.getMessage());
            }
        }
        return null;
    }

    private static void put(JSONObject o, String key, String v) throws Exception {
        if (v != null && !v.isEmpty() && !"null".equals(v)) o.put(key, v);
    }

    private static JSONObject airlabs(String k, String f) throws Exception {
        String t = get("https://airlabs.co/api/v9/flight?flight_iata=" + f + "&api_key=" + URLEncoder.encode(k, "UTF-8"));
        if (t.isEmpty()) return null;
        JSONObject j = new JSONObject(t);
        JSONObject r = j.optJSONObject("response");
        if (r == null) return null;
        JSONObject o = new JSONObject();
        put(o, "status", r.optString("status"));
        put(o, "airline", r.optString("airline_name"));
        put(o, "departure_airport", r.optString("dep_iata"));
        put(o, "arrival_airport", r.optString("arr_iata"));
        put(o, "departure_scheduled", r.optString("dep_time"));
        put(o, "departure_estimated", r.optString("dep_estimated"));
        put(o, "arrival_scheduled", r.optString("arr_time"));
        put(o, "arrival_estimated", r.optString("arr_estimated"));
        if (r.has("dep_delayed")) o.put("departure_delay_min", r.optInt("dep_delayed"));
        if (r.has("arr_delayed")) o.put("arrival_delay_min", r.optInt("arr_delayed"));
        put(o, "departure_terminal", r.optString("dep_terminal"));
        put(o, "departure_gate", r.optString("dep_gate"));
        put(o, "arrival_terminal", r.optString("arr_terminal"));
        put(o, "arrival_gate", r.optString("arr_gate"));
        return o.length() == 0 ? null : o;
    }

    private static JSONObject aerodatabox(String k, String f) throws Exception {
        String t = get("https://aerodatabox.p.rapidapi.com/flights/number/" + f, "X-RapidAPI-Key", k, "X-RapidAPI-Host", "aerodatabox.p.rapidapi.com");
        if (t.isEmpty()) return null;
        JSONArray arr = t.trim().startsWith("[") ? new JSONArray(t) : null;
        if (arr == null || arr.length() == 0) return null;
        // the API returns several days; take the first flight that is not yet landed, else the latest
        JSONObject pick = arr.optJSONObject(arr.length() - 1);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject x = arr.optJSONObject(i);
            if (x == null) continue;
            String st = x.optString("status");
            if (st.equals("EnRoute") || st.equals("Departed") || st.equals("Expected") || st.equals("Boarding")) {
                pick = x;
                break;
            }
        }
        if (pick == null) return null;
        JSONObject o = new JSONObject();
        put(o, "status", pick.optString("status"));
        JSONObject al = pick.optJSONObject("airline");
        if (al != null) put(o, "airline", al.optString("name"));
        JSONObject ac = pick.optJSONObject("aircraft");
        if (ac != null) put(o, "aircraft", (ac.optString("model") + " " + ac.optString("reg")).trim());
        for (String side : new String[]{"departure", "arrival"}) {
            JSONObject s = pick.optJSONObject(side);
            if (s == null) continue;
            JSONObject ap = s.optJSONObject("airport");
            if (ap != null) put(o, side + "_airport", ap.optString("iata", ap.optString("name")));
            JSONObject sch = s.optJSONObject("scheduledTime");
            if (sch != null) put(o, side + "_scheduled", sch.optString("local"));
            JSONObject rev = s.optJSONObject("revisedTime");
            if (rev != null) put(o, side + "_estimated", rev.optString("local"));
            put(o, side + "_terminal", s.optString("terminal"));
            put(o, side + "_gate", s.optString("gate"));
        }
        return o.length() == 0 ? null : o;
    }
}
