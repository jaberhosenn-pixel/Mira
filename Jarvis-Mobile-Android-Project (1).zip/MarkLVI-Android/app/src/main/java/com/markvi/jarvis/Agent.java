package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Typed-chat brain: Gemini text model with the same phone tools as the live voice session,
 * looped until it has an answer (mobile twin of the tool-call loop in main.py).
 */
public final class Agent {
    private Agent() {}

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String[] MODELS = {"gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-flash-latest"};
    private static final List<JSONObject> HISTORY = new ArrayList<>();

    public static synchronized String chat(Context c, String userText) throws Exception {
        if (Prefs.asksCreator(userText)) return Prefs.creatorAnswer(c);
        String[] rest = {""};
        String sw = SeriousMode.handleSwitch(c, userText, rest);
        if (sw != null) {
            if (!sw.isEmpty()) return sw;
            userText = rest[0]; // "serious mode, build me a website ..." -> carry on with the job
        }
        if (SeriousMode.active(c)) {
            try {
                return SeriousMode.run(c, userText);
            } catch (Exception e) {
                if (Prefs.apiKey(c).isEmpty()) throw e;
                DebugLog.add("Serious provider failed (" + e.getMessage() + "); answering with Gemini instead");
            }
        }
        if (Prefs.apiKey(c).isEmpty()) throw new Exception("No Gemini API key. Add it in Settings.");
        HISTORY.add(J.obj("role", "user", "parts", J.arr(J.obj("text", userText))));

        String sys = Tools.systemPrompt(c)
                + "\n\n[TEXT CHAT MODE] The user typed this message. Reply in plain text (no markdown), short, in the "
                + "language of their message. Call tools when an action is requested; do not describe doing it.";
        JSONArray decls = Tools.declarations();
        String lastText = "";

        for (int round = 0; round < 6; round++) {
            JSONArray contents = new JSONArray();
            for (JSONObject h : HISTORY) contents.put(h);
            JSONObject body = J.obj(
                    "systemInstruction", J.obj("parts", J.arr(J.obj("text", sys))),
                    "contents", contents,
                    "tools", J.arr(J.obj("functionDeclarations", decls)));

            JSONObject resp = post(c, body);
            JSONArray cands = resp.optJSONArray("candidates");
            if (cands == null || cands.length() == 0) throw new Exception("The model returned no answer.");
            JSONObject content = cands.getJSONObject(0).optJSONObject("content");
            JSONArray parts = content == null ? null : content.optJSONArray("parts");
            if (parts == null) throw new Exception("The model returned an empty answer.");

            StringBuilder text = new StringBuilder();
            List<JSONObject> calls = new ArrayList<>();
            for (int i = 0; i < parts.length(); i++) {
                JSONObject p = parts.getJSONObject(i);
                if (p.has("text") && !p.optBoolean("thought", false)) text.append(p.optString("text"));
                JSONObject fc = p.optJSONObject("functionCall");
                if (fc != null) calls.add(fc);
            }
            HISTORY.add(J.obj("role", "model", "parts", parts));
            if (text.length() > 0) lastText = text.toString().trim();

            if (calls.isEmpty()) {
                trim();
                String done = lastText.isEmpty() ? "Done." : lastText;
                if (round > 0 && Bus.ui == null) Util.notifyAlert(c, 4790, "Mira · task done", done.length() > 200 ? done.substring(0, 200) + "…" : done);
                return done;
            }

            JSONArray results = new JSONArray();
            for (JSONObject fc : calls) {
                String name = fc.optString("name");
                JSONObject args = fc.optJSONObject("args");
                Bus.log("Tool: " + name);
                JSONObject r = Tools.dispatchUser(c, name, args == null ? new JSONObject() : args);
                results.put(J.obj("functionResponse", J.obj("name", name, "response", r)));
            }
            HISTORY.add(J.obj("role", "user", "parts", results));
        }
        trim();
        return lastText.isEmpty() ? "I ran several steps; check the phone to see where things stand." : lastText;
    }

    public static synchronized void reset() {
        CustomAgent.reset();
        HISTORY.clear();
    }

    private static void trim() {
        while (HISTORY.size() > 30) HISTORY.remove(0);
        // never start the history on a tool result or a model turn
        while (!HISTORY.isEmpty()) {
            JSONObject first = HISTORY.get(0);
            JSONArray p = first.optJSONArray("parts");
            boolean userText = "user".equals(first.optString("role")) && p != null && p.length() > 0
                    && p.optJSONObject(0) != null && p.optJSONObject(0).has("text");
            if (userText) break;
            HISTORY.remove(0);
        }
    }

    private static JSONObject post(Context c, JSONObject body) throws Exception {
        String key = Prefs.apiKey(c);
        Exception last = null;
        for (String model : MODELS) {
            Request req = new Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + key)
                    .post(RequestBody.create(body.toString(), JSON))
                    .build();
            try (Response r = GeminiRest.HTTP.newCall(req).execute()) {
                String txt = r.body() == null ? "" : r.body().string();
                if (r.isSuccessful()) return J.parse(txt);
                last = new Exception("Gemini error " + r.code() + ": " + GeminiRest.abbreviate(txt, 160));
                if (r.code() == 400 || r.code() == 401 || r.code() == 403) throw last;
            } catch (java.io.IOException io) {
                last = io;
            }
        }
        throw last != null ? last : new Exception("no model answered");
    }
}
