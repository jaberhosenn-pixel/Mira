package com.markvi.jarvis;

/** JNI bridge to whisper.cpp (v1.8.2, CPU only, MIT licence). */
final class WhisperLib {
    private WhisperLib() {}

    static boolean loaded;

    static {
        try {
            System.loadLibrary("mirawhisper");
            loaded = nativeSupported() == 1;
        } catch (Throwable t) {
            DebugLog.add("Whisper native library failed to load: " + t);
        }
    }

    static native int nativeSupported();
    static native long nativeInit(String modelPath);
    static native void nativeFree(long ctx);
    static native String nativeTranscribe(long ctx, int threads, float[] audio16k, String lang, String prompt);
}
