package com.markvi.jarvis;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/** Minimal read-only file provider (no AndroidX): lets other apps open files Mira saved. */
public class MiraFileProvider extends ContentProvider {
    static final String AUTH = "com.markvi.jarvis.files";

    static Uri uriFor(Context c, File f) {
        return new Uri.Builder().scheme("content").authority(AUTH).appendQueryParameter("p", f.getAbsolutePath())
                .appendPath(f.getName()).build();
    }

    private File fileOf(Uri u) throws FileNotFoundException {
        String p = u.getQueryParameter("p");
        if (p == null) throw new FileNotFoundException();
        File f = new File(p);
        String ok;
        try {
            ok = f.getCanonicalPath();
        } catch (java.io.IOException e) {
            throw new FileNotFoundException();
        }
        String dl, own;
        try {
            dl = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS).getCanonicalPath() + "/";
            File ext = getContext().getExternalFilesDir(null);
            own = ext == null ? "/nonexistent/" : ext.getCanonicalPath() + "/";
        } catch (java.io.IOException e) {
            throw new FileNotFoundException();
        }
        if (!(ok.startsWith(dl) || ok.startsWith(own))) throw new FileNotFoundException("not allowed");
        return f;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        return ParcelFileDescriptor.open(fileOf(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        try {
            File f = fileOf(uri);
            MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
            c.addRow(new Object[]{f.getName(), f.length()});
            return c;
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues v) {
        return null;
    }

    @Override
    public int delete(Uri uri, String s, String[] a) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues v, String s, String[] a) {
        return 0;
    }
}
