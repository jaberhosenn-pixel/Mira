package com.markvi.jarvis;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Home-screen widget: one tap opens Mira and starts listening. */
public class MiraWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            try {
                RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_mira);
                Intent i = new Intent(c, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra("assist", true);
                PendingIntent pi = PendingIntent.getActivity(c, 9100 + id, i,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                rv.setOnClickPendingIntent(R.id.widget_root, pi);
                mgr.updateAppWidget(id, rv);
            } catch (Throwable t) {
                DebugLog.add("Widget update failed: " + t);
            }
        }
    }
}
