package com.markvi.jarvis;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The scanner screen: a real (desktop-style) WebView that scrolls the Google Maps result list, opens every place and
 * reads its details, the same way the lead-scraper browser extensions do. Keep the screen on while it runs.
 */
public class MapsScanActivity extends Activity {

    private static final String DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private static final String JS_LIST = "(function(){try{var t=document.body?document.body.innerText.slice(0,3000):'';"
            + "var b=/unusual traffic|not a robot|captcha|Before you continue/i.test(t)?'blocked':'';"
            + "var f=document.querySelector('div[role=\"feed\"]');"
            + "if(!f){return JSON.stringify({feed:false,count:0,end:false,blocked:b,h1:!!document.querySelector('h1')});}"
            + "f.scrollTop=f.scrollHeight;"
            + "var n=f.querySelectorAll('a.hfpxzc, a[href*=\"/maps/place/\"]').length;"
            + "var e=/reached the end of the list|end of the list/i.test(f.innerText);"
            + "return JSON.stringify({feed:true,count:n,end:e,blocked:b,h1:false});}catch(x){return JSON.stringify({feed:false,count:0,end:false,blocked:'',h1:false});}})()";

    private static final String JS_COLLECT = "(function(){var out=[],seen={};"
            + "document.querySelectorAll('div[role=\"feed\"] a.hfpxzc, div[role=\"feed\"] a[href*=\"/maps/place/\"]').forEach(function(a){"
            + "var h=a.href;if(!h||seen[h])return;seen[h]=1;var card=a.closest('.Nv2PK')||a.parentElement;"
            + "out.push({name:(a.getAttribute('aria-label')||'').trim(),href:h,text:card?(card.innerText||'').slice(0,400):''});});"
            + "return JSON.stringify(out);})()";

    private static final String JS_DETAIL = "(function(){try{function q(s){return document.querySelector(s)}"
            + "var h=q('h1');if(!h)return '';var name=(h.innerText||'').trim();if(!name)return '';"
            + "function clean(x){return (x||'').replace(/[\\u200e\\u200f\\ue0c8\\ue0b0\\ue0b1\\ue0b2]/g,'').replace(/^[^:]{2,25}:\\s*/,'').trim();}"
            + "var ad=q('button[data-item-id=\"address\"]');var ph=q('button[data-item-id^=\"phone\"]');var ws=q('a[data-item-id=\"authority\"]');"
            + "var phone='';if(ph){var id=ph.getAttribute('data-item-id')||'';phone=id.indexOf('tel:')>=0?id.split('tel:')[1]:clean(ph.getAttribute('aria-label')||ph.innerText);}"
            + "var cat=q('button.DkEaL')||q('button[jsaction*=\"category\"]');var rt=q('div.F7nice');"
            + "return JSON.stringify({name:name,address:ad?clean(ad.getAttribute('aria-label')||ad.innerText):'',phone:phone,website:ws?ws.href:'',"
            + "category:cat?(cat.innerText||'').trim():'',rating:rt?(rt.innerText||'').replace(/\\s+/g,' ').trim():'',url:location.href});}catch(x){return '';}})()";

    private static final String JS_SERP = "(function(){var t=document.body?document.body.innerText.slice(0,3000):'';"
            + "var b=/unusual traffic|not a robot|captcha|before you continue/i.test(t)||location.href.indexOf('/sorry/')>=0;"
            + "var out=[];document.querySelectorAll('a h3').forEach(function(h){var a=h.closest('a');if(a&&a.href&&a.href.indexOf('http')===0&&a.href.indexOf('google.')<0)"
            + "out.push({title:(h.innerText||'').trim(),url:a.href});});return JSON.stringify({blocked:b,results:out});})()";

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private WebView wv;
    private TextView status;
    private String mode, query;
    private int target;
    private boolean finished;
    private int gen; // bumped on every navigation so old timers die

    // maps state
    private final List<JSONObject> stubs = new ArrayList<>();
    private int idx, lastCount, stable, ticks, noFeed;
    private long detailStart;

    // serp state
    private List<String> urls = new ArrayList<>();
    private int urlIdx;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        mode = getIntent().getStringExtra("mode");
        query = getIntent().getStringExtra("q");
        target = Math.max(5, getIntent().getIntExtra("target", 50));
        ArrayList<String> u = getIntent().getStringArrayListExtra("urls");
        if (u != null) urls = u;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#05080d"));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int p = (int) (10 * getResources().getDisplayMetrics().density);
        bar.setPadding(p, p * 2, p, p);
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(13);
        status.setText("Mira lead scan starting…");
        bar.addView(status, new LinearLayout.LayoutParams(0, -2, 1f));
        Button stop = new Button(this);
        stop.setText("Stop & save");
        stop.setAllCaps(false);
        stop.setOnClickListener(v -> {
            LeadScan.cancelled = true;
            finishScan();
        });
        bar.addView(stop);
        root.addView(bar);

        wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(DESKTOP_UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        wv.setWebViewClient(new WebViewClient());
        root.addView(wv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);

        LeadScan.started = true;
        try {
            if ("serp".equals(mode)) nextSerp();
            else {
                say("Opening Google Maps…");
                go("https://www.google.com/maps/search/" + URLEncoder.encode(query, "UTF-8").replace("+", "%20") + "?hl=en");
                h.postDelayed(this::listTick, 3500);
            }
        } catch (Exception e) {
            fail("could not open Google: " + e.getMessage());
        }
    }

    private void say(String t) {
        LeadScan.progress = t;
        if (status != null) status.setText(t);
    }

    private void go(String url) {
        gen++;
        wv.loadUrl(url);
    }

    private static String unq(String raw) {
        if (raw == null || raw.equals("null")) return "";
        try {
            Object o = new JSONTokener(raw).nextValue();
            return o instanceof String ? (String) o : "";
        } catch (Exception e) {
            return "";
        }
    }

    private void js(String code, final java.util.function.Consumer<String> cb) {
        final int g = gen;
        wv.evaluateJavascript(code, raw -> {
            if (g == gen && !finished) cb.accept(unq(raw));
        });
    }

    // ------------------------------------------------------------------ Google Maps

    private void listTick() {
        if (finished) return;
        ticks++;
        js(JS_LIST, res -> {
            JSONObject o;
            try {
                o = new JSONObject(res);
            } catch (Exception e) {
                o = new JSONObject();
            }
            if (!o.optString("blocked").isEmpty()) {
                LeadScan.blocked = true;
                fail("Google asked for a robot check. Wait a while and try again, or use the Google Search scan.");
                return;
            }
            if (!o.optBoolean("feed")) {
                noFeed++;
                if (noFeed >= 4 && o.optBoolean("h1")) { // Maps jumped straight to one business
                    JSONObject one = J.obj("name", "", "href", wv.getUrl() == null ? "" : wv.getUrl(), "text", "");
                    stubs.add(one);
                    startDetails();
                    return;
                }
                if (noFeed >= 16) {
                    fail("the Google Maps result list did not appear (Google may have changed its page, or there are no results).");
                    return;
                }
                h.postDelayed(this::listTick, 1500);
                return;
            }
            int n = o.optInt("count");
            stable = n == lastCount ? stable + 1 : 0;
            lastCount = n;
            say("Scrolling the results… " + n + " businesses found");
            boolean enough = n >= Math.min(220, Math.round(target * 1.4f) + 5);
            if (o.optBoolean("end") || enough || stable >= 6 || ticks >= 160) {
                collect();
            } else {
                h.postDelayed(this::listTick, 1400);
            }
        });
    }

    private void collect() {
        js(JS_COLLECT, res -> {
            try {
                JSONArray a = new JSONArray(res);
                int max = Math.min(a.length(), Math.max(target, Math.round(target * 1.3f)));
                for (int i = 0; i < max; i++) stubs.add(a.getJSONObject(i));
            } catch (Exception e) {
                DebugLog.add("Maps collect failed: " + e);
            }
            if (stubs.isEmpty()) {
                fail("no businesses could be read from the list.");
                return;
            }
            startDetails();
        });
    }

    private void startDetails() {
        idx = 0;
        openDetail();
    }

    private void openDetail() {
        if (finished) return;
        if (idx >= stubs.size() || LeadScan.cancelled) {
            finishScan();
            return;
        }
        JSONObject st = stubs.get(idx);
        say("Reading business " + (idx + 1) + " of " + stubs.size() + "…");
        detailStart = System.currentTimeMillis();
        String href = st.optString("href");
        if (href.isEmpty()) {
            idx++;
            openDetail();
            return;
        }
        go(href);
        h.postDelayed(this::detailTick, 1800);
    }

    private void detailTick() {
        if (finished) return;
        final long waited = System.currentTimeMillis() - detailStart;
        js(JS_DETAIL, res -> {
            JSONObject d = null;
            try {
                if (!res.isEmpty()) d = new JSONObject(res);
            } catch (Exception ignored) {
            }
            boolean ready = d != null && (!d.optString("address").isEmpty() || !d.optString("phone").isEmpty()
                    || !d.optString("website").isEmpty() || waited > 6500);
            if (ready) {
                recordPlace(d, stubs.get(idx));
                idx++;
                h.postDelayed(this::openDetail, 1200 + rnd.nextInt(1300));
            } else if (waited > 15000) {
                recordPlace(null, stubs.get(idx)); // keep what the list showed
                idx++;
                h.postDelayed(this::openDetail, 800);
            } else {
                h.postDelayed(this::detailTick, 700);
            }
        });
    }

    private static final Pattern RATE = Pattern.compile("(\\d\\.\\d)\\s*\\(?\\s*([\\d,]+)\\s*\\)?");

    private void recordPlace(JSONObject d, JSONObject stub) {
        String name = d != null && !d.optString("name").isEmpty() ? d.optString("name") : stub.optString("name");
        if (name.isEmpty()) return;
        double rating = 0;
        int reviews = 0;
        String rt = d != null ? d.optString("rating") : "";
        Matcher m = RATE.matcher(rt.isEmpty() ? stub.optString("text") : rt);
        if (m.find()) {
            try {
                rating = Double.parseDouble(m.group(1));
                reviews = Integer.parseInt(m.group(2).replace(",", ""));
            } catch (Exception ignored) {
            }
        }
        JSONObject p = J.obj("name", name, "category", d == null ? "" : d.optString("category"),
                "address", d == null ? "" : d.optString("address"), "phone", d == null ? "" : d.optString("phone"),
                "website", d == null ? "" : d.optString("website"), "rating", rating, "reviews", reviews,
                "url", d != null && !d.optString("url").isEmpty() ? d.optString("url") : stub.optString("href"));
        LeadScan.places.add(p);
    }

    // ------------------------------------------------------------------ Google Search

    private void nextSerp() {
        if (finished) return;
        if (urlIdx >= urls.size() || LeadScan.cancelled || LeadScan.blocked) {
            finishScan();
            return;
        }
        say("Google Search page " + (urlIdx + 1) + " of " + urls.size() + "…");
        go(urls.get(urlIdx));
        h.postDelayed(this::serpTick, 2500);
    }

    private int serpTries;

    private void serpTick() {
        if (finished) return;
        js(JS_SERP, res -> {
            try {
                JSONObject o = new JSONObject(res);
                if (o.optBoolean("blocked")) {
                    LeadScan.blocked = true;
                    DebugLog.add("Google Search showed a robot check; stopping Google and using the fallback");
                    finishScan();
                    return;
                }
                JSONArray r = o.optJSONArray("results");
                if ((r == null || r.length() == 0) && serpTries < 3) {
                    serpTries++;
                    h.postDelayed(this::serpTick, 1200);
                    return;
                }
                for (int i = 0; r != null && i < r.length(); i++) LeadScan.serp.put(r.get(i));
            } catch (Exception e) {
                DebugLog.add("serp read failed: " + e);
            }
            serpTries = 0;
            urlIdx++;
            h.postDelayed(this::nextSerp, 2200 + rnd.nextInt(1800));
        });
    }

    // ------------------------------------------------------------------ end

    private void fail(String why) {
        LeadScan.error = why;
        DebugLog.add("Lead scan problem: " + why);
        finishScan();
    }

    private void finishScan() {
        if (finished) return;
        finished = true;
        h.removeCallbacksAndMessages(null);
        if (LeadScan.done != null) LeadScan.done.countDown();
        finish();
    }

    @Override
    public void onBackPressed() {
        LeadScan.cancelled = true;
        finishScan();
    }

    @Override
    protected void onDestroy() {
        finished = true;
        if (LeadScan.done != null) LeadScan.done.countDown();
        try {
            wv.destroy();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }
}
