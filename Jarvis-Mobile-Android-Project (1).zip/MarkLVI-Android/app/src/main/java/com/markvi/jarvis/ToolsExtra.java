package com.markvi.jarvis;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.speech.tts.TextToSpeech;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Inbox reading and replies, driving mode, journal, screen understanding, image creation, nightly backup, find-my-phone. */
public final class ToolsExtra {
    private ToolsExtra() {}

    private static JSONArray load(Context c, String key) {
        try {
            return new JSONArray(Prefs.sp(c).getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static void register() {
        // ---------------------------------------------------------------- notifications: read + reply
        reg("read_notifications",
                "Reads the newest phone notifications (WhatsApp, Messenger, Telegram, SMS, Gmail, banking...). Use for 'what are my messages', 'any new message from X'. "
                        + "Read them to the user briefly: who, which app, what it says. Optional app and sender filters.",
                schema("", "app:STRING:only this app, e.g. WhatsApp", "sender:STRING:only this sender", "count:INTEGER:how many, default 6"),
                (c, a) -> {
                    if (!NotifCatcher.hasAccess(c)) {
                        return J.fail("Notification access is OFF. Tell the user: Settings > Open All Permissions > Notification access > turn Mira on.");
                    }
                    String app = a.optString("app").toLowerCase(Locale.ROOT).trim();
                    String snd = a.optString("sender").toLowerCase(Locale.ROOT).trim();
                    int n = Math.max(1, Math.min(15, a.optInt("count", 6)));
                    JSONArray out = new JSONArray();
                    SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.US);
                    for (NotifCatcher.Entry e : NotifCatcher.entries()) {
                        if (out.length() >= n) break;
                        if (!app.isEmpty() && !e.app.toLowerCase(Locale.ROOT).contains(app)) continue;
                        if (!snd.isEmpty() && !e.sender.toLowerCase(Locale.ROOT).contains(snd)) continue;
                        out.put(J.obj("app", e.app, "from", e.sender, "text", e.text, "time", f.format(new Date(e.time)),
                                "can_reply", e.reply != null));
                    }
                    return out.length() == 0 ? J.ok("note", "no matching notifications right now", "notifications", out)
                            : J.ok("count", out.length(), "notifications", out);
                });

        reg("reply_notification",
                "Replies to a message notification straight from the notification's reply box (WhatsApp, Messenger, Telegram, SMS apps) without opening the app. "
                        + "sender = the person's name as shown in the notification. Write the reply in the user's own words and language. Say the reply back before sending when the user asked for a draft.",
                schema("sender,text", "sender:STRING:name of the person who messaged", "text:STRING:the reply"),
                (c, a) -> {
                    if (!NotifCatcher.hasAccess(c)) return J.fail("Notification access is OFF.");
                    String snd = Util.collapseSpelled(a.optString("sender")).toLowerCase(Locale.ROOT).trim();
                    String text = a.optString("text").trim();
                    if (snd.isEmpty() || text.isEmpty()) return J.fail("sender and text are required");
                    NotifCatcher.Entry hit = null, noReply = null;
                    for (NotifCatcher.Entry e : NotifCatcher.entries()) {
                        if (!e.sender.toLowerCase(Locale.ROOT).contains(snd)) continue;
                        if (e.reply != null) {
                            hit = e;
                            break;
                        }
                        if (noReply == null) noReply = e;
                    }
                    if (hit == null) {
                        return J.fail(noReply != null
                                ? "that notification has no reply box; use send_message instead"
                                : "no recent notification from '" + a.optString("sender") + "'");
                    }
                    Intent fill = new Intent();
                    Bundle b = new Bundle();
                    for (android.app.RemoteInput ri : hit.inputs) b.putCharSequence(ri.getResultKey(), text);
                    android.app.RemoteInput.addResultsToIntent(hit.inputs, fill, b);
                    hit.reply.actionIntent.send(c, 0, fill);
                    return J.obj("status", "unverified", "note", "reply handed to " + hit.app + "; nobody can confirm it arrived");
                });

        // ---------------------------------------------------------------- driving mode
        reg("driving_mode",
                "Turns Driving mode on or off. On: hands-free, wake word kept listening, new messages are read aloud, answers stay very short. Use when the user says they are driving / riding.",
                schema("on", "on:BOOLEAN:true to turn on, false to turn off"),
                (c, a) -> {
                    boolean on = a.optBoolean("on", true);
                    Prefs.sp(c).edit().putBoolean("driving", on).apply();
                    try {
                        if (on && !Prefs.sp(c).getBoolean("wake_enabled", false)) {
                            Prefs.sp(c).edit().putBoolean("driving_started_wake", true).apply();
                            c.startForegroundService(new Intent(c, JarvisService.class).setAction(JarvisService.ACTION_WAKE_ON));
                        } else if (!on && Prefs.sp(c).getBoolean("driving_started_wake", false)) {
                            Prefs.sp(c).edit().putBoolean("driving_started_wake", false).apply();
                            c.startService(new Intent(c, JarvisService.class).setAction(JarvisService.ACTION_WAKE_OFF));
                        }
                    } catch (Throwable t) {
                        DebugLog.add("Driving mode wake word: " + t);
                    }
                    return J.ok("driving", on, "note", on ? "messages will be read aloud; keep answers very short" : "driving mode off");
                });

        // ---------------------------------------------------------------- journal
        reg("journal_add",
                "Adds an entry to the user's daily journal (diary) with today's date. Use when the user dictates how their day went or says 'write in my diary'.",
                schema("text", "text:STRING:the diary text in the user's words"),
                (c, a) -> {
                    JSONArray all = load(c, "journal");
                    all.put(J.obj("d", new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()), "t", System.currentTimeMillis(), "text", a.optString("text")));
                    while (all.length() > 800) all.remove(0);
                    Prefs.sp(c).edit().putString("journal", all.toString()).apply();
                    return J.ok("saved", all.length());
                });

        reg("journal_read",
                "Reads back diary entries. days_ago=0 is today, 1 is yesterday. query filters by word. Summarise them for the user if they ask.",
                schema("", "days_ago:INTEGER:0 today, 1 yesterday", "query:STRING:word to look for", "days:INTEGER:how many days to include, default 1"),
                (c, a) -> {
                    JSONArray all = load(c, "journal"), out = new JSONArray();
                    String q = a.optString("query").toLowerCase(Locale.ROOT).trim();
                    int ago = Math.max(0, a.optInt("days_ago", 0)), span = Math.max(1, Math.min(60, a.optInt("days", 1)));
                    Calendar cal = Calendar.getInstance();
                    cal.add(Calendar.DAY_OF_YEAR, -ago);
                    String newest = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
                    cal.add(Calendar.DAY_OF_YEAR, -(span - 1));
                    String oldest = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
                    for (int i = 0; i < all.length(); i++) {
                        JSONObject e = all.optJSONObject(i);
                        if (e == null) continue;
                        String d = e.optString("d");
                        if (q.isEmpty() ? (d.compareTo(oldest) < 0 || d.compareTo(newest) > 0) : false) continue;
                        if (!q.isEmpty() && !e.optString("text").toLowerCase(Locale.ROOT).contains(q)) continue;
                        out.put(d + ": " + e.optString("text"));
                    }
                    return J.ok("count", out.length(), "entries", out);
                });

        // ---------------------------------------------------------------- understand the screen
        reg("explain_screen",
                "Looks at what is on the phone screen right now and answers a question about it: explain it, translate it, summarise it, read it out. "
                        + "Use for 'what is on my screen', 'translate this', 'explain this message'. question is what the user wants to know.",
                schema("", "question:STRING:what the user wants to know about the screen"),
                (c, a) -> {
                    JarvisAccessibility acc = JarvisAccessibility.get();
                    if (acc == null) return J.fail("Accessibility is OFF, so Mira cannot see the screen. Settings > Open All Permissions > Accessibility.");
                    byte[] jpg = acc.screenshotJpeg();
                    if (jpg == null || jpg.length == 0) return J.fail("could not take a screenshot of the screen");
                    String q = a.optString("question").trim();
                    if (q.isEmpty()) q = "Explain briefly what is on this screen.";
                    String ans = GeminiRest.generateMedia(c,
                            "This is a screenshot of the user's phone. Answer in the same language as the question (Bangla, English or Banglish), briefly, "
                                    + "in plain sentences that are easy to say out loud. Only use what is visible. Question: " + q,
                            false, jpg, "image/jpeg", null);
                    return J.ok("answer", ans);
                });

        // ---------------------------------------------------------------- image creation
        reg("generate_image",
                "Creates a picture from a description (poster, Facebook post image, logo idea, illustration) with Gemini and saves it as PNG in Downloads. "
                        + "Write the prompt in English with the details the user gave. Tell the user the file name when done.",
                schema("prompt", "prompt:STRING:detailed description of the image", "name:STRING:short file name, optional"),
                (c, a) -> generateImage(c, a.optString("prompt").trim(), a.optString("name").trim()));

        // ---------------------------------------------------------------- nightly backup
        reg("auto_backup",
                "Sets, shows or stops the automatic backup that saves Mira's settings and memories to Downloads every night. time is 24h HH:mm; action off stops it.",
                schema("", "time:STRING:24h time like 02:00", "action:STRING:on | off | status"),
                (c, a) -> {
                    String act = a.optString("action", "on").toLowerCase(Locale.ROOT);
                    if (act.equals("status")) {
                        String t = Prefs.sp(c).getString("autobackup", "");
                        return J.ok("auto_backup", t.isEmpty() ? "off" : "every night at " + t);
                    }
                    if (act.equals("off")) {
                        Prefs.sp(c).edit().remove("autobackup").apply();
                        cancelBackup(c);
                        return J.ok("auto_backup", "off");
                    }
                    String time = a.optString("time", "02:00").trim();
                    if (!time.matches("\\d{1,2}:\\d{2}")) return J.fail("time must look like 02:00");
                    Prefs.sp(c).edit().putString("autobackup", time).apply();
                    scheduleBackup(c);
                    return J.ok("auto_backup", "every night at " + time, "note", "file Mira-backup-DATE.json appears in Downloads");
                });

        // ---------------------------------------------------------------- find my phone
        reg("set_find_phone_code",
                "Sets the secret code for Find My Phone. When an SMS that starts with this code reaches the phone, it rings loudly for a minute and texts back its location. "
                        + "The code must be at least 6 characters; the user chooses it. Never say it back unless they ask.",
                schema("code", "code:STRING:secret code, at least 6 characters, no spaces"),
                (c, a) -> {
                    String code = a.optString("code").trim();
                    if (code.length() < 6 || code.contains(" ")) return J.fail("the code needs at least 6 characters and no spaces");
                    Prefs.sp(c).edit().putString("find_code", code).apply();
                    boolean smsOk = c.checkSelfPermission(android.Manifest.permission.RECEIVE_SMS) == android.content.pm.PackageManager.PERMISSION_GRANTED;
                    return J.ok("saved", true, "receive_sms_permission", smsOk,
                            "note", smsOk ? "send the code from another phone by SMS to make this phone ring"
                                    : "SMS receive permission is missing: Settings > Open All Permissions > Find my phone");
                });

        reg("find_phone_stop",
                "Stops the Find My Phone ringing.",
                schema(""),
                (c, a) -> {
                    FindPhone.stop();
                    return J.ok();
                });
    }

    // ------------------------------------------------------------------ driving: read a new message aloud

    private static TextToSpeech tts;
    private static boolean ttsReady;

    static void driveAnnounce(final Context c, final String sender, final String text, final String app) {
        try {
            JarvisService s = JarvisService.get();
            if (s != null && s.isLive()) {
                s.alert("New " + app + " message from " + sender + ": " + text
                        + ". Tell the user briefly, then ask if they want to reply. Keep it very short.");
                return;
            }
            final boolean bn = text.matches("(?s).*[\\u0980-\\u09FF].*");
            final String say = bn ? sender + " লিখেছেন: " + text : sender + " says: " + text;
            if (tts == null) {
                tts = new TextToSpeech(c.getApplicationContext(), status -> {
                    ttsReady = status == TextToSpeech.SUCCESS;
                    if (ttsReady) speak(say, bn);
                });
            } else if (ttsReady) {
                speak(say, bn);
            }
        } catch (Throwable t) {
            DebugLog.add("Driving announce failed: " + t);
        }
    }

    private static void speak(String say, boolean bn) {
        try {
            Locale l = bn ? new Locale("bn", "BD") : Locale.getDefault();
            if (tts.isLanguageAvailable(l) < TextToSpeech.LANG_AVAILABLE) l = Locale.getDefault();
            tts.setLanguage(l);
            tts.speak(say.length() > 280 ? say.substring(0, 280) : say, TextToSpeech.QUEUE_ADD, null, "mira-drive");
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ image generation

    private static JSONObject generateImage(Context c, String prompt, String name) throws Exception {
        if (prompt.isEmpty()) return J.fail("prompt is empty");
        String key = Prefs.apiKey(c);
        if (key.isEmpty()) return J.fail("No Gemini API key set. Open Settings and paste one.");
        String model = Prefs.sp(c).getString("image_model", "gemini-2.5-flash-image");
        JSONObject body = J.obj("contents", J.arr(J.obj("parts", J.arr(J.obj("text", prompt)))),
                "generationConfig", J.obj("responseModalities", J.arr("TEXT", "IMAGE")));
        Request req = new Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + key)
                .post(RequestBody.create(body.toString(), MediaType.parse("application/json; charset=utf-8"))).build();
        String txt;
        try (Response r = GeminiRest.HTTP.newCall(req).execute()) {
            txt = r.body() == null ? "" : r.body().string();
            if (!r.isSuccessful()) {
                String hint = r.code() == 429 ? " (the free image quota is used up for now; try later or use a billed key)"
                        : r.code() == 404 ? " (this image model is not available for the key)" : "";
                return J.fail("image service said HTTP " + r.code() + hint + ": " + GeminiRest.abbreviate(txt, 160));
            }
        }
        JSONArray cands = J.parse(txt).optJSONArray("candidates");
        if (cands == null || cands.length() == 0) return J.fail("the image service returned nothing (the prompt may have been blocked)");
        JSONObject content = cands.getJSONObject(0).optJSONObject("content");
        JSONArray parts = content == null ? null : content.optJSONArray("parts");
        if (parts != null) {
            for (int i = 0; i < parts.length(); i++) {
                JSONObject p = parts.getJSONObject(i);
                JSONObject inl = p.optJSONObject("inlineData");
                if (inl == null) inl = p.optJSONObject("inline_data");
                if (inl == null) continue;
                byte[] png = android.util.Base64.decode(inl.optString("data"), android.util.Base64.DEFAULT);
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();
                String base = name.isEmpty() ? "Mira-image" : name.replaceAll("[^A-Za-z0-9_-]+", "_");
                File f = new File(dir, base + "-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + ".png");
                try (FileOutputStream o = new FileOutputStream(f)) {
                    o.write(png);
                }
                return J.ok("saved_to", f.getAbsolutePath(), "file", f.getName());
            }
        }
        return J.fail("the model answered with text only and no picture; try describing the image more clearly");
    }

    // ------------------------------------------------------------------ nightly backup alarm

    static void scheduleBackup(Context c) {
        try {
            String t = Prefs.sp(c).getString("autobackup", "");
            if (t.isEmpty()) return;
            String[] p = t.split(":");
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(p[0]));
            cal.set(Calendar.MINUTE, Integer.parseInt(p[1]));
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() < System.currentTimeMillis() + 30000L) cal.add(Calendar.DAY_OF_YEAR, 1);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pi = PendingIntent.getBroadcast(c, 7731, new Intent(c, AutoBackupReceiver.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            try {
                if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
                }
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            }
        } catch (Throwable t) {
            DebugLog.add("Backup schedule failed: " + t);
        }
    }

    static void cancelBackup(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.cancel(PendingIntent.getBroadcast(c, 7731, new Intent(c, AutoBackupReceiver.class),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        } catch (Throwable ignored) {
        }
    }

    /** The newest copy of the page's localStorage that the Mira screen handed over (expenses, memories...). */
    static String cachedLocal(Context c) {
        try {
            File f = new File(c.getFilesDir(), "local_cache.json");
            if (!f.exists()) return "";
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            }
            return bo.toString("UTF-8");
        } catch (Throwable t) {
            return "";
        }
    }
}
