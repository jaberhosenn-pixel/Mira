package com.markvi.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;

/** Remembers the state of the phone call so Mira can say who is calling and answer or decline on command. It never acts by itself. */
public class CallReceiver extends BroadcastReceiver {
    public static volatile String state = TelephonyManager.EXTRA_STATE_IDLE;
    public static volatile String number = "";
    public static volatile long ringTime = 0;

    @Override
    public void onReceive(Context c, Intent i) {
        String st = i.getStringExtra(TelephonyManager.EXTRA_STATE);
        if (st == null) return;
        state = st;
        String n = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
        if (TelephonyManager.EXTRA_STATE_RINGING.equals(st)) {
            if (System.currentTimeMillis() - ringTime > 60000) number = "";
            ringTime = System.currentTimeMillis();
            if (n != null && !n.isEmpty()) number = n;
        }
    }
}
