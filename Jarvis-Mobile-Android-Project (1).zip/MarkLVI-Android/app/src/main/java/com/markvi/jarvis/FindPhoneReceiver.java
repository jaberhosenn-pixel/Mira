package com.markvi.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.provider.Telephony;
import android.telephony.SmsMessage;

/** An SMS that starts with the user's secret code makes the phone ring and text back where it is. "<code> stop" stops it. */
public class FindPhoneReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            String code = Prefs.sp(c).getString("find_code", "");
            if (code.length() < 6) return;
            SmsMessage[] msgs = Telephony.Sms.Intents.getMessagesFromIntent(i);
            if (msgs == null || msgs.length == 0) return;
            StringBuilder body = new StringBuilder();
            String from = msgs[0].getOriginatingAddress();
            for (SmsMessage m : msgs) body.append(m.getMessageBody());
            String text = body.toString().trim();
            if (!text.startsWith(code)) return;
            if (text.substring(code.length()).trim().equalsIgnoreCase("stop")) {
                FindPhone.stop();
                return;
            }
            DebugLog.add("Find phone: code received, ringing");
            FindPhone.start(c);
            if (from != null && !from.isEmpty()) replyWithLocation(c, from);
        } catch (Throwable t) {
            DebugLog.add("Find phone receiver failed: " + t);
        }
    }

    private void replyWithLocation(Context c, String to) {
        String where = "location not available";
        try {
            double[] p = EarthTools.userPos(c);
            if (p != null) where = "https://maps.google.com/?q=" + p[0] + "," + p[1];
        } catch (Throwable ignored) {
        }
        try {
            android.telephony.SmsManager sm = Build.VERSION.SDK_INT >= 31
                    ? c.getSystemService(android.telephony.SmsManager.class) : android.telephony.SmsManager.getDefault();
            String msg = "Mira: this phone is ringing now. Last known location: " + where + ". Send your code + stop to stop it.";
            sm.sendMultipartTextMessage(to, null, sm.divideMessage(msg), null, null);
        } catch (Throwable t) {
            DebugLog.add("Find phone reply failed: " + t);
        }
    }
}
