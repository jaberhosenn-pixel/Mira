package com.markvi.jarvis;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.EnumMap;
import java.util.Map;

/**
 * Takes one photo with the phone's camera app, then reads a QR code / barcode (ZXing) and/or printed text (Tesseract,
 * Bengali + English, no internet) from it. The photo is deleted afterwards.
 */
public class ScanActivity extends Activity {
    private Uri photo;
    private String kind = "auto";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        kind = getIntent().getStringExtra("kind") == null ? "auto" : getIntent().getStringExtra("kind");
        if (b != null && b.getString("photo") != null) { photo = Uri.parse(b.getString("photo")); return; }
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "mira_scan_" + System.currentTimeMillis() + ".jpg");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            photo = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, photo);
            startActivityForResult(i, 77);
        } catch (Throwable t) {
            DebugLog.add("Scan: camera failed " + t);
            Toast.makeText(this, "Camera could not open. Allow the Camera permission for Mira.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        if (photo != null) o.putString("photo", photo.toString());
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        final Uri p = photo;
        if (req != 77 || res != RESULT_OK || p == null) {
            deletePhoto(p);
            finish();
            return;
        }
        Toast.makeText(this, "Reading…", Toast.LENGTH_SHORT).show();
        final String k = kind;
        new Thread(() -> {
            String out;
            try {
                Bitmap bmp = load(p);
                if (bmp == null) out = "[SCAN RESULT] The photo could not be opened.";
                else out = scan(getApplicationContext(), bmp, k);
            } catch (Throwable t) {
                DebugLog.add("Scan failed: " + t);
                out = "[SCAN RESULT] Reading failed: " + t.getMessage();
            }
            deletePhoto(p);
            deliver(getApplicationContext(), out);
            runOnUiThread(this::finish);
        }, "mira-scan").start();
    }

    private void deletePhoto(Uri p) {
        try { if (p != null) getContentResolver().delete(p, null, null); } catch (Throwable ignored) { }
    }

    private Bitmap load(Uri u) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / s > 2400) s *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = s;
        Bitmap b;
        try (InputStream in = getContentResolver().openInputStream(u)) { b = BitmapFactory.decodeStream(in, null, o); }
        if (b == null) return null;
        int rot = 0;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            android.media.ExifInterface ex = new android.media.ExifInterface(in);
            int or = ex.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1);
            rot = or == 6 ? 90 : or == 3 ? 180 : or == 8 ? 270 : 0;
        } catch (Throwable ignored) { }
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            b = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
        }
        return b;
    }

    static String scan(android.content.Context ctx, Bitmap bmp, String kind) {
        StringBuilder sb = new StringBuilder("[SCAN RESULT] ");
        if (!kind.equals("text")) {
            String code = readCode(bmp);
            if (code != null) {
                sb.append("QR/barcode: ").append(code);
                if (code.matches("(?i)^(https?://|www\\.).*")) sb.append("\n(Say it is a link. Do not open it unless the user asks; warn if it looks suspicious.)");
                return sb.toString();
            }
            if (kind.equals("code")) return sb.append("No QR code or barcode found. Hold the code flat, bright and fill the frame.").toString();
        }
        String text = ocr(ctx, bmp);
        if (text == null) return sb.append("Text reading is not available on this phone.").toString();
        text = text.trim();
        if (text.length() < 3) return sb.append("No readable text found. Try better light and hold the page flat.").toString();
        return sb.append("Text read from the photo (may contain mistakes, especially Bengali):\n").append(text).toString();
    }

    private static String readCode(Bitmap src) {
        try {
            Bitmap b = src;
            if (Math.max(b.getWidth(), b.getHeight()) > 1400) {
                float f = 1400f / Math.max(b.getWidth(), b.getHeight());
                b = Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * f), Math.round(b.getHeight() * f), true);
            }
            int w = b.getWidth(), h = b.getHeight();
            int[] px = new int[w * h];
            b.getPixels(px, 0, w, 0, 0, w, h);
            Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
            hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
            MultiFormatReader r = new MultiFormatReader();
            r.setHints(hints);
            RGBLuminanceSource ls = new RGBLuminanceSource(w, h, px);
            try {
                Result res = r.decodeWithState(new BinaryBitmap(new HybridBinarizer(ls)));
                return res.getText();
            } catch (Exception e) {
                Result res = r.decodeWithState(new BinaryBitmap(new HybridBinarizer(ls.invert())));
                return res.getText();
            }
        } catch (Throwable t) {
            return null;
        }
    }

    /** Tesseract through reflection, so a library version difference can never break the build. */
    private static String ocr(android.content.Context ctx, Bitmap b) {
        Object api = null;
        try {
            File base = new File(ctx.getFilesDir(), "tess");
            File td = new File(base, "tessdata");
            td.mkdirs();
            for (String n : new String[]{"ben.traineddata", "eng.traineddata"}) {
                File f = new File(td, n);
                if (f.length() > 100000) continue;
                try (InputStream in = ctx.getAssets().open("tessdata/" + n); OutputStream out = new FileOutputStream(f)) {
                    byte[] buf = new byte[1 << 16];
                    int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                }
            }
            Class<?> c = Class.forName("com.googlecode.tesseract.android.TessBaseAPI");
            api = c.getConstructor().newInstance();
            Object ok = c.getMethod("init", String.class, String.class).invoke(api, base.getAbsolutePath(), "ben+eng");
            if (ok instanceof Boolean && !((Boolean) ok)) return null;
            Bitmap s = b;
            if (Math.max(b.getWidth(), b.getHeight()) > 2000) {
                float f = 2000f / Math.max(b.getWidth(), b.getHeight());
                s = Bitmap.createScaledBitmap(b, Math.round(b.getWidth() * f), Math.round(b.getHeight() * f), true);
            }
            c.getMethod("setImage", Bitmap.class).invoke(api, s);
            Object t = c.getMethod("getUTF8Text").invoke(api);
            return t == null ? "" : t.toString();
        } catch (Throwable t) {
            DebugLog.add("OCR failed: " + t);
            return null;
        } finally {
            try {
                if (api != null) {
                    try { api.getClass().getMethod("recycle").invoke(api); }
                    catch (NoSuchMethodException e) { api.getClass().getMethod("end").invoke(api); }
                }
            } catch (Throwable ignored) { }
        }
    }

    /** Gives the result to the live Gemini session, the offline voice, and the screen. */
    static void deliver(android.content.Context c, String text) {
        try {
            Bus.Ui u = Bus.ui;
            if (u != null) u.onAssistantText(text.replace("[SCAN RESULT] ", ""), true);
            JarvisService js = JarvisService.get();
            if (js != null && js.isLive()) {
                js.sendText(text + "\nRead this result to the user briefly, in their language.");
                return;
            }
            if (OfflineMira.isActive()) { OfflineMira.announce(text.replace("[SCAN RESULT] ", "")); return; }
            Util.notifyAlertResult(c, 4242, "Mira scan", text.replace("[SCAN RESULT] ", ""));
        } catch (Throwable t) {
            DebugLog.add("Scan deliver: " + t);
        }
    }
}
