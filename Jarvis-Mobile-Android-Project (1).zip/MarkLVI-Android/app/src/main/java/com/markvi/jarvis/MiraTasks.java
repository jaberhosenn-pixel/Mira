package com.markvi.jarvis;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/**
 * Scheduled Mira tasks: at a time (every day, on chosen weekdays, or on a day of the month) Mira runs a safe, read-only job
 * (weather, today's calendar, new email, notification digest, expenses, missed calls, news) or shows a plain message,
 * and posts the result as a notification with Snooze / Done buttons. A job that cannot run says so in a notification.
 * Only tasks the user created run, and none of the jobs sends, deletes or buys anything.
 */
final class MiraTasks {
    private MiraTasks() {}

    static final String KEY = "mira_tasks";
    static final String ACT_RUN = "com.markvi.jarvis.TASK_RUN";
    static final String ACT_SNOOZE = "com.markvi.jarvis.TASK_SNOOZE";
    static final String ACT_DONE = "com.markvi.jarvis.TASK_DONE";

    /** kind -> label. The tool each one runs is fixed below (read-only on purpose). */
    static final String[][] PRESETS = {
            {"text", "Plain reminder message"},
            {"weather", "Weather (arg: city)"},
            {"calendar", "My calendar (arg: days ahead, default 1)"},
            {"email", "New emails"},
            {"notifications", "Notification digest (what I missed)"},
            {"expenses", "This month's expenses"},
            {"missed_calls", "Missed calls"},
            {"news", "News (arg: bbc / prothomalo)"}
    };

    static void register() {
        reg("task_add",
                "Creates a SCHEDULED TASK: at a time Mira runs a job and sends the result as a notification. kind = text | weather | calendar | email | notifications | expenses | missed_calls | news. "
                        + "arg = city for weather, days for calendar, source for news, or the message for text. days = daily (default) or weekdays like 'mon,thu' (sat,sun,mon,tue,wed,thu,fri). "
                        + "day_of_month = 1..31 for a monthly task. time = HH:mm 24h. Only when the user asks.",
                schema("name,time,kind", "name:STRING:short title", "time:STRING:HH:mm 24-hour", "kind:STRING:job kind", "arg:STRING:optional argument",
                        "days:STRING:daily or mon,tue,...", "day_of_month:INTEGER:1-31 for monthly"),
                (c, a) -> add(c, a));
        reg("task_list", "Lists the scheduled tasks with their next run and last result.", schema(""), (c, a) -> J.ok("tasks", list(c)));
        reg("task_remove", "Deletes a scheduled task by id or by a word from its name.", schema("which", "which:STRING:id or part of the name"), (c, a) -> remove(c, a.optString("which")));
        reg("task_toggle", "Turns a scheduled task on or off.", schema("which,on", "which:STRING:id or part of the name", "on:BOOLEAN:true = on"), (c, a) -> toggle(c, a.optString("which"), a.optBoolean("on", true)));
        reg("task_run_now", "Runs a scheduled task right now to test it.", schema("which", "which:STRING:id or part of the name"), (c, a) -> runNow(c, a.optString("which")));
    }

    // ------------------------------------------------------------------ storage

    static JSONArray list(Context c) {
        try {
            return new JSONArray(Prefs.sp(c).getString(KEY, "[]"));
        } catch (Throwable t) {
            return new JSONArray();
        }
    }

    private static void save(Context c, JSONArray a) {
        Prefs.sp(c).edit().putString(KEY, a.toString()).apply();
    }

    private static JSONObject find(JSONArray all, String which) {
        String w = which == null ? "" : which.toLowerCase(Locale.ROOT).trim();
        if (w.isEmpty()) return null;
        for (int i = 0; i < all.length(); i++) {
            JSONObject t = all.optJSONObject(i);
            if (t != null && (String.valueOf(t.optInt("id")).equals(w) || t.optString("name").toLowerCase(Locale.ROOT).contains(w))) return t;
        }
        return null;
    }

    // ------------------------------------------------------------------ create / edit

    /** Used by the tool and by the Settings page. Returns the saved task or a failure. */
    static JSONObject add(Context c, JSONObject a) {
        try {
            String name = a.optString("name").trim();
            String time = a.optString("time").trim();
            String kind = a.optString("kind", "text").trim().toLowerCase(Locale.ROOT);
            if (name.isEmpty()) return J.fail("name is required");
            if (!time.matches("\\d{1,2}:\\d{2}")) return J.fail("time must look like 08:00");
            String[] hm = time.split(":");
            if (Integer.parseInt(hm[0]) > 23 || Integer.parseInt(hm[1]) > 59) return J.fail("time must be a real 24-hour time");
            boolean known = false;
            for (String[] p : PRESETS) if (p[0].equals(kind)) known = true;
            if (!known) return J.fail("unknown kind '" + kind + "'");
            int dom = a.optInt("day_of_month", 0);
            if (dom < 0 || dom > 31) return J.fail("day_of_month must be 1-31");
            JSONArray days = parseDays(a.opt("days"));
            JSONArray all = list(c);
            if (all.length() >= 30) return J.fail("too many scheduled tasks (30); remove one first");
            int id = a.optInt("id", 0);
            JSONObject t = null;
            if (id != 0) for (int i = 0; i < all.length(); i++) if (all.optJSONObject(i) != null && all.optJSONObject(i).optInt("id") == id) t = all.optJSONObject(i);
            if (t == null) {
                id = 1100000000 + (int) (System.currentTimeMillis() % 800000000L);
                t = new JSONObject();
                t.put("id", id);
                all.put(t);
            }
            t.put("name", name);
            t.put("time", String.format(Locale.US, "%02d:%s", Integer.parseInt(hm[0]), hm[1]));
            t.put("kind", kind);
            t.put("arg", a.optString("arg").trim());
            t.put("days", days);
            t.put("dom", dom);
            t.put("on", a.optBoolean("on", true));
            save(c, all);
            arm(c, t);
            return J.ok("id", id, "next_run", nextText(t));
        } catch (Throwable e) {
            return J.fail("could not save the task: " + e.getMessage());
        }
    }

    private static JSONArray parseDays(Object o) {
        JSONArray out = new JSONArray();
        Set<Integer> set = new HashSet<>();
        String[] names = {"sun", "mon", "tue", "wed", "thu", "fri", "sat"};
        if (o instanceof JSONArray) {
            JSONArray ja = (JSONArray) o;
            for (int i = 0; i < ja.length(); i++) {
                int d = ja.optInt(i, 0);
                if (d >= 1 && d <= 7) set.add(d);
            }
        } else if (o != null) {
            String s = String.valueOf(o).toLowerCase(Locale.ROOT);
            if (!s.contains("daily") && !s.contains("every")) {
                for (int i = 0; i < 7; i++) if (s.contains(names[i])) set.add(i + 1);
            }
        }
        if (set.size() < 7) for (int d = 1; d <= 7; d++) if (set.contains(d)) out.put(d);
        return out; // empty = every day
    }

    static JSONObject remove(Context c, String which) {
        JSONArray all = list(c);
        JSONObject t = find(all, which);
        if (t == null) return J.fail("no scheduled task matched");
        JSONArray keep = new JSONArray();
        for (int i = 0; i < all.length(); i++) if (all.optJSONObject(i) != t) keep.put(all.opt(i));
        save(c, keep);
        cancel(c, t.optInt("id"));
        return J.ok("removed", t.optString("name"));
    }

    static JSONObject toggle(Context c, String which, boolean on) {
        try {
            JSONArray all = list(c);
            JSONObject t = find(all, which);
            if (t == null) return J.fail("no scheduled task matched");
            t.put("on", on);
            save(c, all);
            if (on) arm(c, t); else cancel(c, t.optInt("id"));
            return J.ok("task", t.optString("name"), "on", on);
        } catch (Throwable e) {
            return J.fail(String.valueOf(e.getMessage()));
        }
    }

    static JSONObject runNow(Context c, String which) {
        JSONObject t = find(list(c), which);
        if (t == null) return J.fail("no scheduled task matched");
        final Context app = c.getApplicationContext();
        final int id = t.optInt("id");
        new Thread(() -> execute(app, id, true), "mira-task-now").start();
        return J.started("note", "running now; the result arrives as a notification");
    }

    // ------------------------------------------------------------------ alarms

    static long nextTrigger(JSONObject t, long after) {
        String[] hm = t.optString("time", "08:00").split(":");
        JSONArray days = t.optJSONArray("days");
        int dom = t.optInt("dom", 0);
        Set<Integer> ds = new HashSet<>();
        for (int i = 0; days != null && i < days.length(); i++) ds.add(days.optInt(i));
        for (int off = 0; off <= 400; off++) {
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(after);
            cal.add(Calendar.DAY_OF_YEAR, off);
            cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hm[0]));
            cal.set(Calendar.MINUTE, Integer.parseInt(hm[1]));
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.getTimeInMillis() <= after + 1000) continue;
            if (!ds.isEmpty() && !ds.contains(cal.get(Calendar.DAY_OF_WEEK))) continue;
            if (dom > 0 && cal.get(Calendar.DAY_OF_MONTH) != dom) continue;
            return cal.getTimeInMillis();
        }
        return after + 24L * 3600 * 1000;
    }

    private static String nextText(JSONObject t) {
        return new java.text.SimpleDateFormat("EEE d MMM HH:mm", Locale.US).format(new java.util.Date(nextTrigger(t, System.currentTimeMillis())));
    }

    private static PendingIntent pi(Context c, int id, String action, int extraMinutes) {
        Intent i = new Intent(c, TaskReceiver.class).setAction(action).putExtra("id", id).putExtra("snooze_min", extraMinutes);
        return PendingIntent.getBroadcast(c, id + (action.equals(ACT_RUN) ? 0 : action.equals(ACT_SNOOZE) ? 1 : 2), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void arm(Context c, JSONObject t) {
        try {
            if (!t.optBoolean("on", true)) return;
            setAlarm(c, nextTrigger(t, System.currentTimeMillis()), pi(c, t.optInt("id") * 3 % 2000000000 + 0, ACT_RUN, 0), t.optInt("id"));
        } catch (Throwable e) {
            DebugLog.add("Task arm failed: " + e);
        }
    }

    private static void setAlarm(Context c, long when, PendingIntent p, int id) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, p);
        }
    }

    static void cancel(Context c, int id) {
        try {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi(c, id * 3 % 2000000000, ACT_RUN, 0));
        } catch (Throwable ignored) {
        }
    }

    /** After a phone restart or app update. */
    static void rearm(Context c) {
        JSONArray all = list(c);
        for (int i = 0; i < all.length(); i++) {
            JSONObject t = all.optJSONObject(i);
            if (t != null) arm(c, t);
        }
    }

    // ------------------------------------------------------------------ running

    /** Runs one task and posts its notification. fromSchedule=false re-arms nothing; fromSchedule=true (the alarm) plans the next run first. */
    static void execute(Context c, int id, boolean manual) {
        JSONArray all = list(c);
        JSONObject t = null;
        for (int i = 0; i < all.length(); i++) if (all.optJSONObject(i) != null && all.optJSONObject(i).optInt("id") == id) t = all.optJSONObject(i);
        if (t == null) return;
        if (!manual) arm(c, t); // plan the next one first so a failure never stops the schedule
        String name = t.optString("name", "Mira task");
        String body;
        boolean ok = true;
        try {
            String kind = t.optString("kind"), arg = t.optString("arg");
            if (kind.equals("text")) {
                body = arg.isEmpty() ? name : arg;
            } else {
                JSONObject r = runJob(c, kind, arg);
                if (r == null || "failed".equals(r.optString("status"))) {
                    ok = false;
                    body = "Could not run: " + (r == null ? "no result" : r.optString("error", "unknown reason")) + ". It will try again at the next scheduled time.";
                } else {
                    body = summarize(c, name, r);
                }
            }
        } catch (Throwable e) {
            ok = false;
            body = "Could not run: " + e.getMessage();
        }
        try {
            t.put("last", J.obj("t", System.currentTimeMillis(), "ok", ok, "text", body.length() > 300 ? body.substring(0, 300) : body));
            JSONArray fresh = list(c);
            for (int i = 0; i < fresh.length(); i++) if (fresh.optJSONObject(i) != null && fresh.optJSONObject(i).optInt("id") == id) fresh.put(i, t);
            save(c, fresh);
        } catch (Throwable ignored) {
        }
        post(c, id, ok ? name : name + " (failed)", body);
    }

    private static JSONObject runJob(Context c, String kind, String arg) {
        switch (kind) {
            case "weather": return Tools.dispatch(c, "weather_report", J.obj("city", arg.isEmpty() ? "Dhaka" : arg));
            case "calendar": return Tools.dispatch(c, "calendar_list", J.obj("days", arg.matches("\\d+") ? Integer.parseInt(arg) : 1));
            case "email": return Tools.dispatch(c, "gmail_recent", J.obj());
            case "notifications": return Tools.dispatch(c, "notification_digest", J.obj());
            case "expenses": return Tools.dispatch(c, "expense_month", J.obj());
            case "missed_calls": return Tools.dispatch(c, "call_log_recent", J.obj("kind", "missed", "count", 10));
            case "news": return Tools.dispatch(c, "read_news", J.obj("source", arg.isEmpty() ? "bbc" : arg, "count", 5));
            default: return J.fail("unknown task kind");
        }
    }

    /** One to three plain lines from the result; uses only what the result contains. Falls back to the raw start of it. */
    private static String summarize(Context c, String name, JSONObject r) {
        String raw = r.toString();
        if (raw.length() > 6000) raw = raw.substring(0, 6000);
        try {
            if (!Prefs.apiKey(c).isEmpty()) {
                String s = GeminiRest.generate(c, "Write a notification text of at most 3 short lines for the task \"" + name + "\" from this data. Use only facts that are in the data, "
                        + "write in the language of the task name, no markdown. If the data has nothing, say there is nothing new.\n\nDATA:\n" + raw);
                if (s != null && !s.trim().isEmpty()) return s.trim();
            }
        } catch (Throwable ignored) {
        }
        return raw.length() > 280 ? raw.substring(0, 280) + "…" : raw;
    }

    private static void post(Context c, int id, String title, String text) {
        try {
            Util.ensureChannels(c);
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm == null || !nm.areNotificationsEnabled()) {
                DebugLog.add("Task notification not shown (notifications are off): " + title);
                return;
            }
            Intent open = new Intent(c, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent openPi = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, Util.CHANNEL_ALERT) : new Notification.Builder(c);
            b.setSmallIcon(c.getApplicationInfo().icon != 0 ? c.getApplicationInfo().icon : android.R.drawable.ic_dialog_info)
                    .setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(openPi).setAutoCancel(true).setWhen(System.currentTimeMillis())
                    .addAction(new Notification.Action.Builder(null, "Snooze 10 min", pi(c, id * 3 % 2000000000, ACT_SNOOZE, 10)).build())
                    .addAction(new Notification.Action.Builder(null, "Done", pi(c, id * 3 % 2000000000, ACT_DONE, 0)).build());
            if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL);
            nm.notify(id, b.build());
            DebugLog.add("Task notification shown: " + title);
        } catch (Throwable e) {
            DebugLog.add("Task notification failed: " + e);
        }
    }

    static void snooze(Context c, int id, int minutes) {
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm != null) nm.cancel(id);
            setAlarm(c, System.currentTimeMillis() + minutes * 60000L, pi(c, id * 3 % 2000000000 + 1000000, ACT_RUN, 0), id);
        } catch (Throwable e) {
            DebugLog.add("Snooze failed: " + e);
        }
    }

    static void done(Context c, int id) {
        try {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm != null) nm.cancel(id);
        } catch (Throwable ignored) {
        }
    }
}
