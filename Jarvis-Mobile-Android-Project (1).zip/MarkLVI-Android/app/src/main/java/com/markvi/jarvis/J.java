package com.markvi.jarvis;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/** Tiny JSON helpers so the rest of the code never has to deal with checked JSONException. */
public final class J {
    private J() {}

    public static JSONObject obj(Object... kv) {
        JSONObject o = new JSONObject();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            put(o, String.valueOf(kv[i]), kv[i + 1]);
        }
        return o;
    }

    public static JSONArray arr(Object... values) {
        JSONArray a = new JSONArray();
        for (Object v : values) a.put(v);
        return a;
    }

    public static JSONObject put(JSONObject o, String k, Object v) {
        try {
            o.put(k, v);
        } catch (JSONException ignored) {
        }
        return o;
    }

    public static JSONObject parse(String s) {
        try {
            return new JSONObject(s);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    /** status=done plus the given key/values. */
    public static JSONObject ok(Object... kv) {
        JSONObject o = obj(kv);
        put(o, "status", "done");
        return o;
    }

    /** status=started: launched but not confirmed finished. */
    public static JSONObject started(Object... kv) {
        JSONObject o = obj(kv);
        put(o, "status", "started");
        return o;
    }

    public static JSONObject fail(String message) {
        return obj("status", "failed", "error", message);
    }

    /** Wraps text from the outside world so the model treats it as data. */
    public static String untrusted(String source, String text) {
        if (text == null) text = "";
        text = text.replace("<<<END UNTRUSTED>>>", "<<<END_UNTRUSTED_ESCAPED>>>");
        return "<<<UNTRUSTED source=" + source + ">>>\n" + text + "\n<<<END UNTRUSTED>>>";
    }
}
