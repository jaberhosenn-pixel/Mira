package com.markvi.jarvis;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * Optional auto-reply for chat notifications (WhatsApp, Messenger, SMS apps, Telegram). OFF by default; the user turns it
 * on in Settings or by voice. It answers through the notification's own reply box, so it needs Notification access only.
 * Safe by design: one reply per person per cooldown, a daily limit, never groups, never OTP / bank / promo messages.
 */
public final class AutoReply {
    private AutoReply() {}

    static final String DEFAULT_TEXT = "আমি এখন একটু ব্যস্ত আছি, পরে যোগাযোগ করব। (স্বয়ংক্রিয় উত্তর)";
    private static final Map<String, Long> LAST = new HashMap<>();
    private static final Random RND = new Random();

    static SharedPreferences sp(Context c) { return Prefs.sp(c); }

    public static boolean enabled(Context c) { return sp(c).getBoolean("ar_on", false); }

    static void setEnabled(Context c, boolean on) { sp(c).edit().putBoolean("ar_on", on).apply(); }

    private static boolean appAllowed(Context c, String pkg) {
        String p = pkg.toLowerCase(Locale.ROOT);
        SharedPreferences s = sp(c);
        if (p.startsWith("com.whatsapp")) return s.getBoolean("ar_wa", true);
        if (p.equals("com.facebook.orca") || p.equals("com.facebook.mlite")) return s.getBoolean("ar_ms", true);
        if (p.equals("org.telegram.messenger") || p.contains("telegram")) return s.getBoolean("ar_tg", false);
        if (p.contains("messaging") || p.contains("mms")) return s.getBoolean("ar_sms", false);
        return false;
    }

    private static boolean looksAutomatic(String text) {
        String b = text.toLowerCase(Locale.ROOT);
        return b.matches("(?s).*(\\botp\\b|trxid|transaction|credited|debited|cash in|cash out|verification code|security code|পিন|ওটিপি|লেনদেন|bkash|nagad|rocket|বিকাশ|নগদ).*")
                || b.matches("(?s).*(sale|offer|discount|% off|promo|voucher|coupon|অফার|ডিসকাউন্ট|জিতুন).*")
                || b.matches("^\\d+\\s+(new\\s+)?messages?.*") || b.contains("missed call") || b.contains("মিসড কল");
    }

    /** Called by NotifCatcher for every fresh chat notification. Returns quickly; the work runs on its own thread. */
    static void onMessage(final Context ctx, final NotifCatcher.Entry en) {
        try {
            if (!enabled(ctx) || en == null) return;
            if (en.reply == null || en.inputs == null) return;
            if (en.group) return;
            if (!appAllowed(ctx, en.pkg)) return;
            String sender = en.sender == null ? "" : en.sender.trim();
            if (sender.isEmpty() || sender.equalsIgnoreCase(en.app) || sender.equalsIgnoreCase("you") || sender.equals("আপনি")) return;
            if (en.text == null || en.text.trim().isEmpty() || looksAutomatic(en.text + " " + sender)) return;

            SharedPreferences s = sp(ctx);
            if (s.getBoolean("ar_screen_off", false)) {
                PowerManager pm = (PowerManager) ctx.getSystemService(Context.POWER_SERVICE);
                if (pm != null && pm.isInteractive()) return;
            }
            if (s.getBoolean("ar_only_list", false)) {
                boolean hit = false;
                for (String n : s.getString("ar_list", "").split("[,\\n،]")) {
                    String x = n.trim().toLowerCase(Locale.ROOT);
                    if (!x.isEmpty() && sender.toLowerCase(Locale.ROOT).contains(x)) { hit = true; break; }
                }
                if (!hit) return;
            }
            String key = en.pkg + "|" + sender.toLowerCase(Locale.ROOT);
            long now = System.currentTimeMillis();
            long cool = Math.max(1, s.getInt("ar_cool", 30)) * 60000L;
            synchronized (AutoReply.class) {
                Long last = LAST.get(key);
                if (last != null && now - last < cool) return;
                String day = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
                int count = day.equals(s.getString("ar_day", "")) ? s.getInt("ar_count", 0) : 0;
                if (count >= Math.max(1, s.getInt("ar_max", 30))) return;
                LAST.put(key, now);
                s.edit().putString("ar_day", day).putInt("ar_count", count + 1).apply();
            }
            new Thread(() -> work(ctx, en), "mira-autoreply").start();
        } catch (Throwable t) {
            DebugLog.add("AutoReply: " + t);
        }
    }

    private static void work(Context ctx, NotifCatcher.Entry en) {
        String reply = sp(ctx).getString("ar_text", DEFAULT_TEXT);
        if (reply.trim().isEmpty()) reply = DEFAULT_TEXT;
        boolean ai = sp(ctx).getBoolean("ar_ai", false);
        if (ai && !Prefs.apiKey(ctx).isEmpty() && OfflineMira.online(ctx)) {
            try {
                String r = GeminiRest.generate(ctx,
                        "You reply on behalf of a busy phone owner. Write ONE very short, polite reply (max 20 words) in the SAME language and script as the message. "
                                + "Say they are busy and will get back later. Never promise a time, never share any information, never mention money, links, passwords or places. "
                                + "Output only the reply text. Message from " + en.sender + ": " + (en.text.length() > 300 ? en.text.substring(0, 300) : en.text));
                if (r != null) {
                    r = r.trim().replaceAll("^[\"'“”]+|[\"'“”]+$", "");
                    if (r.length() > 3 && r.length() < 220) reply = r + " (স্বয়ংক্রিয়)";
                }
            } catch (Throwable ignored) { /* keep the fixed text */ }
        }
        try { Thread.sleep(4000 + RND.nextInt(5000)); } catch (InterruptedException ignored) { }
        boolean ok = true;
        String err = "";
        try {
            send(ctx, en, reply);
        } catch (Throwable t) {
            ok = false;
            err = String.valueOf(t.getMessage());
            DebugLog.add("AutoReply send failed: " + t);
        }
        log(ctx, en, reply, ok, err);
    }

    static void send(Context c, NotifCatcher.Entry en, String text) throws Exception {
        Intent fill = new Intent();
        Bundle b = new Bundle();
        for (android.app.RemoteInput ri : en.inputs) b.putCharSequence(ri.getResultKey(), text);
        android.app.RemoteInput.addResultsToIntent(en.inputs, fill, b);
        en.reply.actionIntent.send(c, 0, fill);
    }

    private static void log(Context c, NotifCatcher.Entry en, String reply, boolean ok, String err) {
        try {
            JSONArray a = new JSONArray(sp(c).getString("ar_log", "[]"));
            a.put(J.obj("t", new SimpleDateFormat("d MMM HH:mm", Locale.US).format(new Date()), "who", en.sender, "app", en.app,
                    "msg", en.text.length() > 60 ? en.text.substring(0, 60) : en.text, "reply", reply, "sent", ok, "err", err));
            while (a.length() > 40) a.remove(0);
            sp(c).edit().putString("ar_log", a.toString()).apply();
        } catch (Throwable ignored) { }
    }

    static String logText(Context c) {
        try {
            JSONArray a = new JSONArray(sp(c).getString("ar_log", "[]"));
            if (a.length() == 0) return "(no auto-replies yet)";
            StringBuilder b = new StringBuilder();
            for (int i = a.length() - 1; i >= 0 && i >= a.length() - 15; i--) {
                JSONObject o = a.getJSONObject(i);
                b.append(o.optString("t")).append("  ").append(o.optString("app")).append(" / ").append(o.optString("who"))
                        .append(o.optBoolean("sent") ? "  SENT" : "  FAILED " + o.optString("err")).append('\n')
                        .append("  they: ").append(o.optString("msg")).append('\n')
                        .append("  mira: ").append(o.optString("reply")).append("\n\n");
            }
            return b.toString();
        } catch (Throwable t) { return "(could not read the log)"; }
    }
}
