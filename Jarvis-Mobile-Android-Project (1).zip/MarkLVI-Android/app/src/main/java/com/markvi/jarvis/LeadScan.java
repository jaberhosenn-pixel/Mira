package com.markvi.jarvis;

import android.content.Context;
import android.content.Intent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Request;
import okhttp3.Response;

/**
 * Lead scanner: drives Google Maps / Google Search in a real WebView (like the lead-scraper browser extensions),
 * then reads each business website for real email / Facebook / Instagram, scores every lead and saves CSV + Excel.
 */
final class LeadScan {
    private LeadScan() {}

    // ---- shared state with MapsScanActivity
    static volatile CountDownLatch done;
    static volatile List<JSONObject> places = new ArrayList<>();
    static volatile JSONArray serp = new JSONArray();
    static volatile String error = "";
    static volatile boolean started;
    static volatile boolean cancelled;
    static volatile boolean blocked;
    static volatile String progress = "";

    private static final String[] JUNK_HOSTS = {"facebook.com", "instagram.com", "youtube.com", "wikipedia.org", "linkedin.com", "twitter.com",
            "x.com", "pinterest.", "tiktok.com", "google.", "yelp.", "tripadvisor.", "justdial.", "yellowpages", "foursquare.", "booking.com",
            "daraz.", "amazon.", "alibaba.", "reddit.com", "quora.com", "medium.com", "bing.com", "duckduckgo.com", "wordpress.com",
            "blogspot.", "maps.app.goo.gl", "apple.com", "play.google", "gov.", "edu."};

    // ------------------------------------------------------------------ entry points

    static JSONObject runMaps(Context c, String niche, String city, int target, String focus) throws Exception {
        List<JSONObject> got = launch(c, "maps", niche + " in " + city, target, null);
        if (got == null) return J.fail(error.isEmpty() ? "the scanner did not start" : error);
        if (got.isEmpty()) return J.fail(error.isEmpty() ? "no businesses were read" : error);
        List<JSONObject> rows = new ArrayList<>();
        for (JSONObject p : got) {
            JSONObject r = J.obj("name", p.optString("name"), "category", p.optString("category"), "rating", p.optDouble("rating", 0),
                    "reviews", p.optInt("reviews", 0), "phone", p.optString("phone"), "website", p.optString("website"),
                    "email", "", "facebook", "", "instagram", "", "address", p.optString("address"), "maps_url", p.optString("url"), "notes", "");
            rows.add(r);
        }
        return finish(c, niche, city, rows, target, focus, "Google Maps");
    }

    static JSONObject runSearch(Context c, String niche, String city, int target, String focus) throws Exception {
        String[] variants = {niche + " in " + city, niche + " " + city + " contact", "best " + niche + " in " + city,
                niche + " near " + city + " email", niche + " " + city + " official website", "top " + niche + " " + city + " phone number",
                niche + " services " + city, niche + " " + city + " Facebook page"};
        List<String> urls = new ArrayList<>();
        for (String q : variants) {
            for (int start = 0; start <= 20; start += 10) {
                urls.add("https://www.google.com/search?hl=en&num=10&q=" + URLEncoder.encode(q, "UTF-8") + "&start=" + start);
            }
        }
        JSONArray hits = new JSONArray();
        List<JSONObject> viaGoogle = launch(c, "serp", "", target, urls);
        if (viaGoogle != null && serp != null) hits = serp;
        String how = "Google Search";
        if (hits.length() < 8) {
            // Google asked for a check or showed nothing: use DuckDuckGo's plain results instead
            DebugLog.add("Search scan: Google gave " + hits.length() + " results" + (blocked ? " (blocked)" : "") + "; using DuckDuckGo");
            hits = new JSONArray();
            for (String q : variants) {
                JSONArray part = duck(q);
                for (int i = 0; i < part.length(); i++) hits.put(part.opt(i));
                Thread.sleep(900);
            }
            how = "DuckDuckGo (Google asked for a check)";
        }
        List<JSONObject> rows = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < hits.length(); i++) {
            JSONObject h = hits.optJSONObject(i);
            if (h == null) continue;
            String url = h.optString("url");
            String host = ToolsLeads.host(url);
            if (host.isEmpty() || isJunk(host) || !seen.add(host)) continue;
            String title = h.optString("title").split("\\s[-|–—:·]\\s|\\s\\|\\s")[0].trim();
            if (title.isEmpty()) title = host;
            String site = url.substring(0, url.indexOf('/', url.indexOf("://") + 3) < 0 ? url.length() : url.indexOf('/', url.indexOf("://") + 3));
            rows.add(J.obj("name", title, "category", niche, "rating", 0, "reviews", 0, "phone", "", "website", site, "email", "", "facebook", "",
                    "instagram", "", "address", city, "maps_url", "", "notes", "found in search results"));
            if (rows.size() >= Math.round(target * 1.6f)) break;
        }
        if (rows.isEmpty()) return J.fail("The search returned no usable business websites.");
        return finish(c, niche, city, rows, target, focus, how);
    }

    private static boolean isJunk(String host) {
        for (String j : JUNK_HOSTS) if (host.contains(j)) return true;
        return false;
    }

    /** Opens the scanner screen and waits (up to 25 minutes) for it to finish. Returns null when it could not start. */
    private static List<JSONObject> launch(Context c, String mode, String q, int target, List<String> urls) throws Exception {
        if (done != null && done.getCount() > 0) {
            error = "another scan is still running";
            return null;
        }
        done = new CountDownLatch(1);
        places = new ArrayList<>();
        serp = new JSONArray();
        error = "";
        started = false;
        cancelled = false;
        blocked = false;
        progress = "";
        Intent i = new Intent(c, MapsScanActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                .putExtra("mode", mode).putExtra("q", q).putExtra("target", target);
        if (urls != null) i.putStringArrayListExtra("urls", new ArrayList<>(urls));
        c.startActivity(i);
        for (int k = 0; k < 40 && !started; k++) Thread.sleep(250);
        if (!started) {
            error = "the scanner screen could not open. Keep Mira on the screen, and allow 'Display over other apps' for Mira in phone settings.";
            done.countDown();
            return null;
        }
        done.await(25, TimeUnit.MINUTES);
        return new ArrayList<>(places);
    }

    // ------------------------------------------------------------------ DuckDuckGo fallback

    private static JSONArray duck(String q) {
        JSONArray out = new JSONArray();
        try {
            Request req = new Request.Builder().url("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36").build();
            try (Response r = GeminiRest.HTTP.newCall(req).execute()) {
                String html = r.body() == null ? "" : r.body().string();
                Matcher m = Pattern.compile("class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>", Pattern.DOTALL).matcher(html);
                while (m.find()) {
                    String href = m.group(1).replace("&amp;", "&");
                    int u = href.indexOf("uddg=");
                    if (u >= 0) {
                        String enc = href.substring(u + 5);
                        int amp = enc.indexOf('&');
                        href = URLDecoder.decode(amp > 0 ? enc.substring(0, amp) : enc, "UTF-8");
                    }
                    if (!href.startsWith("http")) continue;
                    out.put(J.obj("title", m.group(2).replaceAll("<[^>]+>", "").replace("&amp;", "&").trim(), "url", href));
                }
            }
        } catch (Exception e) {
            DebugLog.add("DuckDuckGo search failed: " + e);
        }
        return out;
    }

    // ------------------------------------------------------------------ enrich, score, save

    private static JSONObject finish(Context c, String niche, String city, List<JSONObject> rows, int target, String focus, String source) throws Exception {
        // read each real website for email / Facebook / Instagram (6 at a time)
        ExecutorService pool = Executors.newFixedThreadPool(6);
        List<Future<?>> jobs = new ArrayList<>();
        for (final JSONObject r : rows) {
            jobs.add(pool.submit(new Callable<Object>() {
                @Override
                public Object call() {
                    String site = r.optString("website").trim();
                    String h = ToolsLeads.host(site);
                    if (h.contains("facebook.com") || h.contains("instagram.com") || h.contains("linktr.ee") || h.contains("fb.com")) {
                        J.put(r, h.contains("instagram") ? "instagram" : "facebook", site);
                        J.put(r, "website", "");
                        J.put(r, "notes", "only a social page, no own website");
                        return null;
                    }
                    if (site.isEmpty()) {
                        J.put(r, "notes", "no website listed");
                        return null;
                    }
                    JSONObject ct = ToolsLeads.contacts(site);
                    if (ct == null) {
                        J.put(r, "notes", "website did not open");
                        return null;
                    }
                    J.put(r, "email", ct.optString("email"));
                    J.put(r, "facebook", ct.optString("facebook"));
                    J.put(r, "instagram", ct.optString("instagram"));
                    if (r.optString("phone").isEmpty()) J.put(r, "phone", ct.optString("phone"));
                    J.put(r, "notes", ct.optString("email").isEmpty() ? "website read, no public email" : "email read from website");
                    return null;
                }
            }));
        }
        for (Future<?> f : jobs) {
            try {
                f.get(60, TimeUnit.SECONDS);
            } catch (Exception ex) {
                DebugLog.add("lead enrich skipped: " + ex);
            }
        }
        pool.shutdownNow();

        for (JSONObject r : rows) J.put(r, "score", score(r));
        Collections.sort(rows, new Comparator<JSONObject>() {
            @Override
            public int compare(JSONObject a, JSONObject b) {
                int d = b.optInt("score") - a.optInt("score");
                return d != 0 ? d : b.optInt("reviews") - a.optInt("reviews");
            }
        });

        StringBuilder withSite = new StringBuilder("Name,Category,Rating,Reviews,Phone,Website,Email,Facebook,Instagram,Address,Maps URL,Score,Notes\n");
        StringBuilder noSite = new StringBuilder("Name,Category,Rating,Reviews,Phone,Address,Facebook,Maps URL,Score,Notes\n");
        int nWith = 0, nNo = 0, nEmail = 0, nPhone = 0;
        for (JSONObject r : rows) {
            if (!r.optString("phone").isEmpty()) nPhone++;
            if (!r.optString("website").isEmpty()) {
                if (nWith >= target) continue;
                nWith++;
                if (!r.optString("email").isEmpty()) nEmail++;
                withSite.append(row(r, "name", "category", "rating", "reviews", "phone", "website", "email", "facebook", "instagram", "address", "maps_url", "score", "notes"));
            } else {
                nNo++;
                noSite.append(row(r, "name", "category", "rating", "reviews", "phone", "address", "facebook", "maps_url", "score", "notes"));
            }
        }
        String project = (niche + "-" + city).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9\\u0980-\\u09ff]+", "-");
        String tag = source.startsWith("Google Maps") ? "maps" : "search";
        JSONObject out = J.ok("source", source, "businesses_read", rows.size(), "with_website", nWith, "with_public_email", nEmail,
                "with_phone", nPhone, "without_own_website", nNo);
        if (!focus.equals("no_website") && nWith > 0) {
            File f1 = SeriousMode.saveBytes(c, tag + "-leads-" + project + ".csv", withSite.toString().getBytes("UTF-8"), project);
            File f2 = SeriousMode.saveBytes(c, tag + "-leads-" + project + ".xlsx", XlsxWriter.fromCsv(withSite.toString()), project);
            J.put(out, "leads_csv", f1.getAbsolutePath());
            J.put(out, "leads_excel", f2.getAbsolutePath());
        }
        if (!focus.equals("with_website") && nNo > 0) {
            File f3 = SeriousMode.saveBytes(c, tag + "-no-website-" + project + ".csv", noSite.toString().getBytes("UTF-8"), project);
            File f4 = SeriousMode.saveBytes(c, tag + "-no-website-" + project + ".xlsx", XlsxWriter.fromCsv(noSite.toString()), project);
            J.put(out, "no_website_csv", f3.getAbsolutePath());
            J.put(out, "no_website_excel", f4.getAbsolutePath());
        }
        J.put(out, "note", "Score 0-100 = phone 20, public email 25, website 10, Facebook 10, Instagram 5, rating 4+ 10, 20+ reviews 10, 100+ reviews 10. "
                + "Data comes from the live " + source + " pages; spot-check a few leads. "
                + (nWith + nNo < target ? "Fewer than requested were available for this niche and area." : ""));
        return out;
    }

    static int score(JSONObject r) {
        int s = 0;
        if (!r.optString("phone").isEmpty()) s += 20;
        if (!r.optString("email").isEmpty()) s += 25;
        if (!r.optString("website").isEmpty()) s += 10;
        if (!r.optString("facebook").isEmpty()) s += 10;
        if (!r.optString("instagram").isEmpty()) s += 5;
        double rt = r.optDouble("rating", 0);
        int rv = r.optInt("reviews", 0);
        if (rt >= 4.0) s += 10;
        if (rv >= 20) s += 10;
        if (rv >= 100) s += 10;
        return Math.min(100, s);
    }

    private static String row(JSONObject r, String... keys) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < keys.length; i++) {
            if (i > 0) sb.append(',');
            String v = r.optString(keys[i]);
            if (("rating".equals(keys[i]) && r.optDouble("rating", 0) == 0) || ("reviews".equals(keys[i]) && r.optInt("reviews", 0) == 0)) v = "";
            sb.append(esc(v));
        }
        return sb.append('\n').toString();
    }

    private static String esc(String s) {
        if (s == null) return "";
        String t = s.replace("\r", " ").replace("\n", " ");
        return (t.contains(",") || t.contains("\"")) ? "\"" + t.replace("\"", "\"\"") + "\"" : t;
    }
}
