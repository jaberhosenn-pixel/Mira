package com.markvi.jarvis;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Document outputs for Serious mode: PDF, Word (.docx) and ZIP of saved files. */
public final class ToolsDocs {
    private ToolsDocs() {}

    static void register() {
        reg("make_pdf",
                "Makes a PDF from plain text and saves it in Downloads. Lines starting with '# ' or '## ' become headings, '- ' becomes a bullet.",
                schema("filename,text",
                        "filename:STRING:name ending in .pdf",
                        "text:STRING:the document text",
                        "project:STRING:short project name"),
                (c, a) -> {
                    String name = ensureExt(a.optString("filename"), ".pdf");
                    String text = a.optString("text");
                    if (text.trim().isEmpty()) return J.fail("text is empty");
                    java.io.File f = SeriousMode.saveBytes(c, name, pdf(text), a.optString("project", "general"));
                    return J.ok("saved_to", f.getAbsolutePath());
                });

        reg("make_word",
                "Makes a Word (.docx) document from plain text and saves it in Downloads. Lines starting with '# ' or '## ' become headings.",
                schema("filename,text",
                        "filename:STRING:name ending in .docx",
                        "text:STRING:the document text",
                        "project:STRING:short project name"),
                (c, a) -> {
                    String name = ensureExt(a.optString("filename"), ".docx");
                    String text = a.optString("text");
                    if (text.trim().isEmpty()) return J.fail("text is empty");
                    java.io.File f = SeriousMode.saveBytes(c, name, docx(text), a.optString("project", "general"));
                    return J.ok("saved_to", f.getAbsolutePath());
                });

        reg("zip_files",
                "Packs files that Mira saved earlier into one .zip in Downloads (for example a website with its images).",
                schema("filename,paths",
                        "filename:STRING:name ending in .zip",
                        "paths:STRING:full file paths separated by commas",
                        "project:STRING:short project name"),
                (c, a) -> {
                    String name = ensureExt(a.optString("filename"), ".zip");
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    int n = 0;
                    try (ZipOutputStream z = new ZipOutputStream(bo)) {
                        for (String p : a.optString("paths").split(",")) {
                            File f = new File(p.trim());
                            if (!f.isFile()) continue;
                            z.putNextEntry(new ZipEntry(f.getName()));
                            try (FileInputStream in = new FileInputStream(f)) {
                                byte[] buf = new byte[16384];
                                int r;
                                while ((r = in.read(buf)) > 0) z.write(buf, 0, r);
                            }
                            z.closeEntry();
                            n++;
                        }
                    }
                    if (n == 0) return J.fail("none of those files exist");
                    java.io.File f = SeriousMode.saveBytes(c, name, bo.toByteArray(), a.optString("project", "general"));
                    return J.ok("saved_to", f.getAbsolutePath(), "files", n);
                });
    }

    private static String ensureExt(String name, String ext) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty()) n = "mira-" + System.currentTimeMillis();
        return n.toLowerCase(Locale.ROOT).endsWith(ext) ? n : n + ext;
    }

    // ---- PDF
    private static byte[] pdf(String text) throws Exception {
        final int W = 595, H = 842, M = 44;
        PdfDocument doc = new PdfDocument();
        Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        body.setTextSize(11f);
        body.setColor(0xFF111111);
        Paint h1 = new Paint(body), h2 = new Paint(body);
        h1.setTextSize(18f);
        h1.setTypeface(Typeface.DEFAULT_BOLD);
        h2.setTextSize(14f);
        h2.setTypeface(Typeface.DEFAULT_BOLD);

        int pageNo = 1;
        PdfDocument.Page page = doc.startPage(new PdfDocument.PageInfo.Builder(W, H, pageNo).create());
        android.graphics.Canvas cv = page.getCanvas();
        float y = M;
        for (String raw : text.replace("\r", "").split("\n")) {
            Paint p = body;
            String line = raw;
            float gap = 4f;
            if (line.startsWith("## ")) {
                p = h2;
                line = line.substring(3);
                gap = 8f;
            } else if (line.startsWith("# ")) {
                p = h1;
                line = line.substring(2);
                gap = 10f;
            } else if (line.startsWith("- ") || line.startsWith("* ")) {
                line = "•  " + line.substring(2);
            }
            float lh = p.getTextSize() * 1.35f;
            String[] words = line.split(" ", -1);
            StringBuilder cur = new StringBuilder();
            java.util.List<String> lines = new java.util.ArrayList<>();
            for (String w : words) {
                String test = cur.length() == 0 ? w : cur + " " + w;
                if (p.measureText(test) > W - 2 * M && cur.length() > 0) {
                    lines.add(cur.toString());
                    cur = new StringBuilder(w);
                } else cur = new StringBuilder(test);
            }
            lines.add(cur.toString());
            y += gap;
            for (String l : lines) {
                if (y + lh > H - M) {
                    doc.finishPage(page);
                    pageNo++;
                    page = doc.startPage(new PdfDocument.PageInfo.Builder(W, H, pageNo).create());
                    cv = page.getCanvas();
                    y = M;
                }
                y += lh;
                cv.drawText(l, M, y, p);
            }
        }
        doc.finishPage(page);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        doc.writeTo(bo);
        doc.close();
        return bo.toByteArray();
    }

    // ---- DOCX
    private static String esc(String t) {
        return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]", "");
    }

    private static byte[] docx(String text) throws Exception {
        StringBuilder b = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
        for (String raw : text.replace("\r", "").split("\n")) {
            String line = raw;
            String rpr = "";
            if (line.startsWith("## ")) {
                line = line.substring(3);
                rpr = "<w:rPr><w:b/><w:sz w:val=\"28\"/></w:rPr>";
            } else if (line.startsWith("# ")) {
                line = line.substring(2);
                rpr = "<w:rPr><w:b/><w:sz w:val=\"36\"/></w:rPr>";
            } else if (line.startsWith("- ") || line.startsWith("* ")) {
                line = "• " + line.substring(2);
            }
            b.append("<w:p><w:r>").append(rpr).append("<w:t xml:space=\"preserve\">").append(esc(line)).append("</w:t></w:r></w:p>");
        }
        b.append("</w:body></w:document>");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(bo)) {
            put(z, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                    + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                    + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                    + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
                    + "</Types>");
            put(z, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                    + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                    + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
                    + "</Relationships>");
            put(z, "word/document.xml", b.toString());
        }
        return bo.toByteArray();
    }

    private static void put(ZipOutputStream z, String name, String body) throws Exception {
        z.putNextEntry(new ZipEntry(name));
        z.write(body.getBytes("UTF-8"));
        z.closeEntry();
    }
}
