package com.markvi.jarvis;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Owns the live session so the assistant keeps listening when the app is in the background. */
public class JarvisService extends Service implements LiveClient.Listener {

    public static final String ACTION_START = "com.markvi.jarvis.START";
    public static final String ACTION_STOP = "com.markvi.jarvis.STOP";
    public static final String ACTION_WAKE_ON = "com.markvi.jarvis.WAKE_ON";
    public static final String ACTION_WAKE_OFF = "com.markvi.jarvis.WAKE_OFF";

    private static volatile JarvisService inst;

    public static JarvisService get() {
        return inst;
    }

    private LiveClient client;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Handler main = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wake;
    private int reconnects;
    private boolean stopping;

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        DebugLog.installCrashHandler(this);
        Util.ensureChannels(this);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? null : intent.getAction();
        if (ACTION_STOP.equals(act)) {
            if (OfflineMira.isActive()) { OfflineMira.stop(); return START_NOT_STICKY; }
            if (client == null) {
                // only waiting for the wake word: Stop means turn the listener off
                Prefs.sp(this).edit().putBoolean("wake_enabled", false).apply();
                WakeEngine.stop();
                stopForeground(true);
                stopSelf();
                return START_NOT_STICKY;
            }
            stopSession();
            return START_NOT_STICKY;
        }
        if (ACTION_WAKE_OFF.equals(act)) {
            Prefs.sp(this).edit().putBoolean("wake_enabled", false).apply();
            main.removeCallbacks(watchdog);
            if (listenLock != null && listenLock.isHeld()) listenLock.release();
            listenLock = null;
            WakeEngine.stop();
            if (client == null) {
                stopForeground(true);
                stopSelf();
            }
            return START_NOT_STICKY;
        }
        if (ACTION_WAKE_ON.equals(act)) {
            if (!goForeground()) {
                Bus.log("Could not start listening: microphone permission is needed");
                stopSelf();
                return START_NOT_STICKY;
            }
            Prefs.sp(this).edit().putBoolean("wake_enabled", true).apply();
            if (client == null) startWake();
            return START_STICKY;
        }
        if (!goForeground()) {
            Bus.state("ERROR");
            Bus.log("Could not start: microphone permission is needed");
            stopSelf();
            return START_NOT_STICKY;
        }
        WakeEngine.stop();
        stopping = false;
        if (client == null && OfflineMira.shouldUse(this)) {
            // no internet (or forced): the phone's own offline speech, rule based commands
            OfflineMira.start(this, () -> main.post(this::resumeWakeOrStop));
            return START_NOT_STICKY;
        }
        if (client == null) client = new LiveClient(this, this);
        reconnects = 0;
        if (Prefs.keepAwake(this) && wake == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "jarvis:live");
            wake.acquire(4 * 60 * 60 * 1000L);
        }
        client.start();
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------------ wake word

    private volatile boolean downloading;
    private long lastDl;
    private PowerManager.WakeLock listenLock;

    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            if (Prefs.sp(JarvisService.this).getBoolean("wake_enabled", false) && client == null && !stopping) {
                if (!WakeEngine.isRunning()) {
                    // after repeated failures wait longer, so the microphone does not blink on and off
                    long since = System.currentTimeMillis() - lastWakeTry;
                    if (WakeEngine.fails < 3 || since > 30000) startWake();
                }
                else if (!WakeEngine.fallbackRunning() || !WakeEngine.hasModel(JarvisService.this)) { /* ok */ }
                if (WakeEngine.hasModel(JarvisService.this) && WakeEngine.fallbackRunning()) {
                    WakeEngine.stopFallback();
                    startWake();
                }
            }
            if (JarvisAccessibility.get() == null) {
                final android.content.Context ac = getApplicationContext();
                new Thread(() -> JarvisAccessibility.ensureEnabled(ac)).start();
            }
            new Thread(() -> Sip.ensure(getApplicationContext())).start();
            main.postDelayed(this, 8000);
        }
    };

    private long lastWakeTry;

    private void startWake() {
        lastWakeTry = System.currentTimeMillis();
        WakeEngine.setCustomName(Prefs.sp(this).getString("wake_name", ""));
        if (listenLock == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            listenLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mira:listen");
            listenLock.acquire();
        }
        main.removeCallbacks(watchdog);
        main.postDelayed(watchdog, 8000);
        if (!WakeEngine.hasModel(this) && WhisperEngine.ready(this)) {
            // no Vosk model, but the Whisper model is on the phone: offline wake word, no internet needed
            WakeEngine.startWhisper(this, () -> main.post(this::onWakeWord));
            return;
        }
        if (!WakeEngine.hasModel(this)) {
            if (!downloading && System.currentTimeMillis() - lastDl > 60000) {
                downloading = true;
                lastDl = System.currentTimeMillis();
                new Thread(() -> {
                    try {
                        WakeEngine.downloadModel(getApplicationContext());
                    } catch (Throwable t) {
                        DebugLog.add("Wake model download failed: " + t);
                    }
                    downloading = false;
                }, "mira-model").start();
            }
            Bus.log("Wake: speech model is downloading, using the phone recognizer meanwhile");
            WakeEngine.startFallback(this, () -> main.post(this::onWakeWord));
            return;
        }
        WakeEngine.start(this, () -> main.post(this::onWakeWord));
    }

    /**
     * "Hey Mira" was heard. This takes exactly the same road as tapping START TALKING (ACTION_START), so the voice path
     * and the button path can never behave differently.
     */
    private void onWakeWord() {
        if (client != null) return;
        Bus.log("Wake word heard");
        Bus.log("Wake: heard, starting the conversation");
        Bus.state("CONNECTING");
        main.removeCallbacks(watchdog);
        try {
            Intent open = new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(open);
        } catch (Exception ignored) {
        }
        // release the microphone from the wake listener, then start the live session the normal way
        pool.submit(() -> {
            try {
                WakeEngine.stop();
            } catch (Throwable t) {
                DebugLog.add("Wake stop failed: " + t);
            }
            if (listenLock != null && listenLock.isHeld()) listenLock.release();
            listenLock = null;
            main.postDelayed(() -> {
                try {
                    startForegroundService(new Intent(this, JarvisService.class).setAction(ACTION_START));
                } catch (Throwable t) {
                    DebugLog.add("Wake start failed: " + t);
                    Bus.state("ERROR");
                }
                // self-heal: still not ready after 9 s -> restart the session once
                main.postDelayed(() -> {
                    LiveClient cl = client;
                    if (cl == null || stopping || cl.isReady()) return;
                    Bus.log("Wake: session was slow, retrying once");
                    reconnects = 0;
                    cl.stop();
                    cl.start();
                }, 9000);
            }, 150);
        });
    }

    private void resumeWakeOrStop() {
        if (Prefs.sp(this).getBoolean("wake_enabled", false)) {
            goForeground();
            startWake();
        } else {
            stopForeground(true);
            stopSelf();
        }
    }

    private boolean goForeground() {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stop = new Intent(this, JarvisService.class).setAction(ACTION_STOP);
        PendingIntent sp = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, Util.CHANNEL)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle(Prefs.assistantName(this) + (client == null && Prefs.sp(this).getBoolean("wake_enabled", false) ? " is waiting" : " is listening"))
                .setContentText(Prefs.sp(this).getBoolean("wake_enabled", false) && client == null ? "Say \"Hey Mira\" to wake me. Tap to open." : "Tap to open. The microphone is on.")
                .setContentIntent(pi)
                .addAction(android.R.drawable.ic_media_pause, "Stop", sp)
                .setOngoing(true)
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(1, n);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ control

    /** A live session object exists (it may still be connecting). */
    public boolean hasSession() {
        return client != null;
    }

    public boolean isLive() {
        return client != null && client.isReady();
    }

    public void sendText(String t) {
        if (client != null && client.isReady()) client.sendText(t);
    }

    public void sendImage(byte[] jpeg) {
        if (client != null && client.isReady()) client.sendImage(jpeg);
    }

    public void setMuted(boolean m) {
        if (client != null) client.setMuted(m);
    }

    public boolean isMuted() {
        return client != null && client.isMuted();
    }

    public void alert(String text) {
        sendText("[SYSTEM_ALERT] " + text);
    }

    /** Serious mode was switched: after Mira finishes speaking, reconnect so the other voice and tone apply. */
    public void applyModeChange() {
        if (client == null) return;
        final long t0 = System.currentTimeMillis();
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                LiveClient cl = client;
                if (cl == null || stopping || !cl.isReady()) return;
                if (cl.isSpeaking() && System.currentTimeMillis() - t0 < 20000) {
                    main.postDelayed(this, 1000);
                    return;
                }
                Bus.log("Mode changed: reconnecting with the matching voice");
                reconnects = 0;
                cl.stop();
                cl.start();
            }
        }, 4000);
    }

    public void stopSessionSoon() {
        main.postDelayed(this::stopSession, 3500);
    }

    public void stopSession() {
        stopping = true;
        if (client != null) client.stop();
        client = null;
        if (wake != null && wake.isHeld()) wake.release();
        wake = null;
        resumeWakeOrStop();
    }

    @Override
    public void onDestroy() {
        main.removeCallbacks(watchdog);
        if (listenLock != null && listenLock.isHeld()) listenLock.release();
        WakeEngine.stop();
        if (client != null) client.stop();
        if (wake != null && wake.isHeld()) wake.release();
        pool.shutdownNow();
        if (inst == this) inst = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------------ LiveClient.Listener

    @Override
    public void onReady() {
        reconnects = 0;
    }

    @Override
    public void onUserText(String text, boolean finished) {
        Bus.Ui u = Bus.ui;
        if (u != null) u.onUserText(text, finished);
    }

    @Override
    public void onAssistantText(String text, boolean finished) {
        Bus.Ui u = Bus.ui;
        if (u != null) u.onAssistantText(text, finished);
    }

    @Override
    public void onToolCall(final String id, final String name, final JSONObject args) {
        final LiveClient cl = client;
        Bus.log("Tool: " + name + " " + GeminiRest.abbreviate(args.toString(), 120));
        pool.submit(() -> {
            JSONObject result;
            Future<JSONObject> f = pool.submit(() -> Tools.dispatchUser(JarvisService.this, name, args));
            try {
                result = f.get(90, TimeUnit.SECONDS);
            } catch (Exception e) {
                f.cancel(true);
                result = J.fail("the tool timed out");
            }
            Bus.log("  -> " + GeminiRest.abbreviate(result.toString(), 160));
            if (cl != null) cl.sendToolResponse(id, name, result);
        });
    }

    @Override
    public void onClosed(String reason, boolean fatal) {
        Bus.log("Session ended: " + GeminiRest.abbreviate(reason, 160));
        if (!fatal && !stopping && reconnects < 3 && client != null) {
            reconnects++;
            Bus.state("CONNECTING");
            main.postDelayed(() -> {
                if (!stopping && client != null) client.start();
            }, 1500);
            return;
        }
        main.post(this::stopSession);
    }
}
