package com.markvi.jarvis;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Incoming call helpers: who is calling, answer, decline, "I'm busy" by SMS/WhatsApp, and Mira's voice played into a call. Only on the user's command. */
final class ToolsCalls {
    private ToolsCalls() {}

    static final String BUSY_TEXT_BN = "আমি মীরা, ওনার ডিজিটাল সহকারী। উনি এখন একটু ব্যস্ত আছেন, পরে আপনাকে ফোন করবেন।";
    static final String BUSY_SMS_BN = "আমি এখন একটু ব্যস্ত আছি, পরে আপনাকে ফোন করবো।";

    static void register() {
        reg("incoming_call",
                "Tells who is calling right now (name from contacts and number), or says no call is ringing. Also checks for a WhatsApp call notification. "
                        + "Use when the user asks who is calling or before answering.",
                schema(""), (c, a) -> incoming(c));

        reg("answer_call",
                "Answers the ringing phone call (normal phone calls, not WhatsApp). speaker=true puts it on loudspeaker.",
                schema("", "speaker:BOOLEAN:true to use the loudspeaker"),
                (c, a) -> {
                    JSONObject chk = needReady(c, true);
                    if (chk != null) return chk;
                    tm(c).acceptRingingCall();
                    if (a.optBoolean("speaker", false)) {
                        waitState(c, TelephonyManager.EXTRA_STATE_OFFHOOK, 4000);
                        audio(c).setSpeakerphoneOn(true);
                    }
                    return J.ok("note", "call answered");
                });

        reg("reject_call",
                "Declines / ends the ringing or current phone call (normal phone calls, not WhatsApp).",
                schema(""),
                (c, a) -> {
                    JSONObject chk = needReady(c, false);
                    if (chk != null) return chk;
                    if (!hangUp(c)) return J.fail("this phone version cannot end calls from an app (needs Android 9 or newer)");
                    return J.ok("note", "call ended");
                });

        reg("decline_with_message",
                "Declines the ringing call (or uses the last caller within 10 minutes) and sends them a short 'I am busy' message by SMS or WhatsApp. "
                        + "Only when the user asks. text defaults to a polite Bangla busy message.",
                schema("", "text:STRING:the message, in the user's language",
                        "platform:STRING:sms (default) | whatsapp"),
                (c, a) -> declineWithMessage(c, a));

        reg("answer_and_say_busy",
                "Answers the ringing phone call, plays Mira's voice saying the user is busy (through the loudspeaker so the caller hears it through the "
                        + "phone's microphone) and then hangs up. Normal phone calls only. Only when the user asks. text is optional.",
                schema("", "text:STRING:what Mira says; default is a polite Bangla line saying she is the user's assistant and the user is busy",
                        "hang_up:BOOLEAN:hang up afterwards (default true)",
                        "repeat:INTEGER:how many times to say it (default 2, max 4)",
                        "route:STRING:auto (default, tries media, voice and alarm audio paths) | media | voice | alarm"),
                (c, a) -> answerAndSayBusy(c, a));

        reg("decline_with_voice",
                "Declines the ringing call (or uses the last caller within 10 minutes) and sends them Mira's VOICE saying the user is busy, as an audio message on WhatsApp. "
                        + "Needs Accessibility on and the caller to have WhatsApp. Only when the user asks. text is optional (default: a polite Bangla line).",
                schema("", "text:STRING:what Mira says, in the user's language"),
                (c, a) -> declineWithVoice(c, a));

        reg("set_call_voice_route",
                "Saves which audio path Mira uses when she speaks into a phone call: auto | media | voice | alarm. Use after the user tells you which one the caller could hear.",
                schema("route", "route:STRING:auto | media | voice | alarm"),
                (c, a) -> {
                    String r = a.optString("route", "auto").toLowerCase(Locale.ROOT);
                    if (!Arrays.asList("auto", "media", "voice", "alarm").contains(r)) return J.fail("route must be auto, media, voice or alarm");
                    Prefs.sp(c).edit().putString("call_route", r).apply();
                    return J.ok("route", r);
                });

        reg("call_log_recent",
                "Lists the latest phone calls (incoming, missed, outgoing) with name, number, time and duration. Use for 'who called me', 'missed calls'. "
                        + "kind: all | missed | incoming | outgoing.",
                schema("", "kind:STRING:all (default) | missed | incoming | outgoing", "count:INTEGER:how many, default 10, max 30"),
                (c, a) -> {
                    if (!has(c, Manifest.permission.READ_CALL_LOG)) return J.fail("Call log permission is missing. Allow 'Call log' in Mira's All Permissions page.");
                    String kind = a.optString("kind", "all").toLowerCase(Locale.ROOT);
                    int max = Math.max(1, Math.min(30, a.optInt("count", 10)));
                    JSONArray out = new JSONArray();
                    java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
                    try (Cursor cur = c.getContentResolver().query(android.provider.CallLog.Calls.CONTENT_URI,
                            new String[]{android.provider.CallLog.Calls.NUMBER, android.provider.CallLog.Calls.DATE, android.provider.CallLog.Calls.TYPE,
                                    android.provider.CallLog.Calls.DURATION}, null, null, android.provider.CallLog.Calls.DATE + " DESC")) {
                        while (cur != null && cur.moveToNext() && out.length() < max) {
                            int t = cur.getInt(2);
                            String tn = t == android.provider.CallLog.Calls.MISSED_TYPE ? "missed" : t == android.provider.CallLog.Calls.INCOMING_TYPE ? "incoming"
                                    : t == android.provider.CallLog.Calls.OUTGOING_TYPE ? "outgoing" : t == android.provider.CallLog.Calls.REJECTED_TYPE ? "rejected" : "other";
                            if (!kind.equals("all") && !tn.equals(kind) && !(kind.equals("missed") && tn.equals("rejected"))) continue;
                            String num = cur.getString(0) == null ? "" : cur.getString(0);
                            String nm = nameFor(c, num);
                            out.put(J.obj("type", tn, "name", nm.isEmpty() ? "not in contacts" : nm, "number", num.isEmpty() ? "hidden" : num,
                                    "time", f.format(new java.util.Date(cur.getLong(1))), "seconds", cur.getInt(3)));
                        }
                    } catch (Exception e) {
                        return J.fail("could not read the call log: " + e.getMessage());
                    }
                    return J.ok("count", out.length(), "calls", out);
                });

        reg("whatsapp_call_action",
                "Answers or declines a ringing WhatsApp call by tapping its button on screen. Needs Accessibility, an unlocked screen with the call notification showing. "
                        + "Not reliable, tell the user so.",
                schema("action", "action:STRING:answer | decline"),
                (c, a) -> {
                    if (JarvisAccessibility.get() == null) return J.fail("Accessibility is off");
                    boolean ans = "answer".equalsIgnoreCase(a.optString("action"));
                    ArrayList<String> labels = new ArrayList<>(ans ? Arrays.asList("Answer", "Accept", "Pick up") : Arrays.asList("Decline", "Reject", "Dismiss"));
                    boolean ok = JarvisAccessibility.tapAnyTextWithin(labels, 3500);
                    return ok ? J.obj("status", "unverified", "note", "button tapped") : J.fail("could not find the button on screen (screen locked or call banner gone)");
                });
    }

    // ------------------------------------------------------------------ helpers

    private static TelecomManager tm(Context c) {
        return (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
    }

    private static AudioManager audio(Context c) {
        return (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
    }

    /** Live call state straight from the phone; falls back to what the broadcast receiver last saw. */
    static String callState(Context c) {
        try {
            int st = ((TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE)).getCallState();
            if (st == TelephonyManager.CALL_STATE_RINGING) return TelephonyManager.EXTRA_STATE_RINGING;
            if (st == TelephonyManager.CALL_STATE_OFFHOOK) return TelephonyManager.EXTRA_STATE_OFFHOOK;
            return TelephonyManager.EXTRA_STATE_IDLE;
        } catch (Throwable t) {
            return CallReceiver.state;
        }
    }

    /** Number of the current or latest caller: from the broadcast, else from the call log (calls that just ended). */
    static String callerNumber(Context c) {
        if (!CallReceiver.number.isEmpty() && System.currentTimeMillis() - CallReceiver.ringTime < 600000L) return CallReceiver.number;
        if (!has(c, Manifest.permission.READ_CALL_LOG)) return "";
        try (Cursor cur = c.getContentResolver().query(android.provider.CallLog.Calls.CONTENT_URI,
                new String[]{android.provider.CallLog.Calls.NUMBER, android.provider.CallLog.Calls.DATE, android.provider.CallLog.Calls.TYPE},
                android.provider.CallLog.Calls.DATE + " > ?", new String[]{String.valueOf(System.currentTimeMillis() - 600000L)},
                android.provider.CallLog.Calls.DATE + " DESC")) {
            while (cur != null && cur.moveToNext()) {
                int type = cur.getInt(2);
                if (type == android.provider.CallLog.Calls.INCOMING_TYPE || type == android.provider.CallLog.Calls.MISSED_TYPE
                        || type == android.provider.CallLog.Calls.REJECTED_TYPE) {
                    String n = cur.getString(0);
                    if (n != null && !n.isEmpty()) return n;
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static boolean has(Context c, String p) {
        return c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private static JSONObject needReady(Context c, boolean mustRing) {
        if (!has(c, Manifest.permission.ANSWER_PHONE_CALLS)) {
            return J.fail("Phone-call permission is missing. Open Settings > Permissions in Mira and allow 'Answer calls'.");
        }
        if (mustRing && !TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c))) return J.fail("no phone call is ringing right now");
        return null;
    }

    private static void waitState(Context c, String want, long ms) {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end && !want.equals(callState(c))) {
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    @SuppressWarnings("deprecation")
    private static boolean hangUp(Context c) {
        if (Build.VERSION.SDK_INT < 28) return false;
        return tm(c).endCall();
    }

    static String nameFor(Context c, String number) {
        if (number == null || number.isEmpty() || !has(c, Manifest.permission.READ_CONTACTS)) return "";
        try (Cursor cur = c.getContentResolver().query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (Exception ignored) {
        }
        return "";
    }

    private static JSONObject incoming(Context c) {
        JSONObject out = new JSONObject();
        boolean ringing = TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c));
        J.put(out, "status", "done");
        J.put(out, "phone_call_ringing", ringing);
        if (ringing || System.currentTimeMillis() - CallReceiver.ringTime < 600000 || !callerNumber(c).isEmpty()) {
            String n = callerNumber(c);
            J.put(out, ringing ? "number" : "last_caller_number", n.isEmpty() ? "hidden or not available" : n);
            String name = nameFor(c, n);
            J.put(out, ringing ? "name" : "last_caller_name", name.isEmpty() ? "not in contacts" : name);
        }
        if (!has(c, Manifest.permission.READ_CALL_LOG) || !has(c, Manifest.permission.READ_PHONE_STATE)) {
            J.put(out, "warning", "the caller number may be missing: allow 'Call log' and 'Phone state' in Mira's permission page");
        }
        try {
            JSONArray all = new JSONArray(NotifCatcher.json());
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.getJSONObject(i);
                String app = o.optString("app").toLowerCase(Locale.ROOT);
                String txt = (o.optString("desc") + " " + o.optString("sender")).toLowerCase(Locale.ROOT);
                if (app.contains("whatsapp") && (txt.contains("incoming") && txt.contains("call"))) {
                    J.put(out, "whatsapp_call_notification", o.optString("sender") + " at " + o.optString("time") + " (may already be over)");
                    break;
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private static JSONObject declineWithMessage(Context c, JSONObject a) throws Exception {
        boolean ringing = TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c));
        String number = callerNumber(c);
        if (!ringing && number.isEmpty()) return J.fail("no recent call to answer with a message");
        if (number.isEmpty()) return J.fail("the caller's number is hidden or not available (check Call log permission)");
        String text = a.optString("text").trim();
        if (text.isEmpty()) text = BUSY_SMS_BN;
        String platform = a.optString("platform", "sms").toLowerCase(Locale.ROOT);
        String who = nameFor(c, number);
        if (ringing && has(c, Manifest.permission.ANSWER_PHONE_CALLS)) hangUp(c);
        if (platform.equals("whatsapp")) {
            JSONObject r = Tools.dispatch(c, "send_message", J.obj("receiver", number, "message_text", text, "platform", "whatsapp"));
            J.put(r, "to", who.isEmpty() ? number : who);
            return r;
        }
        if (!has(c, Manifest.permission.SEND_SMS)) return J.fail("SMS permission is missing");
        SmsManager sm = Build.VERSION.SDK_INT >= 31 ? c.getSystemService(SmsManager.class) : SmsManager.getDefault();
        sm.sendMultipartTextMessage(number, null, sm.divideMessage(text), null, null);
        return J.obj("status", "unverified", "to", who.isEmpty() ? number : who, "note", "call declined and SMS handed to the network; delivery cannot be confirmed");
    }

    private static byte[] wav(byte[] pcm) throws Exception {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
        java.nio.ByteBuffer h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN);
        h.put("RIFF".getBytes()).putInt(36 + pcm.length).put("WAVE".getBytes()).put("fmt ".getBytes()).putInt(16)
                .putShort((short) 1).putShort((short) 1).putInt(24000).putInt(48000).putShort((short) 2).putShort((short) 16)
                .put("data".getBytes()).putInt(pcm.length);
        o.write(h.array());
        o.write(pcm);
        return o.toByteArray();
    }

    private static JSONObject declineWithVoice(Context c, JSONObject a) throws Exception {
        if (JarvisAccessibility.get() == null) return J.fail("Accessibility is off, so Mira cannot press Send in WhatsApp. Turn it on in All Permissions.");
        boolean ringing = TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c));
        String number = callerNumber(c);
        if (number.isEmpty()) return J.fail("the caller's number is hidden or not available (check the Call log permission)");
        String text = a.optString("text").trim();
        if (text.isEmpty()) text = BUSY_TEXT_BN;
        byte[] pcm = VoiceTts.render(c, text, Prefs.voice(c));
        if (pcm == null) return J.fail("could not prepare Mira's voice (" + VoiceTts.lastError + "). The call was NOT declined.");
        String iso = "";
        try {
            iso = ((TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE)).getSimCountryIso().toUpperCase(Locale.ROOT);
        } catch (Exception ignored) {
        }
        String e164 = iso.isEmpty() ? null : android.telephony.PhoneNumberUtils.formatNumberToE164(number, iso);
        String digits = Util.digitsOnly(e164 != null ? e164 : number);
        if (digits.length() < 8) return J.fail("could not work out the caller's number for WhatsApp");
        String pkg = null;
        for (String p : new String[]{"com.whatsapp", "com.whatsapp.w4b"}) {
            try {
                c.getPackageManager().getPackageInfo(p, 0);
                pkg = p;
                break;
            } catch (Exception ignored) {
            }
        }
        if (pkg == null) return J.fail("WhatsApp is not installed");
        java.io.File dir = c.getExternalFilesDir(null);
        if (dir == null) return J.fail("no storage available");
        java.io.File f = new java.io.File(dir, "mira-busy-voice.wav");
        try (java.io.FileOutputStream fo = new java.io.FileOutputStream(f)) {
            fo.write(wav(VoiceTts.boost(pcm)));
        }
        if (ringing && has(c, Manifest.permission.ANSWER_PHONE_CALLS)) hangUp(c);
        Uri uri = MiraFileProvider.uriFor(c, f);
        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_SEND)
                .setType("audio/wav").setPackage(pkg)
                .putExtra(android.content.Intent.EXTRA_STREAM, uri)
                .putExtra("jid", digits + "@s.whatsapp.net")
                .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            c.grantUriPermission(pkg, uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        Util.launch(c, i);
        boolean clicked = JarvisAccessibility.autoPressSend(15000);
        if (!clicked) clicked = JarvisAccessibility.tapSendCorner();
        String who = nameFor(c, number);
        return clicked ? J.obj("status", "unverified", "to", who.isEmpty() ? number : who,
                "note", "call declined and Send was pressed in WhatsApp with Mira's voice file; nobody can confirm it arrived")
                : J.started("note", "call declined and WhatsApp opened with the voice file; the Send button was not found, the user must press Send");
    }

    private static JSONObject answerAndSayBusy(Context c, JSONObject a) throws Exception {
        JSONObject chk = needReady(c, true);
        if (chk != null) return chk;
        String text = a.optString("text").trim();
        if (text.isEmpty()) text = BUSY_TEXT_BN;
        // make the voice first, while the phone is still ringing, so there is no silence after answering
        byte[] pcm = VoiceTts.render(c, text, Prefs.voice(c));
        if (pcm == null) {
            return J.fail("could not prepare Mira's voice (" + VoiceTts.lastError + "). The call was NOT answered; use decline_with_message instead.");
        }
        if (!TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c))) return J.fail("the call stopped ringing");
        AudioManager am = audio(c);
        int[] streams = {AudioManager.STREAM_MUSIC, AudioManager.STREAM_VOICE_CALL, AudioManager.STREAM_ALARM};
        int[] old = new int[streams.length];
        for (int k = 0; k < streams.length; k++) old[k] = am.getStreamVolume(streams[k]);
        boolean oldSpeaker = am.isSpeakerphoneOn();
        byte[] loud = VoiceTts.boost(pcm);
        String route = a.optString("route", Prefs.sp(c).getString("call_route", "auto")).toLowerCase(Locale.ROOT);
        // each route sends the same sentence through a different Android audio path; auto tries all three so the caller has the best chance
        String[] order = route.equals("media") ? new String[]{"media"} : route.equals("voice") ? new String[]{"voice"}
                : route.equals("alarm") ? new String[]{"alarm"} : new String[]{"media", "voice", "alarm"};
        tm(c).acceptRingingCall();
        int played = 0;
        try {
            waitState(c, TelephonyManager.EXTRA_STATE_OFFHOOK, 5000);
            if (!TelephonyManager.EXTRA_STATE_OFFHOOK.equals(callState(c))) return J.fail("could not answer the call");
            am.setSpeakerphoneOn(true);
            for (int k = 0; k < streams.length; k++) {
                try {
                    am.setStreamVolume(streams[k], am.getStreamMaxVolume(streams[k]), 0);
                } catch (Exception ignored) {
                }
            }
            Thread.sleep(900); // let the line connect
            int times = Math.max(order.length, Math.min(4, a.optInt("repeat", 2)));
            for (int k = 0; k < times; k++) {
                if (!TelephonyManager.EXTRA_STATE_OFFHOOK.equals(callState(c))) break; // caller already hung up
                String r = order[k % order.length];
                int usage = r.equals("voice") ? android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION
                        : r.equals("alarm") ? android.media.AudioAttributes.USAGE_ALARM : android.media.AudioAttributes.USAGE_MEDIA;
                DebugLog.add("Call voice: playing via " + r + " (" + (k + 1) + "/" + times + ")");
                VoiceTts.playPcm(loud, usage);
                played++;
                Thread.sleep(900);
            }
        } finally {
            try {
                for (int k = 0; k < streams.length; k++) am.setStreamVolume(streams[k], old[k], 0);
                am.setSpeakerphoneOn(oldSpeaker);
            } catch (Exception ignored) {
            }
        }
        boolean hang = a.optBoolean("hang_up", true);
        if (hang) hangUp(c);
        return J.obj("status", "unverified", "note", "Mira's voice was played through the speaker" + (hang ? " and the call was ended" : "")
                + "; played " + played + " time(s) over route '" + route + "'; whether the caller heard it depends on the phone, nobody can confirm");
    }
}
