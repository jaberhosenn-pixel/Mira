package com.markvi.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Android says the battery is low: tell the user with a notification (and out loud when a session is live). */
public class BatteryLowReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            Util.notifyAlert(c, 4810, "Battery low", "The battery is low. Please plug in the charger.");
            JarvisService s = JarvisService.get();
            if (s != null && s.isLive()) s.alert("The phone battery is low. Tell the user briefly to plug in the charger.");
        } catch (Throwable t) {
            DebugLog.add("Battery alert failed: " + t);
        }
    }
}
