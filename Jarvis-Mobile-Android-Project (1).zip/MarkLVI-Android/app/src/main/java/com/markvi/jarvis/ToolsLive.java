package com.markvi.jarvis;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Live World tools. Every value comes from a real free service; if a service fails we say so, never invent. */
public final class ToolsLive {
    private ToolsLive() {}

    static void register() {
        reg("world_earth_open",
                "Opens Live World: a 3D globe with REAL live layers. layer = quakes (USGS earthquakes, last 24h), sats (ISS and satellites from real orbit data) or radar (real rain radar). Use for: earthquake map, where is ISS, track satellites, show radar, is rain coming. Empty layer opens the globe.",
                schema("", "layer:STRING:quakes, sats or radar"),
                (c, a) -> {
                    String l = a.optString("layer").trim().toLowerCase(Locale.ROOT);
                    if (l.startsWith("quake") || l.startsWith("earth")) l = "quakes";
                    else if (l.startsWith("sat") || l.startsWith("iss")) l = "sats";
                    else if (l.startsWith("rad") || l.startsWith("rain")) l = "radar";
                    else l = "";
                    if (l.isEmpty()) WorldActivity.send(c, J.obj("type", "globe"));
                    else WorldActivity.send(c, J.obj("type", "only", "name", l));
                    return J.ok("opened", "live world " + l);
                });

        reg("world_earth_close", "Closes the Live World globe.", schema(""), (c, a) -> {
            WorldActivity.closeIfOpen();
            return J.ok("closed", "live world");
        });

        reg("iss_now",
                "Real current position of the International Space Station (wheretheiss.at): latitude, longitude, altitude, speed and distance from the user. Tell the user out loud.",
                schema(""),
                (c, a) -> {
                    try {
                        JSONObject j = new JSONObject(get("https://api.wheretheiss.at/v1/satellites/25544"));
                        double la = j.getDouble("latitude"), ln = j.getDouble("longitude");
                        JSONObject r = J.ok("lat", la, "lng", ln, "altitude_km", Math.round(j.optDouble("altitude")),
                                "speed_kmh", Math.round(j.optDouble("velocity")), "visibility", j.optString("visibility"));
                        double[] me = EarthTools.userPos(c);
                        if (me != null) r.put("distance_from_you_km", Math.round(EarthTools.haversine(me[0], me[1], la, ln)));
                        return r;
                    } catch (Exception e) {
                        return J.fail("Could not reach the ISS service right now. I will not guess.");
                    }
                });

        reg("quakes_recent",
                "Real earthquakes of the last 24 hours (USGS, magnitude 2.5 and above): the strongest ones and the one nearest to the user. Tell the user out loud.",
                schema(""),
                (c, a) -> {
                    try {
                        JSONArray f = new JSONObject(get(
                                "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/2.5_day.geojson")).getJSONArray("features");
                        double[] me = EarthTools.userPos(c);
                        JSONObject best = null, near = null;
                        double nd = 1e12;
                        JSONArray top = new JSONArray();
                        for (int i = 0; i < f.length(); i++) {
                            JSONObject p = f.getJSONObject(i).getJSONObject("properties");
                            JSONArray g = f.getJSONObject(i).getJSONObject("geometry").getJSONArray("coordinates");
                            JSONObject q = J.obj("mag", p.optDouble("mag"), "place", p.optString("place"),
                                    "lat", g.getDouble(1), "lng", g.getDouble(0), "depth_km", g.optDouble(2));
                            if (best == null || q.optDouble("mag") > best.optDouble("mag")) best = q;
                            if (me != null) {
                                double d = EarthTools.haversine(me[0], me[1], q.optDouble("lat"), q.optDouble("lng"));
                                if (d < nd) { nd = d; near = q; q.put("distance_km", Math.round(d)); }
                            }
                            if (top.length() < 5 && p.optDouble("mag") >= 5) top.put(q);
                        }
                        JSONObject r = J.ok("count_24h", f.length());
                        if (best != null) r.put("strongest", best);
                        if (near != null) r.put("nearest_to_you", near);
                        r.put("m5_plus", top);
                        return r;
                    } catch (Exception e) {
                        return J.fail("Could not reach the USGS earthquake feed right now.");
                    }
                });

        reg("air_quality",
                "Real air quality (Open-Meteo / CAMS model) at the user's location or a given lat/lng: US AQI, PM2.5, PM10. Explain the level in the user's language.",
                schema("", "lat:NUMBER:optional latitude", "lng:NUMBER:optional longitude"),
                (c, a) -> {
                    double la, ln;
                    if (a.has("lat") && a.has("lng")) { la = a.optDouble("lat"); ln = a.optDouble("lng"); }
                    else {
                        double[] me = EarthTools.userPos(c);
                        if (me == null) return J.fail("Location is off. Turn Location on so I can check the air here.");
                        la = me[0]; ln = me[1];
                    }
                    try {
                        JSONObject cur0 = new JSONObject(get(
                                "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=" + la + "&longitude=" + ln
                                        + "&current=us_aqi,pm2_5,pm10&hourly=us_aqi&forecast_days=1"));
                        JSONObject cur = cur0.getJSONObject("current");
                        double peak = 0;
                        JSONArray hh = cur0.optJSONObject("hourly") == null ? null : cur0.getJSONObject("hourly").optJSONArray("us_aqi");
                        for (int i = 0; hh != null && i < hh.length(); i++) peak = Math.max(peak, hh.optDouble(i, 0));
                        int aqi = (int) Math.round(cur.getDouble("us_aqi"));
                        String lv = aqi <= 50 ? "Good" : aqi <= 100 ? "Moderate" : aqi <= 150 ? "Unhealthy for sensitive groups"
                                : aqi <= 200 ? "Unhealthy" : aqi <= 300 ? "Very unhealthy" : "Hazardous";
                        return J.ok("us_aqi", aqi, "level", lv, "pm2_5", cur.optDouble("pm2_5"), "pm10", cur.optDouble("pm10"),
                                "today_peak_aqi", Math.round(peak),
                                "advice", aqi <= 50 ? "Air is fine for outdoor activity." : aqi <= 100 ? "Acceptable; very sensitive people should limit long outdoor effort."
                                        : aqi <= 150 ? "Sensitive groups (asthma, children, elderly) should reduce outdoor time; a mask helps." : "Avoid long outdoor activity; wear an N95 mask outside.",
                                "time", cur.optString("time"), "source", "Open-Meteo CAMS model, not a ground sensor");
                    } catch (Exception e) {
                        return J.fail("Could not get air quality right now.");
                    }
                });

        reg("sky_tonight",
                "Real positions right now of the Moon and planets in the user's sky (NASA JPL Horizons): which are above the horizon, with compass direction and height. Use for: tonight's sky, where is Mars/Jupiter/Moon.",
                schema(""),
                (c, a) -> {
                    double[] me = EarthTools.userPos(c);
                    if (me == null) return J.fail("Location is off, so I cannot compute your sky. Turn Location on.");
                    String[][] bodies = {{"Moon", "301"}, {"Venus", "299"}, {"Mars", "499"}, {"Jupiter", "599"}, {"Saturn", "699"}, {"Mercury", "199"}};
                    JSONArray up = new JSONArray(), down = new JSONArray();
                    Calendar t = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
                    String t1 = String.format(Locale.US, "%tF %<tR", t);
                    t.add(Calendar.MINUTE, 2);
                    String t2 = String.format(Locale.US, "%tF %<tR", t);
                    int fails = 0;
                    for (String[] b : bodies) {
                        try {
                            String u = "https://ssd.jpl.nasa.gov/api/horizons.api?format=json&COMMAND='" + b[1]
                                    + "'&OBJ_DATA='NO'&MAKE_EPHEM='YES'&EPHEM_TYPE='OBSERVER'&CENTER='coord@399'&COORD_TYPE='GEODETIC'"
                                    + "&SITE_COORD='" + me[1] + "," + me[0] + ",0'&START_TIME='" + t1 + "'&STOP_TIME='" + t2
                                    + "'&STEP_SIZE='1m'&QUANTITIES='4'&CSV_FORMAT='YES'&ANG_FORMAT='DEG'";
                            String res = new JSONObject(get(u.replace("'", "%27").replace(" ", "%20"))).optString("result");
                            int s = res.indexOf("$$SOE"), e = res.indexOf("$$EOE");
                            if (s < 0 || e < 0) { fails++; continue; }
                            String line = res.substring(s + 5, e).trim().split("\n")[0];
                            Matcher m = Pattern.compile("(-?\\d+\\.\\d+)\\s*,\\s*(-?\\d+\\.\\d+)\\s*,?\\s*$").matcher(line.trim());
                            if (!m.find()) { fails++; continue; }
                            double az = Double.parseDouble(m.group(1)), el = Double.parseDouble(m.group(2));
                            JSONObject o = J.obj("body", b[0], "azimuth_deg", Math.round(az), "direction", EarthTools.compass(az),
                                    "height_deg", Math.round(el));
                            (el > 0 ? up : down).put(o);
                        } catch (Exception ex) { fails++; }
                    }
                    if (fails == bodies.length) return J.fail("Could not reach NASA Horizons right now.");
                    JSONObject r = J.ok("above_horizon", up, "below_horizon", down);
                    if (fails > 0) r.put("note", fails + " bodies could not be fetched");
                    return r;
                });

        reg("read_news",
                "Fetches real latest headlines from RSS and returns them for Mira to read aloud. source = bbc (BBC Bangla, default), prothomalo, dailystar, aljazeera, bbcworld, or a full RSS url. Read 5 headlines out loud, short.",
                schema("", "source:STRING:bbc, prothomalo or RSS url", "count:NUMBER:how many, default 5"),
                (c, a) -> {
                    String s = a.optString("source", "bbc").trim().toLowerCase(Locale.ROOT);
                    String url = s.startsWith("http") ? s : s.startsWith("prothom") ? "https://www.prothomalo.com/feed/"
                            : s.startsWith("daily") || s.startsWith("star") ? "https://www.thedailystar.net/frontpage/rss.xml"
                            : s.startsWith("jazeera") || s.startsWith("aljazeera") ? "https://www.aljazeera.com/xml/rss/all.xml"
                            : s.startsWith("bbcworld") ? "https://feeds.bbci.co.uk/news/world/rss.xml"
                            : "https://feeds.bbci.co.uk/bengali/rss.xml";
                    int n = Math.max(1, Math.min(10, a.optInt("count", 5)));
                    try {
                        String x = get(url);
                        Matcher m = Pattern.compile("<item[^>]*>.*?<title>(.*?)</title>", Pattern.DOTALL).matcher(x);
                        JSONArray h = new JSONArray();
                        while (m.find() && h.length() < n) {
                            String t = m.group(1).replace("<![CDATA[", "").replace("]]>", "").replace("&amp;", "&")
                                    .replace("&quot;", "\"").replace("&#39;", "'").trim();
                            if (!t.isEmpty()) h.put(t);
                        }
                        if (h.length() == 0) return J.fail("The news feed returned no headlines.");
                        return J.ok("source", url, "headlines", h);
                    } catch (Exception e) {
                        return J.fail("Could not reach the news feed right now.");
                    }
                });

        reg("money_rates",
                "Real USD to BDT rate (open.er-api.com) and real international gold spot price (gold-api.com) converted to BDT per gram and per bhori(11.664g). This is the world spot price, NOT the local jeweller price (Bajus); say so. Tell the user out loud.",
                schema(""),
                (c, a) -> {
                    JSONObject r = J.ok();
                    double bdt = 0;
                    try {
                        JSONObject j = new JSONObject(get("https://open.er-api.com/v6/latest/USD"));
                        bdt = j.getJSONObject("rates").getDouble("BDT");
                        r.put("usd_to_bdt", bdt);
                        r.put("rate_updated", j.optString("time_last_update_utc"));
                    } catch (Exception e) {
                        try {
                            JSONObject j = new JSONObject(get("https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json"));
                            bdt = j.getJSONObject("usd").getDouble("bdt");
                            r.put("usd_to_bdt", bdt);
                            r.put("rate_updated", j.optString("date") + " (backup source)");
                        } catch (Exception e2) { r.put("usd_error", "dollar rate unavailable"); }
                    }
                    try {
                        double oz = new JSONObject(get("https://api.gold-api.com/price/XAU")).getDouble("price");
                        r.put("gold_usd_per_oz", oz);
                        if (bdt > 0) {
                            double g = oz * bdt / 31.1035;
                            r.put("gold_bdt_per_gram_spot", Math.round(g));
                            r.put("gold_bdt_per_bhori_spot", Math.round(g * 11.664));
                        }
                        r.put("gold_note", "International spot price. Local Bajus/jeweller price is different and not available here.");
                    } catch (Exception e) {
                        try {
                            double xau = new JSONObject(get("https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json"))
                                    .getJSONObject("usd").getDouble("xau");
                            double oz = 1.0 / xau;
                            r.put("gold_usd_per_oz", Math.round(oz * 100) / 100.0);
                            if (bdt > 0) {
                                double g = oz * bdt / 31.1035;
                                r.put("gold_bdt_per_gram_spot", Math.round(g));
                                r.put("gold_bdt_per_bhori_spot", Math.round(g * 11.664));
                            }
                            r.put("gold_note", "International spot price (backup source). Local Bajus price is different and not available here.");
                        } catch (Exception e2) { r.put("gold_error", "gold price unavailable"); }
                    }
                    r.put("note", "Rates are mid-market, not the bank or kerb-market rate.");
                    return r;
                });

        reg("offline_mode",
                "Turns Mira's offline mode on or off, or changes the language the offline listener hears. action = on (always use offline mode, even with internet), off (offline mode only when there is no internet), lang_bn or lang_en, status.",
                schema("action", "action:STRING:on | off | lang_bn | lang_en | status"),
                (c, a) -> {
                    String x = a.optString("action").toLowerCase(Locale.ROOT);
                    SharedPreferences p = Prefs.sp(c);
                    if (x.equals("on")) p.edit().putBoolean("force_offline", true).apply();
                    else if (x.equals("off")) p.edit().putBoolean("force_offline", false).apply();
                    else if (x.equals("lang_bn")) p.edit().putString("whisper_lang", "bn").apply();
                    else if (x.equals("lang_en")) p.edit().putString("whisper_lang", "en").apply();
                    return J.ok("forced_offline", p.getBoolean("force_offline", false), "listen_language", p.getString("whisper_lang", "bn"),
                            "internet_now", OfflineMira.online(c), "whisper_model_ready", WhisperEngine.ready(c));
                });

        reg("auto_reply",
                "Turns Mira's AUTO-REPLY on or off, or changes it. Auto-reply answers new private chat messages (WhatsApp, Messenger, SMS, Telegram) from the notification reply box while the user is busy. It is OFF unless the user turns it on. "
                        + "action = on | off | status | set_text | ai_on | ai_off | log. text = the reply text for set_text. Never turn it on unless the user clearly asked.",
                schema("action", "action:STRING:on | off | status | set_text | ai_on | ai_off | log", "text:STRING:reply text for set_text"),
                (c, a) -> {
                    String x = a.optString("action").toLowerCase(Locale.ROOT);
                    SharedPreferences p = Prefs.sp(c);
                    if (x.equals("on")) {
                        if (!NotifCatcher.hasAccess(c)) return J.fail("Notification access is OFF. Turn it on in Settings first, then ask again.");
                        AutoReply.setEnabled(c, true);
                    } else if (x.equals("off")) AutoReply.setEnabled(c, false);
                    else if (x.equals("ai_on")) p.edit().putBoolean("ar_ai", true).apply();
                    else if (x.equals("ai_off")) p.edit().putBoolean("ar_ai", false).apply();
                    else if (x.equals("set_text") && !a.optString("text").trim().isEmpty()) p.edit().putString("ar_text", a.optString("text").trim()).apply();
                    else if (x.equals("log")) return J.ok("log", AutoReply.logText(c));
                    return J.ok("auto_reply_on", AutoReply.enabled(c), "reply_text", p.getString("ar_text", AutoReply.DEFAULT_TEXT),
                            "ai_text", p.getBoolean("ar_ai", false), "notification_access", NotifCatcher.hasAccess(c),
                            "note", "Replies only to private chats, never groups, once per person per cooldown. Delivery cannot be confirmed.");
                });

        reg("expense_month",
                "Adds up this month's real spending from the user's own SMS (bKash/Nagad/bank debit messages that contain an amount in Tk/BDT) plus expenses the user told Mira to note. Needs SMS permission. Tell the total and the count; mention it only counts messages it could parse.",
                schema(""),
                (c, a) -> {
                    double sms = 0, today = 0, week = 0; int n = 0;
                    java.util.Map<String, Double> by = new java.util.TreeMap<>();
                    long now = System.currentTimeMillis();
                    Calendar d0 = Calendar.getInstance(); d0.set(Calendar.HOUR_OF_DAY, 0); d0.set(Calendar.MINUTE, 0); d0.set(Calendar.SECOND, 0);
                    try {
                        Calendar cal = Calendar.getInstance();
                        cal.set(Calendar.DAY_OF_MONTH, 1); cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0);
                        Pattern amt = Pattern.compile("(?:Tk\\.?|BDT|৳)\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)", Pattern.CASE_INSENSITIVE);
                        Pattern out = Pattern.compile("(payment|cash ?out|sent|send money|purchase|debited|withdraw|paid|bill)", Pattern.CASE_INSENSITIVE);
                        Pattern inn = Pattern.compile("(received|cash ?in|credited|deposit|refund)", Pattern.CASE_INSENSITIVE);
                        try (Cursor cu = c.getContentResolver().query(Uri.parse("content://sms/inbox"), new String[]{"body", "address", "date"},
                                "date>=?", new String[]{String.valueOf(cal.getTimeInMillis())}, null)) {
                            while (cu != null && cu.moveToNext()) {
                                String b = cu.getString(0);
                                if (b == null || !out.matcher(b).find() || inn.matcher(b).find()) continue;
                                Matcher m = amt.matcher(b);
                                if (m.find()) {
                                    double v = Double.parseDouble(m.group(1).replace(",", ""));
                                    sms += v; n++;
                                    long dt = cu.getLong(2);
                                    if (dt >= d0.getTimeInMillis()) today += v;
                                    if (now - dt <= 7L * 86400000L) week += v;
                                    String ad = cu.getString(1);
                                    by.merge(ad == null ? "other" : ad, v, Double::sum);
                                }
                            }
                        }
                    } catch (SecurityException se) {
                        return J.fail("SMS permission is not granted. Allow SMS for Mira in Setup.");
                    } catch (Exception e) { /* fall through with what we have */ }
                    double man = 0; int mn = 0;
                    try {
                        JSONArray arr = new JSONArray(sp(c).getString("list", "[]"));
                        String ym = String.format(Locale.US, "%tY-%<tm", Calendar.getInstance());
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject o = arr.getJSONObject(i);
                            if (o.optString("d").startsWith(ym)) { man += o.optDouble("amt"); mn++; }
                        }
                    } catch (Exception e) { /* ignore */ }
                    return J.ok("sms_total_tk", Math.round(sms), "sms_count", n, "noted_total_tk", Math.round(man), "noted_count", mn,
                            "grand_total_tk", Math.round(sms + man), "sms_today_tk", Math.round(today), "sms_last7days_tk", Math.round(week),
                            "by_sender", new JSONObject(by),
                            "note", "Only SMS with a Tk/BDT amount and a payment-type word are counted; some may be missed.");
                });

        reg("expense_note",
                "Saves an expense the user dictates, e.g. 'write down 500 taka for lunch'.",
                schema("amount", "amount:NUMBER:amount in taka", "note:STRING:what it was for"),
                (c, a) -> {
                    try {
                        double amt = a.getDouble("amount");
                        JSONArray arr = new JSONArray(sp(c).getString("list", "[]"));
                        arr.put(J.obj("amt", amt, "note", a.optString("note"), "d", String.format(Locale.US, "%tF", Calendar.getInstance())));
                        sp(c).edit().putString("list", arr.toString()).apply();
                        return J.ok("saved_tk", amt);
                    } catch (Exception e) { return J.fail("Could not save the expense."); }
                });
    }

    /** GET with one retry; real data or an exception, never a made-up value. */
    private static String get(String url) throws Exception {
        try { return GeminiRest.httpGet(url); }
        catch (Exception e) { Thread.sleep(600); return GeminiRest.httpGet(url); }
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("mira_expenses", Context.MODE_PRIVATE);
    }
}
