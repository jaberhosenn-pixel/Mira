package com.markvi.jarvis;

import android.app.NotificationManager;
import android.app.WallpaperManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.KeyEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import okhttp3.Request;
import okhttp3.Response;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Phone-native tools: apps, settings, messaging, calls, alarms, navigation, clipboard, calendar. */
public final class ToolsPhone {
    private ToolsPhone() {}

    private static boolean torchOn;

    static void register() {
        reg("open_app",
                "Opens an application on this phone. Use whenever the user asks to open, launch or start any app. "
                        + "Put the app's real name in app_name (expand nicknames: 'wp' is WhatsApp, 'fb' is Facebook). "
                        + "Answers immediately: on status=started say only that it is opening. To go back or close an app use screen_control.",
                schema("app_name", "app_name:STRING:the application's real name"),
                (c, a) -> openApp(c, a.optString("app_name")));

        reg("app_search",
                "Opens an app AND searches inside it, all the way to the results (Google, Chrome, YouTube, Maps, Play Store or any app with a "
                        + "search box). Use this whenever the user says 'open X and search Y'. Never use open_app + typing for that.",
                schema("app_name,query",
                        "app_name:STRING:google | chrome | youtube | maps | play store | any other app",
                        "query:STRING:what to search for"),
                (c, a) -> appSearch(c, a.optString("app_name"), a.optString("query")));

        reg("phone_settings",
                "Controls the phone: volume (volume_up, volume_down, volume_set with level 0-100, mute, unmute), brightness "
                        + "(brightness_up, brightness_down, brightness_set), flashlight (flashlight_on, flashlight_off, flashlight_toggle), "
                        + "media (play_pause, next_track, prev_track), do_not_disturb_on/off, ringer_normal/ringer_vibrate/ringer_silent, hotspot, and opening system panels: wifi, bluetooth, "
                        + "airplane, mobile_data, location, display, sound, battery, storage, apps, accessibility, all_settings. "
                        + "Volume and brightness changes can be reversed with undo.",
                schema("action",
                        "action:STRING:the exact action name",
                        "level:INTEGER:0-100 for volume_set or brightness_set"),
                (c, a) -> phoneSettings(c, a));

        reg("send_message",
                "Sends a text message. platform: sms (sent directly after on-screen approval), whatsapp, telegram, messenger, signal, "
                        + "instagram or email. Write message_text in the USER'S OWN LANGUAGE, exactly what they asked. "
                        + "SMS goes to the network but delivery cannot be confirmed; WhatsApp/Telegram are driven through the app screen. "
                        + "Never say 'sent' unless status=done; for 'unverified' say nobody can confirm it arrived.",
                schema("receiver,message_text,platform",
                        "receiver:STRING:contact name, phone number or email address",
                        "message_text:STRING:the message (for email: the body)",
                        "platform:STRING:sms | whatsapp | telegram | messenger | signal | instagram | email",
                        "subject:STRING:email subject line (email only)"),
                (c, a) -> sendMessage(c, a));

        reg("make_call",
                "Calls a person by contact name or phone number after the user approves on screen. Say you are calling before the tool.",
                schema("receiver", "receiver:STRING:contact name or number"),
                (c, a) -> makeCall(c, a.optString("receiver")));

        reg("find_contact",
                "Looks up phone numbers of contacts by name.",
                schema("name", "name:STRING:contact name to search"),
                (c, a) -> J.ok("contacts", Util.findContacts(c, a.optString("name"))));

        reg("set_alarm_timer",
                "Sets an alarm clock (type=alarm, hour 0-23, minute) or a countdown timer (type=timer, seconds) in the phone's clock app.",
                schema("type",
                        "type:STRING:alarm | timer",
                        "hour:INTEGER:0-23 for alarm",
                        "minute:INTEGER:0-59 for alarm",
                        "seconds:INTEGER:length of timer in seconds",
                        "label:STRING:optional label"),
                (c, a) -> alarmTimer(c, a));

        reg("navigate",
                "Starts turn-by-turn navigation to a place in Google Maps. mode: driving (default), walking, bicycling, transit.",
                schema("destination",
                        "destination:STRING:address or place name",
                        "mode:STRING:driving | walking | bicycling | transit"),
                (c, a) -> navigate(c, a));

        reg("clipboard",
                "Reads or writes the clipboard. action: read | write (with text).",
                schema("action", "action:STRING:read | write", "text:STRING:text to copy"),
                (c, a) -> clipboard(c, a));

        reg("calendar_event",
                "Opens a pre-filled new calendar event for the user to save. begin and end are 'YYYY-MM-DD HH:MM' in local time.",
                schema("title,begin",
                        "title:STRING:event title",
                        "begin:STRING:start 'YYYY-MM-DD HH:MM'",
                        "end:STRING:end 'YYYY-MM-DD HH:MM' (default one hour)",
                        "location:STRING:optional place",
                        "description:STRING:optional notes"),
                (c, a) -> calendar(c, a));

        reg("where_am_i",
                "Returns the phone's last known location coordinates (needs location permission).",
                schema(""),
                (c, a) -> whereAmI(c));

        reg("set_wallpaper",
                "Sets the phone's wallpaper from an image URL.",
                schema("url", "url:STRING:direct image URL"),
                (c, a) -> wallpaper(c, a.optString("url")));
    }

    // ------------------------------------------------------------------ open_app

    /** {package, name, other spellings...} */
    private static final String[][] ALIASES = {
        {"com.android.vending", "Play Store", "play store", "playstore", "google play", "google play store", "প্লে স্টোর", "প্লে স্টোরে", "প্লেস্টোর", "গুগল প্লে", "গুগল প্লে স্টোর"},
        {"com.whatsapp", "WhatsApp", "whatsapp", "whats app", "wp", "হোয়াটসঅ্যাপ", "হোয়াটস অ্যাপ", "হোয়াটসএপ", "ওয়াটসঅ্যাপ", "হোয়াটসঅ্যাপে"},
        {"com.google.android.youtube", "YouTube", "youtube", "you tube", "ইউটিউব", "ইউটিউবে"},
        {"com.facebook.katana", "Facebook", "facebook", "fb", "ফেসবুক", "ফেসবুকে"},
        {"com.facebook.orca", "Messenger", "messenger", "মেসেঞ্জার", "মেসেঞ্জারে"},
        {"com.android.chrome", "Chrome", "chrome", "ক্রোম"},
        {"com.google.android.gm", "Gmail", "gmail", "জিমেইল", "জিমেইলে"},
        {"com.google.android.apps.maps", "Maps", "maps", "google maps", "গুগল ম্যাপ", "ম্যাপ"},
        {"com.instagram.android", "Instagram", "instagram", "insta", "ইনস্টাগ্রাম"},
        {"org.telegram.messenger", "Telegram", "telegram", "টেলিগ্রাম"},
        {"com.android.settings", "Settings", "settings", "সেটিংস", "সেটিং"},
        {"com.google.android.googlequicksearchbox", "Google", "google", "গুগল"},
    };

    private static JSONObject openApp(Context c, String name) throws Exception {
        if (name == null || name.trim().isEmpty()) return J.fail("app_name is empty");
        String q = name.trim().toLowerCase(Locale.ROOT);
        PackageManager pm = c.getPackageManager();
        // well-known apps by name, in English or Bangla: open the exact app at once (never a look-alike such as Google)
        String key = q.replaceAll("[\\s\\-_.]+", "");
        for (String[] row : ALIASES) {
            for (int k = 1; k < row.length; k++) {
                if (row[k].replaceAll("[\\s\\-_.]+", "").equals(key)) {
                    Intent direct = pm.getLaunchIntentForPackage(row[0]);
                    if (direct != null) {
                        Util.launch(c, direct);
                        return J.started("app", row[1]);
                    }
                }
            }
        }
        Intent main = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo ri : apps) {
            String label = String.valueOf(ri.loadLabel(pm)).toLowerCase(Locale.ROOT);
            String pkg = ri.activityInfo.packageName.toLowerCase(Locale.ROOT);
            int s = 0;
            if (label.equals(q)) s = 100;
            else if (label.startsWith(q)) s = 80;
            else if (label.contains(q)) s = 60;
            else if (pkg.contains(q.replace(" ", ""))) s = 40;
            if (s > bestScore) {
                bestScore = s;
                best = ri;
            }
        }
        if (best == null) return J.fail("no installed app matches '" + name + "'");
        Intent li = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
        if (li == null) return J.fail("cannot launch " + best.activityInfo.packageName);
        Util.launch(c, li);
        return J.started("app", String.valueOf(best.loadLabel(pm)));
    }

    private static JSONObject appSearch(Context c, String app, String query) throws Exception {
        if (query == null || query.trim().isEmpty()) return J.fail("query is empty");
        String a = Util.lower(app).trim();
        String q = URLEncoder.encode(query.trim(), "UTF-8");
        if (a.isEmpty() || a.contains("google") || a.contains("chrome") || a.contains("browser") || a.equals("web")) {
            Util.launch(c, new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + q)));
            return J.started("searched", query + " on Google (results page opened)");
        }
        if (a.contains("youtube")) {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + q));
            if (installed(c, "com.google.android.youtube")) i.setPackage("com.google.android.youtube");
            Util.launch(c, i);
            return J.started("searched", query + " on YouTube");
        }
        if (a.contains("map")) {
            Intent mi = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + q));
            if (installed(c, "com.google.android.apps.maps")) mi.setPackage("com.google.android.apps.maps");
            Util.launch(c, mi);
            return J.started("searched", query + " on Maps (results opened); say navigate to start directions");
        }
        if (a.contains("play") || a.contains("store")) {
            Util.launch(c, new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + q)));
            return J.started("searched", query + " on Play Store");
        }
        // any other app: open it, tap its search box, type, press Enter
        JSONObject opened = openApp(c, app);
        if (!"started".equals(opened.optString("status"))) return opened;
        JarvisAccessibility acc = JarvisAccessibility.get();
        if (acc == null) {
            return J.started("note", app + " opened, but typing needs the Accessibility service; ask the user to turn it on in Settings");
        }
        boolean focused = false;
        long until = System.currentTimeMillis() + 6000;
        try {
            Thread.sleep(700);
            while (!(focused = acc.focusSearchField()) && System.currentTimeMillis() < until) Thread.sleep(300);
        } catch (InterruptedException ignored) {
        }
        boolean typed = focused && acc.typeText(query.trim(), false);
        boolean entered = typed && acc.pressEnter();
        if (entered) return J.obj("status", "unverified", "note", "searched in " + app + " and pressed Enter");
        if (typed) return J.started("note", "typed the query in " + app + " but could not press Enter");
        return J.started("note", app + " opened but its search box was not found");
    }

    // ------------------------------------------------------------------ settings

    private static JSONObject phoneSettings(final Context c, JSONObject a) throws Exception {
        String act = a.optString("action").toLowerCase(Locale.ROOT).trim();
        final AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        final int cur = am.getStreamVolume(AudioManager.STREAM_MUSIC);

        switch (act) {
            case "volume_up":
            case "volume_down":
            case "volume_set": {
                int target;
                if (act.equals("volume_up")) target = Math.min(max, cur + Math.max(1, max / 8));
                else if (act.equals("volume_down")) target = Math.max(0, cur - Math.max(1, max / 8));
                else target = Math.round(max * Math.max(0, Math.min(100, a.optInt("level", 50))) / 100f);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0);
                Util.pushUndo("volume " + cur + "/" + max, () -> am.setStreamVolume(AudioManager.STREAM_MUSIC, cur, 0));
                return J.ok("volume_percent", Math.round(target * 100f / max));
            }
            case "mute": {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
                Util.pushUndo("volume " + cur + "/" + max, () -> am.setStreamVolume(AudioManager.STREAM_MUSIC, cur, 0));
                return J.ok("volume_percent", 0);
            }
            case "unmute": {
                int t = Math.max(1, max / 2);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, t, 0);
                return J.ok("volume_percent", Math.round(t * 100f / max));
            }
            case "brightness_up":
            case "brightness_down":
            case "brightness_set": {
                if (!Settings.System.canWrite(c)) {
                    Util.launch(c, new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.getPackageName())));
                    return J.fail("Brightness needs 'Modify system settings' permission; I opened the page. Ask the user to allow it.");
                }
                final int old = Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
                final int oldMode = Settings.System.getInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                int t;
                if (act.equals("brightness_up")) t = Math.min(255, old + 40);
                else if (act.equals("brightness_down")) t = Math.max(5, old - 40);
                else t = Math.max(1, Math.min(255, Math.round(255f * a.optInt("level", 50) / 100f)));
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, t);
                Util.pushUndo("brightness", () -> {
                    Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, old);
                    Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, oldMode);
                });
                return J.ok("brightness_percent", Math.round(t * 100f / 255f));
            }
            case "flashlight_on":
                return torch(c, true);
            case "flashlight_off":
                return torch(c, false);
            case "flashlight_toggle":
                return torch(c, !torchOn);
            case "ringer_normal":
            case "ringer_vibrate":
            case "ringer_silent": {
                try {
                    int mode = act.equals("ringer_normal") ? AudioManager.RINGER_MODE_NORMAL
                            : act.equals("ringer_vibrate") ? AudioManager.RINGER_MODE_VIBRATE : AudioManager.RINGER_MODE_SILENT;
                    am.setRingerMode(mode);
                    return J.ok();
                } catch (SecurityException se) {
                    Util.launch(c, new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                    return J.fail("Silent mode needs Do Not Disturb access; I opened the page. Ask the user to allow it.");
                }
            }
            case "hotspot": {
                try {
                    Util.launch(c, new Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"));
                } catch (Exception e) {
                    Util.launch(c, new Intent(Settings.ACTION_WIRELESS_SETTINGS));
                }
                return J.ok("note", "Opened the hotspot page; Android does not let apps switch it on directly.");
            }
            case "play_pause":
                media(am, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE);
                return J.ok();
            case "next_track":
                media(am, KeyEvent.KEYCODE_MEDIA_NEXT);
                return J.ok();
            case "prev_track":
                media(am, KeyEvent.KEYCODE_MEDIA_PREVIOUS);
                return J.ok();
            case "do_not_disturb_on":
            case "do_not_disturb_off": {
                NotificationManager nm = c.getSystemService(NotificationManager.class);
                if (!nm.isNotificationPolicyAccessGranted()) {
                    Util.launch(c, new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
                    return J.fail("Do Not Disturb needs special access; I opened the page. Ask the user to allow Mira.");
                }
                nm.setInterruptionFilter(act.endsWith("_on") ? NotificationManager.INTERRUPTION_FILTER_NONE
                        : NotificationManager.INTERRUPTION_FILTER_ALL);
                return J.ok();
            }
            default:
                break;
        }

        String panel = null;
        switch (act) {
            case "wifi": panel = Settings.ACTION_WIFI_SETTINGS; break;
            case "bluetooth": panel = Settings.ACTION_BLUETOOTH_SETTINGS; break;
            case "airplane": panel = Settings.ACTION_AIRPLANE_MODE_SETTINGS; break;
            case "mobile_data": panel = Settings.ACTION_DATA_ROAMING_SETTINGS; break;
            case "location": panel = Settings.ACTION_LOCATION_SOURCE_SETTINGS; break;
            case "display": panel = Settings.ACTION_DISPLAY_SETTINGS; break;
            case "sound": panel = Settings.ACTION_SOUND_SETTINGS; break;
            case "battery": panel = Intent.ACTION_POWER_USAGE_SUMMARY; break;
            case "storage": panel = Settings.ACTION_INTERNAL_STORAGE_SETTINGS; break;
            case "apps": panel = Settings.ACTION_APPLICATION_SETTINGS; break;
            case "accessibility": panel = Settings.ACTION_ACCESSIBILITY_SETTINGS; break;
            case "all_settings": panel = Settings.ACTION_SETTINGS; break;
            default: break;
        }
        if (panel == null) return J.fail("unknown action '" + act + "'");
        Util.launch(c, new Intent(panel));
        return J.started("opened", act + " settings (Android does not let apps flip this switch directly)");
    }

    private static void media(AudioManager am, int code) {
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    static JSONObject torch(Context c, boolean on) throws Exception {
        CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
        for (String id : cm.getCameraIdList()) {
            CameraCharacteristics ch = cm.getCameraCharacteristics(id);
            Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
            if (flash != null && flash) {
                cm.setTorchMode(id, on);
                torchOn = on;
                return J.ok("flashlight", on ? "on" : "off");
            }
        }
        return J.fail("this phone has no flashlight");
    }

    // ------------------------------------------------------------------ messaging

    private static String packageFor(String platform) {
        switch (platform) {
            case "whatsapp": return "com.whatsapp";
            case "telegram": return "org.telegram.messenger";
            case "messenger": return "com.facebook.orca";
            case "signal": return "org.thoughtcrime.securesms";
            case "instagram": return "com.instagram.android";
            default: return null;
        }
    }

    private static boolean installed(Context c, String pkg) {
        try {
            c.getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static JSONObject sendMessage(Context c, JSONObject a) throws Exception {
        String who = Util.collapseSpelled(a.optString("receiver").trim());
        String text = a.optString("message_text");
        String platform = a.optString("platform", "sms").toLowerCase(Locale.ROOT).trim();
        if (who.isEmpty() || text.isEmpty()) return J.fail("receiver and message_text are required");

        boolean isSms = platform.equals("sms") || platform.equals("text") || platform.equals("message");
        if (!isSms && JarvisAccessibility.get() == null) {
            return J.fail("Accessibility is OFF, so Mira cannot press Send by herself. Tell the user: open Settings > Open All Permissions > Accessibility, "
                    + "turn Mira ON (if it is greyed out: App info > top-right menu > Allow restricted settings). Nothing was sent.");
        }
        if (platform.equals("email")) {
            String subj = a.optString("subject");
            Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(who.trim(), "@,;")
                    + "?subject=" + Uri.encode(subj) + "&body=" + Uri.encode(text)));
            if (installed(c, "com.google.android.gm")) i.setPackage("com.google.android.gm");
            Util.launch(c, i);
            boolean clicked = JarvisAccessibility.autoPressSend(8000);
            return clicked ? J.obj("status", "unverified", "note", "email composer opened and Send was pressed")
                    : J.started("note", "email composer opened with the text; the user must press Send");
        }

        if (platform.equals("sms") || platform.equals("text") || platform.equals("message")) {
            String number = Util.resolveNumber(c, who);
            if (number == null) return J.fail("no contact or number found for '" + who + "'");
            if (!Bus.confirm("Send SMS to " + who + " (" + number + "):\n\n" + text)) {
                return J.obj("status", "declined", "note", "the user did not approve on screen");
            }
            SmsManager sm = Build.VERSION.SDK_INT >= 31 ? c.getSystemService(SmsManager.class) : SmsManager.getDefault();
            ArrayList<String> parts = sm.divideMessage(text);
            sm.sendMultipartTextMessage(number, null, parts, null, null);
            return J.obj("status", "unverified", "note", "handed to the mobile network; delivery cannot be confirmed");
        }

        String pkg = packageFor(platform);
        if (pkg == null) return J.fail("unsupported platform: " + platform);
        if (!installed(c, pkg)) return J.fail(platform + " is not installed");

        if (platform.equals("whatsapp")) {
            String number = Util.resolveNumber(c, who);
            if (number == null) DebugLog.add("WhatsApp: no contact number found for '" + who + "'; using the share-and-pick flow");
            if (number != null) {
                String digits = Util.digitsOnly(Util.e164(c, number));
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits + "?text="
                        + URLEncoder.encode(text, "UTF-8")));
                i.setPackage(pkg);
                Util.launch(c, i);
                boolean clicked = JarvisAccessibility.autoPressSend(16000);
                if (!clicked && JarvisAccessibility.get() != null) clicked = JarvisAccessibility.tapSendCorner();
                if (!clicked) clicked = ToolsApps.agent(c, "WhatsApp has a chat open with a message already typed in the box. Press the Send button once so it is sent. If the box is empty and the message already shows in the chat, answer done.", 6);
                return clicked ? J.obj("status", "unverified", "note", "Send was pressed in WhatsApp; nobody can confirm arrival")
                        : J.started("note", "WhatsApp chat opened with the text typed; the Accessibility service is off or Send was not found");
            }
        }

        // generic: share the text into the app, then pick the contact on screen and press Send
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text).setPackage(pkg);
        Util.launch(c, i);
        if (JarvisAccessibility.get() == null) {
            return J.started("note", platform + " opened with the text; Accessibility is off, so the user must pick '" + who + "' and press Send");
        }
        List<String> names = Util.nameVariants(c, who);
        String[] fz = Util.fuzzyContact(c, who);
        if (fz != null && !names.contains(fz[0])) names.add(0, fz[0]);
        boolean tapped = JarvisAccessibility.tapAnyTextWithin(names, 4000);
        if (!tapped) tapped = JarvisAccessibility.tapFuzzyName(who, 3000);
        if (!tapped) {
            // use the app's own search box, then tap the result
            JarvisAccessibility s = JarvisAccessibility.get();
            if (s != null && s.focusSearchField() && s.typeText(names.get(0), false)) {
                try {
                    Thread.sleep(900);
                } catch (InterruptedException ignored) {
                }
                tapped = JarvisAccessibility.tapAnyTextWithin(names, 4000);
                if (!tapped) tapped = JarvisAccessibility.tapFuzzyName(who, 3000);
            }
        }
        if (!tapped) {
            tapped = ToolsApps.agent(c, "In " + platform + " a list of chats/contacts is shown to share a message with. Pick the one named '" + who
                    + "' (use the search box or scroll if needed). Only pick a name that clearly matches; if there is no such name answer fail. Do not press Send yet.", 8);
        }
        DebugLog.add(platform + " share flow: names tried " + names + ", contact tapped=" + tapped);
        if (!tapped) {
            JarvisAccessibility sc = JarvisAccessibility.get();
            DebugLog.add("Screen now: " + (sc == null ? "" : sc.readScreen(500).replace("\n", " | ")));
        }
        // sharing has 1 to 3 Send steps (pick, preview, confirm): press until no Send button is left
        boolean sent = false;
        if (tapped) {
            for (int k = 0; k < 3; k++) {
                boolean pressed = JarvisAccessibility.autoPressSend(k == 0 ? 9000 : 4000);
                if (!pressed) break;
                sent = true;
                try {
                    Thread.sleep(1200);
                } catch (InterruptedException ignored) {
                }
                if (!JarvisAccessibility.sendVisible()) break;
            }
        }
        if (!sent && tapped) {
            sent = ToolsApps.agent(c, "The message '" + (text.length() > 60 ? text.substring(0, 60) : text) + "' is ready to send to " + who + " in " + platform
                    + ". Press Send (once or twice if a confirmation appears) until it is sent. If it already shows as sent, answer done.", 8);
        }
        if (sent) return J.obj("status", "unverified", "note", "contact picked and Send pressed; nobody can confirm arrival");
        if (tapped) return J.started("note", "contact selected; Send could not be found, the user may need to press it");
        JarvisAccessibility sc2 = JarvisAccessibility.get();
        return J.started("note", platform + " opened with the text; contact '" + who + "' was not found on screen. Screen text: "
                + (sc2 == null ? "" : sc2.readScreen(400).replace("\n", " | ")) + " (you may continue with ui_flow using the real names on screen)");
    }

    private static JSONObject makeCall(Context c, String who) throws Exception {
        String number = Util.resolveNumber(c, who);
        if (number == null) return J.fail("no contact or number found for '" + who + "'");
        if (!Bus.confirm("Call " + who + " (" + number + ")?")) {
            return J.obj("status", "declined", "note", "the user did not approve on screen");
        }
        boolean granted = c.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
        Uri u = Uri.parse("tel:" + Uri.encode(number));
        Util.launch(c, new Intent(granted ? Intent.ACTION_CALL : Intent.ACTION_DIAL, u));
        return J.started("calling", who + " " + number, "note", granted ? "dialling" : "dialler opened; the user must press call");
    }

    // ------------------------------------------------------------------ misc

    private static JSONObject alarmTimer(Context c, JSONObject a) {
        String type = a.optString("type", "alarm").toLowerCase(Locale.ROOT);
        String label = a.optString("label", "Jarvis");
        Intent i;
        if (type.equals("timer")) {
            int sec = a.optInt("seconds", 60);
            i = new Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        } else {
            i = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        }
        Util.launch(c, i);
        return J.started("type", type);
    }

    private static JSONObject navigate(Context c, JSONObject a) throws Exception {
        String dest = a.optString("destination");
        String mode = a.optString("mode", "driving").toLowerCase(Locale.ROOT);
        String m = mode.startsWith("walk") ? "w" : mode.startsWith("bic") ? "b" : mode.startsWith("trans") ? "r" : "d";
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + URLEncoder.encode(dest, "UTF-8") + "&mode=" + m));
        i.setPackage("com.google.android.apps.maps");
        try {
            Util.launch(c, i);
        } catch (Exception e) {
            Util.launch(c, new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + URLEncoder.encode(dest, "UTF-8"))));
        }
        return J.started("navigating_to", dest);
    }

    private static JSONObject clipboard(Context c, JSONObject a) {
        ClipboardManager cb = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
        if (a.optString("action").equalsIgnoreCase("write")) {
            cb.setPrimaryClip(ClipData.newPlainText("jarvis", a.optString("text")));
            return J.ok();
        }
        ClipData d = cb.getPrimaryClip();
        if (d == null || d.getItemCount() == 0) {
            return J.ok("clipboard", "(empty or not readable while the app is in the background)");
        }
        CharSequence t = d.getItemAt(0).coerceToText(c);
        return J.ok("clipboard", J.untrusted("clipboard", String.valueOf(t)));
    }

    private static JSONObject calendar(Context c, JSONObject a) throws Exception {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        Date b = f.parse(a.optString("begin"));
        if (b == null) return J.fail("could not read begin time");
        Date e = a.optString("end").isEmpty() ? new Date(b.getTime() + 3600000L) : f.parse(a.optString("end"));
        if (e == null) e = new Date(b.getTime() + 3600000L);
        Intent i = new Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, a.optString("title"))
                .putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("location"))
                .putExtra(CalendarContract.Events.DESCRIPTION, a.optString("description"))
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, b.getTime())
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, e.getTime());
        Util.launch(c, i);
        return J.started("note", "calendar form opened; the user must tap Save");
    }

    private static JSONObject whereAmI(Context c) {
        LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
        Location best = null;
        for (String p : lm.getProviders(true)) {
            Location l = lm.getLastKnownLocation(p);
            if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
        }
        if (best == null) return J.fail("no location available (permission or location is off)");
        return J.ok("latitude", best.getLatitude(), "longitude", best.getLongitude(),
                "age_minutes", (System.currentTimeMillis() - best.getTime()) / 60000L);
    }

    private static JSONObject wallpaper(Context c, String url) throws Exception {
        if (url == null || url.isEmpty()) return J.fail("url is empty");
        Request req = new Request.Builder().url(url).build();
        try (Response r = GeminiRest.HTTP.newCall(req).execute()) {
            if (!r.isSuccessful() || r.body() == null) return J.fail("download failed: HTTP " + r.code());
            byte[] data = r.body().bytes();
            Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
            if (bmp == null) return J.fail("that URL is not an image");
            WallpaperManager.getInstance(c).setBitmap(bmp);
        }
        return J.ok();
    }
}
