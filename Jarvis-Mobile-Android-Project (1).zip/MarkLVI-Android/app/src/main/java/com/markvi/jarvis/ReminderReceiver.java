package com.markvi.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Fires a reminder: notification, and a spoken alert when a live session is running. */
public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String msg = i.getStringExtra("msg");
        int id = i.getIntExtra("id", 1);
        if (msg == null) msg = "Reminder";
        String title = i.getStringExtra("title");
        if (title == null) title = "Reminder";
        Util.notifyAlert(c, id, title, msg);
        String rt = i.getStringExtra("routine_time");
        if (rt != null) ToolsFinal.scheduleRoutine(c, id, rt, msg);
        JarvisService s = JarvisService.get();
        if (s != null && s.isLive()) s.alert(("Routine".equals(title) ? "Daily routine now: " : "Reminder due now: ") + msg);
    }
}
