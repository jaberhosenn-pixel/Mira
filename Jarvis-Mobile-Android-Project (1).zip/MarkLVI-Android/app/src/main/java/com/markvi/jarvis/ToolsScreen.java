package com.markvi.jarvis;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Surface;

import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Eyes and hands on the phone: screen_process (see), screen_control (tap, type, scroll, buttons). */
public final class ToolsScreen {
    private ToolsScreen() {}

    static void register() {
        reg("screen_process",
                "Captures the phone's SCREEN or the CAMERA and lets you look at it. MUST be called when the user asks what is on the screen, "
                        + "what you see, to look at something with the camera, to read this page, etc. You have NO visual ability without this tool. "
                        + "The image is sent to you right after; describe it and answer the question. angle: 'screen' (needs Accessibility) or "
                        + "'camera' (rear camera; 'front' for the selfie camera; the app must be on screen).",
                schema("text",
                        "angle:STRING:screen | camera | front",
                        "text:STRING:the question or instruction about the image"),
                (c, a) -> screenProcess(c, a));

        reg("close_camera", "Closes the camera preview on the HUD. Call when the user says close or stop the camera.",
                schema(""),
                (c, a) -> {
                    Bus.Ui u = Bus.ui;
                    if (u != null) u.onImage(null, "");
                    return J.ok();
                });

        reg("screen_control",
                "Operates the phone like a person would, through the Accessibility service. Actions: read (list the visible text), "
                        + "tap_text (tap the button or label with that text), tap_xy (x,y as PERCENT of the screen 0-100), long_press_xy, "
                        + "swipe (direction up/down/left/right), scroll_down, scroll_up, type_text (types into the focused or first input field; "
                        + "append=false replaces), enter (press Search/Enter on the keyboard), focus_search (tap the search box), back, home, recents, notifications, quick_settings, lock_screen, screenshot (saves a screenshot), "
                        + "power_menu. Prefer a dedicated tool when one exists (open_app, make_call...). Use read first when unsure what is on screen.",
                schema("action",
                        "action:STRING:the exact action name",
                        "text:STRING:text to tap or type",
                        "x:NUMBER:percent from left 0-100",
                        "y:NUMBER:percent from top 0-100",
                        "direction:STRING:up | down | left | right",
                        "append:BOOLEAN:type_text: add to existing text instead of replacing"),
                (c, a) -> screenControl(c, a));
    }

    private static JSONObject needAccessibility() {
        return J.fail("The Accessibility service is not enabled. Ask the user to open Mira Settings and turn on 'Accessibility control'.");
    }

    private static JSONObject screenControl(Context c, JSONObject a) {
        JarvisAccessibility s = JarvisAccessibility.get();
        if (s == null) return needAccessibility();
        String act = a.optString("action").toLowerCase(Locale.ROOT).trim();
        int[] sz = s.screenSize();
        switch (act) {
            case "read": {
                String t = s.readScreen(5000);
                return J.ok("screen_text", J.untrusted("screen", t.isEmpty() ? "(nothing readable)" : t));
            }
            case "tap_text": {
                boolean ok = s.clickText(a.optString("text"));
                return ok ? J.ok("tapped", a.optString("text")) : J.fail("could not find '" + a.optString("text") + "' on screen");
            }
            case "tap_xy":
                return s.tap(sz[0] * (float) a.optDouble("x", 50) / 100f, sz[1] * (float) a.optDouble("y", 50) / 100f)
                        ? J.ok() : J.fail("tap failed");
            case "long_press_xy":
                return s.longPress(sz[0] * (float) a.optDouble("x", 50) / 100f, sz[1] * (float) a.optDouble("y", 50) / 100f)
                        ? J.ok() : J.fail("long press failed");
            case "swipe": {
                String d = a.optString("direction", "up").toLowerCase(Locale.ROOT);
                float cx = sz[0] / 2f;
                float cy = sz[1] / 2f;
                float dx = sz[0] * 0.35f;
                float dy = sz[1] * 0.30f;
                boolean ok;
                switch (d) {
                    case "down": ok = s.swipe(cx, cy - dy, cx, cy + dy, 300); break;
                    case "left": ok = s.swipe(cx + dx, cy, cx - dx, cy, 300); break;
                    case "right": ok = s.swipe(cx - dx, cy, cx + dx, cy, 300); break;
                    default: ok = s.swipe(cx, cy + dy, cx, cy - dy, 300); break;
                }
                return ok ? J.ok() : J.fail("swipe failed");
            }
            case "scroll_down":
                return s.scroll(true) ? J.ok() : J.fail("scroll failed");
            case "scroll_up":
                return s.scroll(false) ? J.ok() : J.fail("scroll failed");
            case "type_text":
                return s.typeText(a.optString("text"), a.optBoolean("append", false))
                        ? J.ok() : J.fail("no text field found; tap a field first");
            case "enter":
            case "press_enter":
            case "submit":
                return s.pressEnter() ? J.ok() : J.fail("no keyboard Enter/Search available");
            case "focus_search":
                return s.focusSearchField() ? J.ok() : J.fail("no search box found");
            case "back":
                return s.global(AccessibilityService.GLOBAL_ACTION_BACK) ? J.ok() : J.fail("failed");
            case "home":
                return s.global(AccessibilityService.GLOBAL_ACTION_HOME) ? J.ok() : J.fail("failed");
            case "recents":
                return s.global(AccessibilityService.GLOBAL_ACTION_RECENTS) ? J.ok() : J.fail("failed");
            case "notifications":
                return s.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) ? J.ok() : J.fail("failed");
            case "quick_settings":
                return s.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) ? J.ok() : J.fail("failed");
            case "lock_screen":
                return s.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ? J.ok() : J.fail("failed");
            case "screenshot":
                return s.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) ? J.ok("note", "saved to the Screenshots album")
                        : J.fail("failed");
            case "power_menu":
                return s.global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG) ? J.ok() : J.fail("failed");
            default:
                return J.fail("unknown action '" + act + "'");
        }
    }

    // ------------------------------------------------------------------ screen_process

    private static JSONObject screenProcess(Context c, JSONObject a) throws Exception {
        String angle = a.optString("angle", "screen").toLowerCase(Locale.ROOT);
        String question = a.optString("text", "Describe what you see.");
        JarvisService svc = JarvisService.get();
        if (svc == null || !svc.isLive()) return J.fail("no live session to show the image to");

        byte[] jpeg;
        String label;
        if (angle.startsWith("cam") || angle.equals("front")) {
            jpeg = capturePhoto(c, angle.equals("front"));
            label = "CAMERA frame showing the USER's surroundings";
        } else {
            JarvisAccessibility s = JarvisAccessibility.get();
            if (s == null) return needAccessibility();
            jpeg = s.screenshotJpeg();
            if (jpeg == null) return J.fail("could not capture the screen (needs Android 11+ and Accessibility)");
            label = "SCREEN capture of the user's PHONE";
        }
        Bus.Ui ui = Bus.ui;
        if (ui != null) {
            Bitmap bmp = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length);
            ui.onImage(bmp, label);
        }
        svc.sendImage(jpeg);
        return J.ok("note", "A " + label + " has just been sent to you. Look at it and answer: " + question);
    }

    /** One still frame from a camera, using Camera2 directly (no extra libraries). */
    static byte[] capturePhoto(Context c, boolean front) throws Exception {
        CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
        String id = null;
        int want = front ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK;
        for (String s : cm.getCameraIdList()) {
            Integer f = cm.getCameraCharacteristics(s).get(CameraCharacteristics.LENS_FACING);
            if (f != null && f == want) {
                id = s;
                break;
            }
        }
        if (id == null) id = cm.getCameraIdList()[0];

        HandlerThread ht = new HandlerThread("jarvis-cam");
        ht.start();
        final Handler h = new Handler(ht.getLooper());
        final ImageReader reader = ImageReader.newInstance(1280, 960, ImageFormat.JPEG, 3);
        final byte[][] result = new byte[1][];
        final CountDownLatch got = new CountDownLatch(1);
        final AtomicInteger frames = new AtomicInteger();
        reader.setOnImageAvailableListener(r -> {
            Image img = r.acquireLatestImage();
            if (img == null) return;
            try {
                // skip the first frames so auto-exposure can settle
                if (frames.incrementAndGet() >= 8 && result[0] == null) {
                    ByteBuffer b = img.getPlanes()[0].getBuffer();
                    byte[] d = new byte[b.remaining()];
                    b.get(d);
                    result[0] = d;
                    got.countDown();
                }
            } finally {
                img.close();
            }
        }, h);

        final CameraDevice[] dev = new CameraDevice[1];
        final CameraCaptureSession[] sess = new CameraCaptureSession[1];
        final CountDownLatch opened = new CountDownLatch(1);
        try {
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice camera) {
                    dev[0] = camera;
                    opened.countDown();
                }

                @Override
                public void onDisconnected(CameraDevice camera) {
                    camera.close();
                    opened.countDown();
                }

                @Override
                public void onError(CameraDevice camera, int error) {
                    camera.close();
                    opened.countDown();
                }
            }, h);
            if (!opened.await(6, TimeUnit.SECONDS) || dev[0] == null) {
                throw new Exception("camera is busy or not allowed in the background; bring the app to the front");
            }
            final Surface surf = reader.getSurface();
            final CountDownLatch configured = new CountDownLatch(1);
            dev[0].createCaptureSession(Collections.singletonList(surf), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession session) {
                    sess[0] = session;
                    try {
                        CaptureRequest.Builder b = dev[0].createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        b.addTarget(surf);
                        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                        session.setRepeatingRequest(b.build(), null, h);
                    } catch (CameraAccessException ignored) {
                    }
                    configured.countDown();
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession session) {
                    configured.countDown();
                }
            }, h);
            configured.await(5, TimeUnit.SECONDS);
            if (!got.await(6, TimeUnit.SECONDS) || result[0] == null) throw new Exception("camera gave no picture");
        } finally {
            try {
                if (sess[0] != null) sess[0].close();
            } catch (Exception ignored) {
            }
            try {
                if (dev[0] != null) dev[0].close();
            } catch (Exception ignored) {
            }
            reader.close();
            ht.quitSafely();
        }

        // downscale for the model
        Bitmap bmp = BitmapFactory.decodeByteArray(result[0], 0, result[0].length);
        return bmp == null ? result[0] : JarvisAccessibility.toJpeg(bmp, 1024);
    }
}
