package com.markvi.jarvis;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;

/** In-app flight recorder: recent log lines plus the last crash, shown in the Debugger screen. */
public final class DebugLog {
    private DebugLog() {}

    private static final ArrayDeque<String> LINES = new ArrayDeque<>();
    private static final SimpleDateFormat TIME = new SimpleDateFormat("HH:mm:ss", Locale.US);
    private static boolean installed;

    public static synchronized void add(String line) {
        if (line == null) return;
        LINES.add(TIME.format(new Date()) + "  " + line);
        while (LINES.size() > 600) LINES.removeFirst();
    }

    public static synchronized String dump() {
        StringBuilder sb = new StringBuilder();
        for (String l : LINES) sb.append(l).append('\n');
        return sb.toString();
    }

    public static synchronized void clear() {
        LINES.clear();
    }

    /** Saves any crash to a file so it can be read after the app restarts. */
    public static synchronized void installCrashHandler(final Context ctx) {
        if (installed) return;
        installed = true;
        final Context app = ctx.getApplicationContext();
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String text = new Date() + "  thread=" + t.getName() + "\n" + sw + "\n--- recent log ---\n" + dump();
                try (FileOutputStream fo = new FileOutputStream(new File(app.getFilesDir(), "crash.txt"))) {
                    fo.write(text.getBytes("UTF-8"));
                }
            } catch (Throwable ignored) {
            }
            if (old != null) old.uncaughtException(t, e);
        });
    }

    public static String lastCrash(Context c) {
        File f = new File(c.getFilesDir(), "crash.txt");
        if (!f.exists()) return "";
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[(int) Math.min(f.length(), 12000)];
            int n = in.read(b);
            return new String(b, 0, Math.max(0, n), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    public static void clearCrash(Context c) {
        new File(c.getFilesDir(), "crash.txt").delete();
    }
}
