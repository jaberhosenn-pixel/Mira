package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Request;
import okhttp3.Response;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/**
 * Lead generation and page reading for Serious mode.
 * Gemini + Google Search finds PUBLIC businesses; every website is then visited and its real contact details are read
 * by code (not by a model), so emails, phones and Facebook links are never invented.
 */
public final class ToolsLeads {
    private ToolsLeads() {}

    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9\\-]+(?:\\.[A-Za-z0-9\\-]+)*\\.[A-Za-z]{2,}");
    private static final Pattern BD_PHONE = Pattern.compile("(?<![\\d])(?:\\+?88[\\s\\-]?)?0?1[3-9][\\d\\s\\-]{8,11}(?![\\d])");
    private static final Pattern INTL_PHONE = Pattern.compile("\\+\\d{1,3}[\\s\\-()]*\\d[\\d\\s\\-()]{7,14}\\d");
    private static final Pattern FB = Pattern.compile("https?://(?:www\\.|m\\.|web\\.)?facebook\\.com/[A-Za-z0-9._\\-]+(?:/[A-Za-z0-9._\\-]+)?");
    private static final Pattern IG = Pattern.compile("https?://(?:www\\.)?instagram\\.com/[A-Za-z0-9._]+");
    private static final Pattern HREF = Pattern.compile("href\\s*=\\s*[\"']([^\"'#]+)[\"']", Pattern.CASE_INSENSITIVE);

    static void register() {
        reg("fetch_page",
                "Downloads a web page and returns its readable text (first ~9000 characters). Use it to read sources while researching.",
                schema("url", "url:STRING:page address"),
                (c, a) -> {
                    String html = fetch(a.optString("url"));
                    if (html == null) return J.fail("could not open that page");
                    String t = text(html);
                    return J.ok("text", t.length() > 9000 ? t.substring(0, 9000) : t);
                });

        reg("extract_contacts",
                "Visits a business website (and its contact page) and reads the REAL public email, phone numbers, Facebook and Instagram links from it.",
                schema("url", "url:STRING:the website address"),
                (c, a) -> {
                    JSONObject r = contacts(a.optString("url"));
                    return r == null ? J.fail("website could not be opened") : J.ok("contacts", r);
                });

        reg("maps_leads",
                "Lead scanner for Google Maps (like a lead-scraper extension): opens Google Maps on the phone screen, scrolls the results, opens every business "
                        + "and reads name, category, rating, reviews, phone, website, address; then visits each website for the real email, Facebook and Instagram; "
                        + "gives every lead a 0-100 score; saves CSV + Excel in Downloads and a separate list of businesses with no website. "
                        + "Takes several minutes; Mira must stay on the screen while it runs.",
                schema("niche,city",
                        "niche:STRING:kind of business, e.g. dental clinic",
                        "city:STRING:city or area",
                        "count:INTEGER:how many leads (default 50, max 150)",
                        "focus:STRING:with_website | no_website | all (default all)"),
                (c, a) -> {
                    String n = a.optString("niche").trim(), city = a.optString("city").trim();
                    if (n.isEmpty() || city.isEmpty()) return J.fail("niche and city are required");
                    return LeadScan.runMaps(c, n, city, Math.max(5, Math.min(150, a.optInt("count", 50))), a.optString("focus", "all").toLowerCase(Locale.ROOT));
                });

        reg("search_leads",
                "Lead scanner for Google Search: runs many Google searches for a niche in a city, collects the business websites (not directories or social sites), "
                        + "visits each to read the real email, phone, Facebook and Instagram, scores each lead 0-100 and saves CSV + Excel in Downloads. "
                        + "If Google shows a robot check it switches to DuckDuckGo results automatically. Takes several minutes.",
                schema("niche,city",
                        "niche:STRING:kind of business",
                        "city:STRING:city or area",
                        "count:INTEGER:how many leads (default 50, max 150)",
                        "focus:STRING:with_website | no_website | all (default all)"),
                (c, a) -> {
                    String n = a.optString("niche").trim(), city = a.optString("city").trim();
                    if (n.isEmpty() || city.isEmpty()) return J.fail("niche and city are required");
                    return LeadScan.runSearch(c, n, city, Math.max(5, Math.min(150, a.optInt("count", 50))), a.optString("focus", "all").toLowerCase(Locale.ROOT));
                });

        reg("find_leads",
                "Builds a lead list of PUBLIC businesses for a niche in a city: searches Google, visits each business website and reads its real "
                        + "email, phone, Facebook and Instagram. Saves a CSV and an Excel file in Downloads (plus a second list of businesses that "
                        + "seem to have no website of their own). Quick version without the scanner screen; needs the Gemini key. Prefer maps_leads or search_leads.",
                schema("niche,city",
                        "niche:STRING:kind of business, e.g. dental clinic, restaurant, coaching center",
                        "city:STRING:city or area, e.g. Sylhet",
                        "count:INTEGER:how many leads to aim for (default 50, max 100)",
                        "focus:STRING:with_website | no_website | all (default all)"),
                (c, a) -> findLeads(c, a));

        reg("schedule_daily_leads",
                "Turns the DAILY LEAD UPDATE on or off, only when the user asks. Every day at the given time Mira searches the web for the niche/city "
                        + "and saves only NEW leads (not seen before) in Downloads, then shows a notification. Needs the Gemini key.",
                schema("action",
                        "action:STRING:on | off | status",
                        "niche:STRING:kind of business (on)",
                        "city:STRING:city or area (on)",
                        "count:INTEGER:leads per day, default 30, max 60",
                        "time:STRING:24h HH:MM, default 09:00"),
                (c, a) -> {
                    String act = a.optString("action", "status").toLowerCase(Locale.ROOT);
                    JSONObject cfg;
                    try {
                        cfg = new JSONObject(Prefs.sp(c).getString("daily_leads", "{}"));
                    } catch (Exception e) {
                        cfg = new JSONObject();
                    }
                    if (act.equals("status")) return J.ok("config", cfg.toString());
                    if (act.equals("off")) {
                        J.put(cfg, "on", false);
                    } else {
                        if (a.optString("niche").trim().isEmpty() || a.optString("city").trim().isEmpty()) return J.fail("niche and city are required");
                        if (Prefs.apiKey(c).isEmpty()) return J.fail("needs the Gemini API key in Settings");
                        int h = 9, m = 0;
                        java.util.regex.Matcher mt = Pattern.compile("(\\d{1,2})[:.](\\d{2})").matcher(a.optString("time"));
                        if (mt.find()) {
                            h = Math.min(23, Integer.parseInt(mt.group(1)));
                            m = Math.min(59, Integer.parseInt(mt.group(2)));
                        }
                        J.put(cfg, "on", true);
                        J.put(cfg, "niche", a.optString("niche").trim());
                        J.put(cfg, "city", a.optString("city").trim());
                        J.put(cfg, "count", Math.max(5, Math.min(60, a.optInt("count", 30))));
                        J.put(cfg, "hour", h);
                        J.put(cfg, "minute", m);
                    }
                    Prefs.sp(c).edit().putString("daily_leads", cfg.toString()).apply();
                    DailyLeads.schedule(c);
                    return J.ok("daily_leads", cfg.optBoolean("on") ? "on at " + cfg.optInt("hour") + ":" + String.format(Locale.US, "%02d", cfg.optInt("minute")) : "off",
                            "note", "the phone must be on with internet; the first run is the next time of day");
                });

        reg("send_email_batch",
                "Sends ONE email (same subject and body) to the Email column of a saved leads CSV, one by one through the Gmail app. "
                        + "Only when the user asks. The user must approve on screen first (shows the count). Max 30 per run, skips duplicates and blanks.",
                schema("path,subject,body",
                        "path:STRING:full path of the saved leads .csv",
                        "subject:STRING:email subject",
                        "body:STRING:email body"),
                (c, a) -> {
                    String csv = SeriousMode.readText(a.optString("path"));
                    if (csv == null) return J.fail("csv not found in Downloads");
                    String[] lines = csv.split("\\r?\\n");
                    if (lines.length < 2) return J.fail("csv is empty");
                    java.util.List<String> head = splitCsv(lines[0]);
                    int ei = -1;
                    for (int i = 0; i < head.size(); i++) if (head.get(i).trim().equalsIgnoreCase("email")) ei = i;
                    if (ei < 0) return J.fail("no Email column");
                    Set<String> mails = new LinkedHashSet<>();
                    for (int i = 1; i < lines.length; i++) {
                        java.util.List<String> cells = splitCsv(lines[i]);
                        if (cells.size() > ei) {
                            String e = cells.get(ei).trim().toLowerCase(Locale.ROOT);
                            if (e.matches("[a-z0-9._%+\\-]+@[a-z0-9.\\-]+\\.[a-z]{2,}")) mails.add(e);
                        }
                        if (mails.size() >= 30) break;
                    }
                    if (mails.isEmpty()) return J.fail("no valid email addresses in the file");
                    if (!Bus.confirm("Send this email to " + mails.size() + " addresses one by one?\n\nSubject: " + a.optString("subject")
                            + "\n\n" + a.optString("body"))) return J.obj("status", "declined", "note", "the user did not approve");
                    int ok = 0, manual = 0;
                    for (String m : mails) {
                        JSONObject r = Tools.dispatch(c, "send_message", J.obj("receiver", m, "message_text", a.optString("body"),
                                "subject", a.optString("subject"), "platform", "email"));
                        if ("unverified".equals(r.optString("status"))) ok++;
                        else manual++;
                        try {
                            Thread.sleep(7000);
                        } catch (InterruptedException ie) {
                            break;
                        }
                    }
                    return J.ok("send_pressed", ok, "needs_manual_send_or_failed", manual, "total", mails.size(),
                            "note", "Send was pressed through the screen; nobody can confirm delivery");
                });
    }

    static java.util.List<String> splitCsv(String line) {
        java.util.List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean q = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (q) {
                if (ch == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        cur.append('"');
                        i++;
                    } else q = false;
                } else cur.append(ch);
            } else if (ch == '"') q = true;
            else if (ch == ',') {
                out.add(cur.toString());
                cur.setLength(0);
            } else cur.append(ch);
        }
        out.add(cur.toString());
        return out;
    }

    // ------------------------------------------------------------------ network + text

    static String fetch(String url) {
        if (url == null) return null;
        String u = url.trim();
        if (u.isEmpty()) return null;
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
        try {
            Request req = new Request.Builder().url(u)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                    .header("Accept-Language", "en,bn;q=0.8").build();
            try (Response r = GeminiRest.HTTP.newBuilder().callTimeout(15, TimeUnit.SECONDS).build().newCall(req).execute()) {
                if (!r.isSuccessful() || r.body() == null) return null;
                String t = r.body().string();
                return t.length() > 700000 ? t.substring(0, 700000) : t;
            }
        } catch (Exception e) {
            return null;
        }
    }

    static String text(String html) {
        String t = html.replaceAll("(?is)<(script|style|noscript)[^>]*>.*?</\\1>", " ")
                .replaceAll("(?is)<[^>]+>", " ")
                .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'");
        return t.replaceAll("\\s+", " ").trim();
    }

    private static String origin(String url) {
        String u = url.trim();
        if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://" + u;
        int s = u.indexOf("://") + 3;
        int e = u.indexOf('/', s);
        return e < 0 ? u : u.substring(0, e);
    }

    static String host(String url) {
        try {
            String o = origin(url);
            String h = o.substring(o.indexOf("://") + 3).toLowerCase(Locale.ROOT);
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean junkEmail(String e) {
        String l = e.toLowerCase(Locale.ROOT);
        return l.matches(".*\\.(png|jpg|jpeg|gif|webp|svg|css|js)$") || l.contains("sentry") || l.contains("wixpress")
                || l.contains("example.") || l.contains("domain.com") || l.contains("yourdomain") || l.contains("email.com")
                || l.startsWith("name@") || l.startsWith("user@") || l.startsWith("your@");
    }

    /** Reads the home page and the contact page(s); returns null when the site cannot be opened at all. */
    static JSONObject contacts(String website) {
        String base = origin(website);
        String home = fetch(website);
        if (home == null) home = fetch(base);
        if (home == null) return null;

        List<String> pages = new ArrayList<>();
        pages.add(home);
        Set<String> tried = new HashSet<>();
        Matcher m = HREF.matcher(home);
        int extra = 0;
        while (m.find() && extra < 2) {
            String h = m.group(1).trim();
            String low = h.toLowerCase(Locale.ROOT);
            if (!(low.contains("contact") || low.contains("about"))) continue;
            if (low.startsWith("mailto:") || low.startsWith("tel:") || low.startsWith("javascript:")) continue;
            String abs = h.startsWith("http") ? h : h.startsWith("//") ? "https:" + h : h.startsWith("/") ? base + h : base + "/" + h;
            if (!host(abs).equals(host(base)) || !tried.add(abs)) continue;
            String p = fetch(abs);
            if (p != null) {
                pages.add(p);
                extra++;
            }
        }

        LinkedHashSet<String> emails = new LinkedHashSet<>(), phones = new LinkedHashSet<>();
        String fb = "", ig = "";
        for (String p : pages) {
            Matcher me = EMAIL.matcher(p);
            while (me.find() && emails.size() < 3) if (!junkEmail(me.group())) emails.add(me.group());
            Matcher mt = Pattern.compile("tel:([+\\d\\s\\-()]{7,20})", Pattern.CASE_INSENSITIVE).matcher(p);
            while (mt.find() && phones.size() < 3) phones.add(mt.group(1).trim());
            String plain = text(p);
            Matcher mb = BD_PHONE.matcher(plain);
            while (mb.find() && phones.size() < 3) phones.add(mb.group().trim());
            Matcher mi = INTL_PHONE.matcher(plain);
            while (mi.find() && phones.size() < 3) phones.add(mi.group().trim());
            if (fb.isEmpty()) {
                Matcher mf = FB.matcher(p);
                while (mf.find()) {
                    String f = mf.group();
                    String l = f.toLowerCase(Locale.ROOT);
                    if (l.contains("sharer") || l.contains("/plugins") || l.contains("/tr") || l.contains("/dialog") || l.contains("/share")
                            || l.endsWith("/facebook.com/") || l.contains("/policies") || l.contains("/groups/")) continue;
                    fb = f;
                    break;
                }
            }
            if (ig.isEmpty()) {
                Matcher mg = IG.matcher(p);
                while (mg.find()) {
                    String l = mg.group().toLowerCase(Locale.ROOT);
                    if (l.endsWith("/p") || l.endsWith("/explore") || l.endsWith("/accounts")) continue;
                    ig = mg.group();
                    break;
                }
            }
        }
        return J.obj("email", String.join("; ", emails), "phone", String.join("; ", dedupePhones(phones)),
                "facebook", fb, "instagram", ig);
    }

    private static List<String> dedupePhones(Set<String> in) {
        List<String> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (String p : in) {
            String d = p.replaceAll("\\D", "");
            if (d.length() < 8) continue;
            String key = d.length() > 10 ? d.substring(d.length() - 10) : d;
            if (seen.add(key)) out.add(p.replaceAll("\\s+", " ").trim());
        }
        return out;
    }

    // ------------------------------------------------------------------ lead pipeline

    private static final String[] VARIANTS = {
            "", " Focus on well known ones.", " Focus on small local ones in different neighbourhoods.",
            " Focus on ones with the most online reviews.", " Include newer ones and ones in the suburbs.",
            " Include ones with a Facebook page or website listed in their Google listing.", " Different names than the usual top results.",
            " Cover other parts of the area not mentioned yet."};

    static JSONObject runFindLeads(Context c, JSONObject a) throws Exception {
        return findLeads(c, a);
    }

    private static JSONObject findLeads(Context c, JSONObject a) throws Exception {
        String niche = a.optString("niche").trim(), city = a.optString("city").trim();
        if (niche.isEmpty() || city.isEmpty()) return J.fail("niche and city are required");
        if (Prefs.apiKey(c).isEmpty()) return J.fail("Lead search needs the Gemini API key (Settings), because it uses Google Search through Gemini.");
        int want = Math.max(5, Math.min(100, a.optInt("count", 50)));
        String focus = a.optString("focus", "all").toLowerCase(Locale.ROOT);

        List<JSONObject> found = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        int fails = 0;
        for (int round = 0; round < VARIANTS.length && found.size() < Math.round(want * 1.4f); round++) {
            StringBuilder known = new StringBuilder();
            for (int i = Math.max(0, found.size() - 60); i < found.size(); i++) known.append(found.get(i).optString("name")).append("; ");
            String prompt = "Using Google Search, list REAL " + niche + " businesses in " + city + "." + VARIANTS[round]
                    + " Return ONLY a JSON array (no markdown, no explanation) of up to 25 objects with the keys: "
                    + "name, website (the business's OWN official website URL, or \"\" if they have none), facebook (their Facebook page URL or \"\"), "
                    + "phone (or \"\"), address (or \"\"). Never invent a business or a detail: if unsure, use \"\"."
                    + (known.length() > 0 ? " Do NOT repeat these: " + known : "");
            try {
                String raw = GeminiRest.generate(c, prompt, true, null, null);
                int s = raw.indexOf('['), e = raw.lastIndexOf(']');
                if (s < 0 || e <= s) {
                    fails++;
                    if (fails >= 3) break;
                    continue;
                }
                JSONArray arr = new JSONArray(raw.substring(s, e + 1));
                int added = 0;
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject o = arr.optJSONObject(i);
                    if (o == null) continue;
                    String name = o.optString("name").trim();
                    if (name.isEmpty()) continue;
                    String site = o.optString("website").trim();
                    String key = site.isEmpty() ? name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9\\u0980-\\u09ff]", "") : host(site);
                    if (key.isEmpty() || !seen.add(key)) continue;
                    found.add(o);
                    added++;
                }
                DebugLog.add("Leads round " + (round + 1) + ": +" + added + " (total " + found.size() + ")");
                fails = 0;
            } catch (Exception ex) {
                fails++;
                DebugLog.add("Leads round " + (round + 1) + " failed: " + ex.getMessage());
                if (fails >= 3) break;
                Thread.sleep(2500);
            }
        }
        if (found.isEmpty()) return J.fail("Search returned no businesses. Try a wider niche or city, or check the Gemini key and quota.");

        // visit every website and read the real contacts (6 at a time)
        ExecutorService pool = Executors.newFixedThreadPool(6);
        List<Future<JSONObject>> jobs = new ArrayList<>();
        for (final JSONObject o : found) {
            jobs.add(pool.submit(new Callable<JSONObject>() {
                @Override
                public JSONObject call() {
                    String site = o.optString("website").trim();
                    String fbListed = o.optString("facebook").trim();
                    String h = host(site);
                    boolean social = h.contains("facebook.com") || h.contains("instagram.com") || h.contains("linktr.ee") || h.contains("fb.com");
                    JSONObject row = J.obj("name", o.optString("name"), "website", social ? "" : site, "email", "", "phone", o.optString("phone"),
                            "facebook", fbListed.isEmpty() && h.contains("facebook") ? site : fbListed, "instagram", "",
                            "address", o.optString("address"), "notes", "");
                    if (site.isEmpty() || social) {
                        J.put(row, "notes", "no own website found in search");
                        return row;
                    }
                    JSONObject ct = contacts(site);
                    if (ct == null) {
                        J.put(row, "notes", "website did not open");
                        return row;
                    }
                    J.put(row, "email", ct.optString("email"));
                    if (!ct.optString("phone").isEmpty()) J.put(row, "phone", ct.optString("phone"));
                    if (!ct.optString("facebook").isEmpty()) J.put(row, "facebook", ct.optString("facebook"));
                    J.put(row, "instagram", ct.optString("instagram"));
                    J.put(row, "notes", ct.optString("email").isEmpty() ? "website read, no public email found" : "contacts read from website");
                    return row;
                }
            }));
        }
        List<JSONObject> rows = new ArrayList<>();
        for (Future<JSONObject> f : jobs) {
            try {
                rows.add(f.get(60, TimeUnit.SECONDS));
            } catch (Exception ex) {
                DebugLog.add("lead skipped: " + ex);
            }
        }
        pool.shutdownNow();

        StringBuilder withSite = new StringBuilder("Name,Website,Email,Phone,Facebook,Instagram,Address,Notes\n");
        StringBuilder noSite = new StringBuilder("Name,Facebook,Phone,Address,Notes\n");
        int nWith = 0, nNo = 0, nEmail = 0;
        boolean newOnly = a.optBoolean("new_only", false);
        Set<String> seenBefore = new HashSet<>();
        if (newOnly) {
            try {
                JSONArray old = new JSONArray(Prefs.sp(c).getString("daily_seen", "[]"));
                for (int i = 0; i < old.length(); i++) seenBefore.add(old.optString(i));
            } catch (Exception ignored) {
            }
        }
        for (JSONObject r : rows) {
            if (newOnly) {
                String k = r.optString("website").isEmpty() ? "n:" + r.optString("name").toLowerCase(Locale.ROOT) : "h:" + host(r.optString("website"));
                if (!seenBefore.add(k)) continue;
            }
            boolean has = !r.optString("website").isEmpty();
            if (has) {
                if (nWith >= want) continue;
                nWith++;
                if (!r.optString("email").isEmpty()) nEmail++;
                withSite.append(csv(r.optString("name"))).append(',').append(csv(r.optString("website"))).append(',').append(csv(r.optString("email")))
                        .append(',').append(csv(r.optString("phone"))).append(',').append(csv(r.optString("facebook"))).append(',')
                        .append(csv(r.optString("instagram"))).append(',').append(csv(r.optString("address"))).append(',').append(csv(r.optString("notes"))).append('\n');
            } else {
                nNo++;
                noSite.append(csv(r.optString("name"))).append(',').append(csv(r.optString("facebook"))).append(',').append(csv(r.optString("phone")))
                        .append(',').append(csv(r.optString("address"))).append(',').append(csv(r.optString("notes"))).append('\n');
            }
        }

        if (newOnly) {
            JSONArray all = new JSONArray();
            int n = 0;
            for (String k : seenBefore) {
                if (n++ > 5000) break;
                all.put(k);
            }
            Prefs.sp(c).edit().putString("daily_seen", all.toString()).apply();
        }
        String project = (niche + "-" + city).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9\\u0980-\\u09ff]+", "-");
        if (newOnly) project += "-new-" + new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new java.util.Date());
        JSONObject out = J.ok("businesses_found", found.size(), "with_website", nWith, "with_public_email", nEmail, "without_own_website", nNo);
        if (!focus.equals("no_website") && nWith > 0) {
            File f1 = SeriousMode.saveBytes(c, "leads-" + project + ".csv", withSite.toString().getBytes("UTF-8"), project);
            File f2 = SeriousMode.saveBytes(c, "leads-" + project + ".xlsx", XlsxWriter.fromCsv(withSite.toString()), project);
            J.put(out, "leads_csv", f1.getAbsolutePath());
            J.put(out, "leads_excel", f2.getAbsolutePath());
        }
        if (!focus.equals("with_website") && nNo > 0) {
            File f3 = SeriousMode.saveBytes(c, "no-website-" + project + ".csv", noSite.toString().getBytes("UTF-8"), project);
            J.put(out, "no_website_csv", f3.getAbsolutePath());
        }
        if (newOnly) J.put(out, "new_leads", nWith + nNo);
        J.put(out, "note", "Contacts were read from the real websites; businesses are from Google Search through Gemini, so spot-check a few. "
                + (nWith + nNo < want ? "Fewer than requested exist in what search returned; try another niche wording or a nearby city for more." : ""));
        return out;
    }

    static String csv(String s) {
        if (s == null) return "";
        String t = s.replace("\r", " ").replace("\n", " ");
        if (t.contains(",") || t.contains("\"")) return "\"" + t.replace("\"", "\"\"") + "\"";
        return t;
    }
}
