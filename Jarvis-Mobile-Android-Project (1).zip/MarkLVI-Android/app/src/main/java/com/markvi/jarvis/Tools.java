package com.markvi.jarvis;

import android.content.Context;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Tool registry, declarations for Gemini, and dispatch (mobile twin of core/action_loader.py). */
public final class Tools {
    private Tools() {}

    public interface H {
        JSONObject run(Context c, JSONObject args) throws Exception;
    }

    static final class T {
        final String name;
        final String description;
        final JSONObject params;
        final H handler;

        T(String name, String description, JSONObject params, H handler) {
            this.name = name;
            this.description = description;
            this.params = params;
            this.handler = handler;
        }
    }

    private static final Map<String, T> REG = new LinkedHashMap<>();

    static {
        ToolsCore.register();
        ToolsFinal.register();
        EarthTools.register();
        ToolsExtra.register();
        ToolsPhone.register();
        ToolsFiles.register();
        ToolsScreen.register();
        SeriousMode.register();
        ToolsLeads.register();
        ToolsDocs.register();
        ToolsGoogle.register();
        ToolsCalls.register();
        ToolsApps.register();
        Sip.register();
        Backup.registerTools();
    }

    static void reg(String name, String description, JSONObject params, H handler) {
        REG.put(name, new T(name, description, params, handler));
    }

    /**
     * Builds a Gemini parameter schema. Each prop is "name:TYPE:description" (TYPE = STRING, INTEGER,
     * NUMBER, BOOLEAN). required is a comma separated list of names.
     */
    static JSONObject schema(String required, String... props) {
        JSONObject p = new JSONObject();
        for (String s : props) {
            String[] parts = s.split(":", 3);
            J.put(p, parts[0], J.obj("type", parts[1], "description", parts.length > 2 ? parts[2] : ""));
        }
        JSONObject o = J.obj("type", "OBJECT", "properties", p);
        if (required != null && !required.isEmpty()) {
            JSONArray r = new JSONArray();
            for (String s : required.split(",")) r.put(s.trim());
            J.put(o, "required", r);
        }
        return o;
    }

    public static JSONArray declarations() {
        JSONArray a = new JSONArray();
        for (T t : REG.values()) {
            a.put(J.obj("name", t.name, "description", t.description, "parameters", t.params));
        }
        return a;
    }

    /** Same as dispatch, but honours PIN protection. Used for calls that come from the AI model. */
    public static JSONObject dispatchUser(Context c, String name, JSONObject args) {
        JSONObject g = ToolsFinal.guard(c, name);
        if (g != null) {
            ToolsFinal.log(c, name, args, g);
            return g;
        }
        return dispatch(c, name, args);
    }

    public static JSONObject dispatch(Context c, String name, JSONObject args) {
        JSONObject result = run(c, name, args);
        ToolsFinal.log(c, name, args, result);
        return result;
    }

    private static JSONObject run(Context c, String name, JSONObject args) {
        T t = REG.get(name);
        if (t == null) return J.fail("unknown tool: " + name);
        try {
            JSONObject r = t.handler.run(c, args == null ? new JSONObject() : args);
            return r == null ? J.ok() : r;
        } catch (SecurityException se) {
            return J.fail("Permission missing: " + se.getMessage() + ". Ask the user to grant it in Settings.");
        } catch (Throwable e) {
            DebugLog.add("Tool " + name + " crashed: " + e);
            return J.fail(e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    // ------------------------------------------------------------------ system prompt

    private static String readAsset(Context c, String name) {
        try (InputStream in = c.getAssets().open(name)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return "You are {assistant_name}, a voice assistant on an Android phone.\n{capabilities}\n{limits}\n{memory}";
        }
    }

    private static String firstSentence(String s) {
        int i = s.indexOf(". ");
        String t = i > 0 ? s.substring(0, i + 1) : s;
        return t.length() > 150 ? t.substring(0, 150) + "..." : t;
    }

    public static String systemPrompt(Context c) {
        StringBuilder cap = new StringBuilder();
        for (T t : REG.values()) {
            cap.append("- ").append(t.name).append(": ").append(firstSentence(t.description)).append('\n');
        }
        boolean acc = JarvisAccessibility.get() != null;
        StringBuilder lim = new StringBuilder();
        lim.append("- You are on a phone, not a PC: there is no mouse, no keyboard shortcuts, no desktop windows, ")
                .append("no Steam/game updates and no terminal.\n");
        lim.append("- You cannot control other apps unless the Accessibility service is enabled. Right now it is ")
                .append(acc ? "ENABLED." : "NOT enabled: tell the user to turn it on in Settings > Accessibility if they ask for taps, typing or screenshots.").append('\n');
        lim.append("- You CAN read recent calls (call_log_recent), SMS (read_sms), Gmail notifications (gmail_recent), the calendar, and the screen of the app in front.\n");
        lim.append("- SMS to another person and calls need the user's on-screen approval, except when the user's command is a busy-reply (decline_with_message) or a dictated email/WhatsApp message: the user's command IS the approval, send it.\n");
        lim.append("- Sending to WhatsApp/Messenger/Telegram/email works by driving the app screen. NEVER ask the user to press Send or any final button: finish it yourself (send_message, then screen_agent or ui_flow if needed). Delivery cannot be verified: say so.\n");
        lim.append("- You CAN install free apps from Google Play (install_app), automate any app screen (ui_flow, screen_agent) and answer IP-phone calls (sip_*). You cannot wake a switched-off screen, and Android blocks cross-app control while the phone is locked.\n");

        String now = new SimpleDateFormat("EEEE, d MMMM yyyy HH:mm", Locale.US).format(new Date());
        String device = Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE;
        String tone = SeriousMode.active(c)
                ? "\n\n[VOICE TONE - SERIOUS MODE] Speak in a deep, low, slow, grave and authoritative voice, like a senior professional delivering important news. "
                  + "Short firm sentences, calm and weighty, no giggling, no excitement, no filler like 'oh' or 'wow'. Never sound playful.\n\n"
                : "";
        return tone + ToolsFinal.promptExtras(c) + Prefs.creatorRule(c) + "\n\n" + readAsset(c, "prompt.txt")
                .replace("{assistant_name}", Prefs.assistantName(c))
                .replace("{device}", device)
                .replace("{now}", now)
                .replace("{capabilities}", cap.toString().trim())
                .replace("{limits}", lim.toString().trim())
                .replace("{memory}", Memory.promptBlock(c)) + "\n\n" + Prefs.creatorRule(c);
    }
}
