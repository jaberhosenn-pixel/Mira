package com.markvi.jarvis;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Traffic and routes, follow-up reminders, camera text (OCR) and QR / barcode scanning. */
public final class ToolsMore {
    private ToolsMore() {}

    static void register() {
        // ------------------------------------------------------------ traffic and routes
        reg("traffic_view",
                "Opens Google Maps with the live TRAFFIC layer (red/orange/green roads) around the user, or around a place. Mira cannot read the traffic itself; Google Maps shows it. Use for 'how is the traffic', 'ট্রাফিক কেমন'.",
                schema("", "place:STRING:optional place name; empty = around the user"),
                (c, a) -> {
                    try {
                        String place = a.optString("place").trim();
                        Uri u;
                        if (place.isEmpty()) {
                            double[] me = EarthTools.userPos(c);
                            if (me == null) return J.fail("Location is off. Turn Location on, or say a place name.");
                            u = Uri.parse(String.format(Locale.US, "https://www.google.com/maps/@%.5f,%.5f,14z/data=!5m1!1e1", me[0], me[1]));
                        } else {
                            u = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + URLEncoder.encode(place, "UTF-8"));
                        }
                        openMaps(c, u);
                        return J.ok("opened", "Google Maps", "note", place.isEmpty()
                                ? "Traffic layer is on. Colours show live traffic; I cannot read the travel time myself."
                                : "Search opened. Tap the layers button and choose Traffic to see live traffic.");
                    } catch (Exception e) { return J.fail("Could not open Google Maps: " + e.getMessage()); }
                });

        reg("route_open",
                "Shows the route to a place in Google Maps (with Google's own travel time and live traffic) WITHOUT starting navigation. mode: driving (default), walking, bicycling, transit. For turn-by-turn use navigate.",
                schema("destination", "destination:STRING:place or address", "origin:STRING:optional start; empty = current location",
                        "mode:STRING:driving | walking | bicycling | transit"),
                (c, a) -> {
                    try {
                        String d = a.optString("destination").trim();
                        if (d.isEmpty()) return J.fail("Where to?");
                        String mode = a.optString("mode", "driving").toLowerCase(Locale.ROOT);
                        if (!mode.matches("driving|walking|bicycling|transit")) mode = "driving";
                        String url = "https://www.google.com/maps/dir/?api=1&destination=" + URLEncoder.encode(d, "UTF-8") + "&travelmode=" + mode;
                        String o = a.optString("origin").trim();
                        if (!o.isEmpty()) url += "&origin=" + URLEncoder.encode(o, "UTF-8");
                        openMaps(c, Uri.parse(url));
                        return J.ok("opened", "route to " + d, "note", "The travel time and traffic are shown in Google Maps; I cannot read them myself.");
                    } catch (Exception e) { return J.fail("Could not open Google Maps: " + e.getMessage()); }
                });

        // ------------------------------------------------------------ follow-up reminders
        reg("followup_add",
                "Adds a FOLLOW-UP reminder for a person (client, lead, friend): Mira reminds the user at that time to follow up with them. days = days from now (default 3), time = HH:MM 24h (default 10:00), or date = YYYY-MM-DD. note = what to follow up about.",
                schema("name", "name:STRING:person or business", "days:INTEGER:days from now, default 3", "date:STRING:YYYY-MM-DD, overrides days",
                        "time:STRING:HH:MM 24-hour, default 10:00", "note:STRING:what to follow up about"),
                (c, a) -> {
                    try {
                        String name = a.optString("name").trim();
                        if (name.isEmpty()) return J.fail("Whose follow-up?");
                        Calendar cal = Calendar.getInstance();
                        String date = a.optString("date").trim();
                        if (date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                            cal.setTime(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date));
                        } else {
                            cal.add(Calendar.DAY_OF_YEAR, Math.max(0, a.optInt("days", 3)));
                        }
                        String tm = a.optString("time", "10:00").trim();
                        if (!tm.matches("\\d{1,2}:\\d{2}")) tm = "10:00";
                        cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(tm.split(":")[0]));
                        cal.set(Calendar.MINUTE, Integer.parseInt(tm.split(":")[1]));
                        cal.set(Calendar.SECOND, 0);
                        if (cal.getTimeInMillis() < System.currentTimeMillis()) return J.fail("That time has already passed.");
                        String note = a.optString("note").trim();
                        String msg = "ফলো-আপ: " + name + (note.isEmpty() ? "" : " – " + note);
                        JSONObject r = Tools.dispatchUser(c, "reminder", J.obj("date", new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()),
                                "time", String.format(Locale.US, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)), "message", msg));
                        if (!"done".equals(r.optString("status")) && !"started".equals(r.optString("status")) && r.has("error"))
                            return J.fail("Could not set the reminder: " + r.optString("error"));
                        JSONArray all = load(c);
                        all.put(J.obj("name", name, "note", note, "due", cal.getTimeInMillis(), "done", false));
                        save(c, all);
                        return J.ok("saved", name, "due", new SimpleDateFormat("EEE d MMM HH:mm", Locale.US).format(cal.getTime()));
                    } catch (Exception e) { return J.fail("Could not save the follow-up: " + e.getMessage()); }
                });

        reg("followup_list",
                "Lists the pending follow-ups, soonest first. Mark overdue ones.",
                schema(""),
                (c, a) -> {
                    JSONArray all = load(c), out = new JSONArray();
                    ArrayList<JSONObject> rows = new ArrayList<>();
                    for (int i = 0; i < all.length(); i++) {
                        JSONObject o = all.optJSONObject(i);
                        if (o != null && !o.optBoolean("done")) rows.add(o);
                    }
                    Collections.sort(rows, (x, y) -> Long.compare(x.optLong("due"), y.optLong("due")));
                    SimpleDateFormat f = new SimpleDateFormat("EEE d MMM HH:mm", Locale.US);
                    long now = System.currentTimeMillis();
                    for (JSONObject o : rows)
                        out.put(J.obj("name", o.optString("name"), "note", o.optString("note"), "due", f.format(new Date(o.optLong("due"))),
                                "overdue", o.optLong("due") < now));
                    return J.ok("count", out.length(), "followups", out);
                });

        reg("followup_done",
                "Marks a follow-up as done (matches the person's name).",
                schema("name", "name:STRING:person or business"),
                (c, a) -> {
                    String n = a.optString("name").trim().toLowerCase(Locale.ROOT);
                    if (n.isEmpty()) return J.fail("Whose follow-up?");
                    JSONArray all = load(c);
                    int k = 0;
                    try {
                        for (int i = 0; i < all.length(); i++) {
                            JSONObject o = all.optJSONObject(i);
                            if (o != null && !o.optBoolean("done") && o.optString("name").toLowerCase(Locale.ROOT).contains(n)) { o.put("done", true); k++; }
                        }
                    } catch (Exception ignored) { }
                    save(c, all);
                    return k == 0 ? J.fail("No pending follow-up for " + a.optString("name")) : J.ok("done", k);
                });

        // ------------------------------------------------------------ camera: text and QR / barcode
        reg("scan_camera",
                "Opens the camera so the user can photograph TEXT (OCR, Bengali and English, works offline) or a QR code / barcode. kind = text | code | auto (try the code first, then text). "
                        + "The result arrives a moment later as a message starting with [SCAN RESULT]; then read it out. OCR of printed text only; handwriting is unreliable.",
                schema("", "kind:STRING:text | code | auto (default auto)"),
                (c, a) -> {
                    try {
                        String kind = a.optString("kind", "auto").toLowerCase(Locale.ROOT);
                        if (!kind.matches("text|code|auto")) kind = "auto";
                        Intent i = new Intent(c, ScanActivity.class).putExtra("kind", kind)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        c.startActivity(i);
                        return J.ok("opened", "camera", "note", "Tell the user to take the photo; the result comes after.");
                    } catch (Exception e) { return J.fail("Could not open the camera: " + e.getMessage()); }
                });
    }

    private static void openMaps(Context c, Uri u) {
        Intent i = new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            i.setPackage("com.google.android.apps.maps");
            c.startActivity(i);
        } catch (Exception e) {
            i.setPackage(null);
            c.startActivity(i);
        }
    }

    private static JSONArray load(Context c) {
        try { return new JSONArray(Prefs.sp(c).getString("followups", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    private static void save(Context c, JSONArray a) {
        try {
            // keep the list short: drop finished ones beyond the newest 60
            JSONArray keep = new JSONArray();
            int done = 0;
            for (int i = a.length() - 1; i >= 0; i--) {
                JSONObject o = a.optJSONObject(i);
                if (o == null) continue;
                if (o.optBoolean("done") && ++done > 30) continue;
                keep.put(o);
            }
            JSONArray rev = new JSONArray();
            for (int i = keep.length() - 1; i >= 0; i--) rev.put(keep.get(i));
            Prefs.sp(c).edit().putString("followups", rev.toString()).apply();
        } catch (Exception ignored) { }
    }
}
