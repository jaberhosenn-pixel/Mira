package com.markvi.jarvis;

import android.app.Notification;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Collects the phone's notifications so the Smart Notification Filter shows real ones. */
public class NotifCatcher extends NotificationListenerService {

    private static final List<JSONObject> LIST = new ArrayList<>();

    /** A notification Mira can read back and, when the app offers a reply box, answer. */
    static final class Entry {
        String id, pkg, app, sender, text;
        long time;
        boolean group;
        Notification.Action reply;
        android.app.RemoteInput[] inputs;
    }

    private static final List<Entry> ENTRIES = new ArrayList<>();

    static synchronized List<Entry> entries() {
        return new ArrayList<>(ENTRIES);
    }

    public static boolean hasAccess(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(c.getPackageName());
    }

    public static synchronized String json() {
        JSONArray a = new JSONArray();
        for (JSONObject o : LIST) a.put(o);
        return a.toString();
    }

    @Override
    public void onListenerConnected() {
        try {
            for (StatusBarNotification s : getActiveNotifications()) add(s, false);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        add(sbn, true);
    }

    private void add(StatusBarNotification sbn, boolean fresh) {
        if (sbn == null || getPackageName().equals(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null) return;
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0 || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        Bundle e = n.extras;
        if (e == null) return;
        CharSequence t = e.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence big = e.getCharSequence(Notification.EXTRA_BIG_TEXT);
        CharSequence tx = big != null ? big : e.getCharSequence(Notification.EXTRA_TEXT);
        String title = t == null ? "" : t.toString();
        String text = tx == null ? "" : tx.toString();
        if (title.isEmpty() && text.isEmpty()) return;

        String pkg = sbn.getPackageName();
        String app = pkg;
        try {
            PackageManager pm = getPackageManager();
            app = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)));
        } catch (Exception ignored) {
        }

        boolean important = classify(pkg, app, title + " " + text);
        JSONObject o = J.obj(
                "id", "n_" + sbn.getKey().hashCode(),
                "app", app,
                "icon", icon(pkg, app, important),
                "sender", title.isEmpty() ? app : title,
                "title", app,
                "desc", text.length() > 200 ? text.substring(0, 200) : text,
                "isImportant", important,
                "time", new SimpleDateFormat("HH:mm", Locale.US).format(new Date(sbn.getPostTime())));

        try {
            Entry en = new Entry();
            en.id = o.optString("id");
            en.pkg = pkg;
            en.app = app;
            en.sender = title.isEmpty() ? app : title;
            en.text = text;
            en.time = sbn.getPostTime();
            try {
                if (android.os.Build.VERSION.SDK_INT >= 28) en.group = e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false);
                CharSequence ct = e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE);
                if (ct != null && ct.length() > 0) en.group = true;
            } catch (Throwable ignored) { }
            if (n.actions != null) {
                for (Notification.Action ac : n.actions) {
                    android.app.RemoteInput[] ri = ac.getRemoteInputs();
                    if (ri != null && ri.length > 0 && ac.actionIntent != null) {
                        en.reply = ac;
                        en.inputs = ri;
                        break;
                    }
                }
            }
            synchronized (NotifCatcher.class) {
                for (int i = ENTRIES.size() - 1; i >= 0; i--) {
                    if (ENTRIES.get(i).id.equals(en.id)) ENTRIES.remove(i);
                }
                ENTRIES.add(0, en);
                while (ENTRIES.size() > 80) ENTRIES.remove(ENTRIES.size() - 1);
            }
            if (fresh && isMessaging(pkg.toLowerCase(Locale.ROOT))) AutoReply.onMessage(getApplicationContext(), en);
            if (fresh && isMessaging(pkg.toLowerCase(Locale.ROOT)) && Prefs.sp(this).getBoolean("driving", false)) {
                ToolsExtra.driveAnnounce(getApplicationContext(), en.sender, text, app);
            }
        } catch (Throwable ex) {
            DebugLog.add("Notification entry failed: " + ex);
        }

        synchronized (NotifCatcher.class) {
            for (int i = LIST.size() - 1; i >= 0; i--) {
                if (LIST.get(i).optString("id").equals(o.optString("id"))) LIST.remove(i);
            }
            LIST.add(0, o);
            while (LIST.size() > 60) LIST.remove(LIST.size() - 1);
        }
    }

    private static boolean isMessaging(String pkg) {
        return pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("orca")
                || pkg.contains("messaging") || pkg.contains("mms") || pkg.contains("dialer")
                || pkg.contains("telecom") || pkg.contains("signal") || pkg.contains("gm");
    }

    private static boolean classify(String pkg, String app, String body) {
        String p = pkg.toLowerCase(Locale.ROOT);
        String b = (app + " " + body).toLowerCase(Locale.ROOT);
        if (b.matches("(?s).*(\\botp\\b|trxid|transaction|credited|debited|cash in|cash out|verification code|security code|পিন|ওটিপি|লেনদেন).*")) return true;
        if (b.matches("(?s).*(bkash|nagad|rocket|bank|ব্যাংক|বিকাশ|নগদ).*") && !b.matches("(?s).*(offer|sale|discount|% off|অফার).*")) return true;
        if (b.matches("(?s).*(sale|offer|discount|% off|deal|promo|voucher|coupon|pack|অফার|ডিসকাউন্ট|ছাড়|জিতুন|win ).*")) return false;
        return isMessaging(p);
    }

    private static String icon(String pkg, String app, boolean important) {
        String b = (pkg + " " + app).toLowerCase(Locale.ROOT);
        if (b.contains("bkash") || b.contains("nagad") || b.contains("bank")) return "🏦";
        if (b.contains("telegram")) return "✈️";
        if (b.contains("whatsapp") || b.contains("messag") || b.contains("orca")) return "💬";
        if (b.contains("daraz") || b.contains("shop")) return "🛍️";
        if (b.contains("food") || b.contains("pizza")) return "🍕";
        if (b.contains("mail")) return "✉️";
        return important ? "🔐" : "🔔";
    }
}
