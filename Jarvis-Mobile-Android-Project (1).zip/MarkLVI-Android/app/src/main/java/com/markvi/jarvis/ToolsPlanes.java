package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/**
 * Real, live aircraft from several free ADS-B networks at once (adsb.lol, airplanes.live, adsb.fi), merged and
 * de-duplicated so a gap in one network is filled by another. Plus route / airline lookup (adsbdb).
 * Nothing here is invented: if a source is down or a plane is not heard, it says so.
 */
public final class ToolsPlanes {
    private ToolsPlanes() {}

    private static final double NM_PER_KM = 0.539957;
    private static final Map<String, String> ICAO = new HashMap<>();

    static {
        String[] p = {"BG", "BBC", "EK", "UAE", "QR", "QTR", "EY", "ETD", "SQ", "SIA", "AI", "AIC", "6E", "IGO", "TG", "THA",
                "MH", "MAS", "SV", "SVA", "TK", "THY", "BA", "BAW", "LH", "DLH", "AA", "AAL", "UA", "UAL", "DL", "DAL",
                "CX", "CPA", "WY", "OMA", "GF", "GFA", "SG", "SEJ", "UL", "ALK", "KU", "KAC", "FZ", "FDB", "G9", "ABY",
                "QF", "QFA", "AF", "AFR", "KL", "KLM", "9W", "JAI", "NH", "ANA", "JL", "JAL", "KE", "KAL", "OZ", "AAR",
                "CA", "CCA", "MU", "CES", "CZ", "CSN", "BS", "UBG", "VS", "VIR", "TR", "TGW", "FD", "AIQ", "SQ", "SIA"};
        for (int i = 0; i + 1 < p.length; i += 2) ICAO.put(p[i], p[i + 1]);
    }

    /** Merged result of all sources. */
    static final class Result {
        final List<JSONObject> list = new ArrayList<>();
        final List<String> ok = new ArrayList<>();
        final List<String> failed = new ArrayList<>();
    }

    private static String[] pointUrls(double lat, double lon, int nm) {
        String la = String.format(Locale.US, "%.4f", lat), lo = String.format(Locale.US, "%.4f", lon);
        return new String[]{
                "adsb.lol|https://api.adsb.lol/v2/point/" + la + "/" + lo + "/" + nm,
                "airplanes.live|https://api.airplanes.live/v2/point/" + la + "/" + lo + "/" + nm,
                "adsb.fi|https://opendata.adsb.fi/api/v2/lat/" + la + "/lon/" + lo + "/dist/" + nm};
    }

    /** Asks every source at the same time (max ~12 s), merges by aircraft id, keeps the freshest position. */
    static Result fetchAround(double lat, double lon, int nm) {
        return fetchUrls(pointUrls(lat, lon, Math.max(1, Math.min(250, nm))));
    }

    static Result fetchUrls(String[] named) {
        final Result res = new Result();
        final String[] bodies = new String[named.length];
        final Thread[] th = new Thread[named.length];
        for (int i = 0; i < named.length; i++) {
            final int k = i;
            final String url = named[i].substring(named[i].indexOf('|') + 1);
            th[i] = new Thread(() -> {
                try {
                    bodies[k] = GeminiRest.httpGet(url);
                } catch (Throwable t) {
                    bodies[k] = null;
                }
            });
            th[i].start();
        }
        long end = System.currentTimeMillis() + 12000;
        for (Thread t : th) {
            try {
                t.join(Math.max(1, end - System.currentTimeMillis()));
            } catch (InterruptedException ignored) {
            }
        }
        Map<String, JSONObject> byId = new HashMap<>();
        for (int i = 0; i < named.length; i++) {
            String name = named[i].substring(0, named[i].indexOf('|'));
            String b = bodies[i];
            if (b == null) {
                res.failed.add(name);
                continue;
            }
            try {
                JSONObject j = new JSONObject(b);
                JSONArray ac = j.optJSONArray("ac");
                if (ac == null) ac = j.optJSONArray("aircraft");
                if (ac == null) { // an error or rate-limit message is not "zero aircraft"
                    res.failed.add(name);
                    continue;
                }
                res.ok.add(name);
                for (int q = 0; q < ac.length(); q++) {
                    JSONObject p = ac.optJSONObject(q);
                    if (p == null || !usable(p)) continue;
                    String id = p.optString("hex", "").toLowerCase(Locale.ROOT);
                    if (id.isEmpty()) continue;
                    JSONObject old = byId.get(id);
                    if (old == null || age(p) < age(old)) byId.put(id, p);
                }
            } catch (Throwable t) {
                res.failed.add(name);
            }
        }
        res.list.addAll(byId.values());
        return res;
    }

    private static double age(JSONObject p) {
        return p.optDouble("seen_pos", p.optDouble("seen", 0));
    }

    /** Has a real position, is recent, and is an aircraft (not a ground vehicle or obstacle). */
    private static boolean usable(JSONObject p) {
        if (!p.has("lat") || !p.has("lon")) return false;
        if (Math.abs(p.optDouble("lat")) < 0.01 && Math.abs(p.optDouble("lon")) < 0.01) return false;
        if (p.optString("category", "").matches("C[1-5]")) return false;
        return age(p) <= 60;
    }

    private static boolean onGround(JSONObject p) {
        return "ground".equals(p.optString("alt_baro"));
    }

    private static String callsign(JSONObject p) {
        return p.optString("flight", "").trim();
    }

    private static JSONObject describe(JSONObject p, double[] me) {
        boolean g = onGround(p);
        double alt = p.optDouble("alt_baro", p.optDouble("alt_geom", 0));
        JSONObject o = J.obj("flight", callsign(p), "registration", p.optString("r"), "aircraft_type", p.optString("t"),
                "altitude_ft", g ? 0 : (int) alt, "speed_kmh", (int) (p.optDouble("gs", 0) * 1.852),
                "heading_deg", (int) p.optDouble("track", p.optDouble("true_heading", 0)), "on_ground", g);
        if (me != null) {
            double d = EarthTools.haversine(me[0], me[1], p.optDouble("lat"), p.optDouble("lon"));
            double b = EarthTools.bearing(me[0], me[1], p.optDouble("lat"), p.optDouble("lon"));
            try {
                o.put("distance_km", Math.round(d * 10) / 10.0);
                o.put("direction", EarthTools.compass(b));
            } catch (Exception ignored) {
            }
        }
        return o;
    }

    private static double distKm(JSONObject p, double[] me) {
        return EarthTools.haversine(me[0], me[1], p.optDouble("lat"), p.optDouble("lon"));
    }

    private static String sourcesNote(Result r) {
        String s = "sources heard: " + (r.ok.isEmpty() ? "none" : join(r.ok));
        if (!r.failed.isEmpty()) s += "; not reachable: " + join(r.failed);
        return s;
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(s);
        }
        return sb.toString();
    }

    private static double[] center(Context c, JSONObject a) {
        double lat = a.optDouble("lat", Double.NaN), lon = a.optDouble("lon", Double.NaN);
        if (!Double.isNaN(lat) && !Double.isNaN(lon)) return new double[]{lat, lon};
        return EarthTools.userPos(c);
    }

    private static int radiusNm(JSONObject a, double defKm) {
        double km = a.optDouble("radius_km", defKm);
        if (km < 5) km = 5;
        if (km > 460) km = 460;
        return (int) Math.ceil(km * NM_PER_KM);
    }

    static void register() {
        reg("planes_count",
                "Counts the REAL aircraft that live ADS-B networks hear around the user (or around given lat/lon) right now, merged from three free networks: how many in total, how many flying, how many on the ground, plus the closest one. Use for 'how many flights are above me', 'কয়টা প্লেন আছে', 'কত ফ্লাইট'. Default radius 100 km, max 460 km. Honest limit: only aircraft that are heard by volunteer receivers are counted, so the true number can be higher, especially over sea or remote areas.",
                schema("", "radius_km:NUMBER:search radius in km (default 100, max 460)", "lat:NUMBER:optional centre latitude", "lon:NUMBER:optional centre longitude"),
                (c, a) -> {
                    try {
                        double[] me = center(c, a);
                        if (me == null) return J.fail("Location is off. Turn Location on, or tell me a place.");
                        int nm = radiusNm(a, 100);
                        Result r = fetchAround(me[0], me[1], nm);
                        if (r.ok.isEmpty()) return J.fail("Could not reach any live aircraft network. Check the internet.");
                        double maxKm = nm / NM_PER_KM;
                        int air = 0, gnd = 0;
                        JSONObject near = null;
                        double nd = 1e9;
                        for (JSONObject p : r.list) {
                            double d = distKm(p, me);
                            if (d > maxKm) continue;
                            if (onGround(p)) gnd++;
                            else air++;
                            if (d < nd && !onGround(p)) {
                                nd = d;
                                near = p;
                            }
                        }
                        JSONObject o = J.ok("total", air + gnd, "flying", air, "on_ground", gnd, "radius_km", Math.round(maxKm),
                                "note", sourcesNote(r) + ". Only aircraft heard by volunteer receivers are counted; the real number can be higher.");
                        if (near != null) o.put("closest_flying", describe(near, me));
                        return o;
                    } catch (Throwable t) {
                        return J.fail("Plane count failed: " + t.getMessage());
                    }
                });

        reg("planes_list",
                "Lists the closest REAL aircraft right now (flight number, registration, type, altitude, speed, heading, distance, direction), merged from three live ADS-B networks. Use for 'which planes are near me', 'আশেপাশে কোন কোন ফ্লাইট', 'list flights'. with_route=true also adds airline and origin->destination from a public route database (can be approximate or missing, never a live schedule).",
                schema("", "limit:INTEGER:how many (default 5, max 10)", "radius_km:NUMBER:search radius in km (default 150, max 460)",
                        "flying_only:BOOLEAN:true = skip planes on the ground (default true)", "with_route:BOOLEAN:add airline and route (default true)",
                        "lat:NUMBER:optional centre latitude", "lon:NUMBER:optional centre longitude"),
                (c, a) -> {
                    try {
                        double[] me = center(c, a);
                        if (me == null) return J.fail("Location is off. Turn Location on, or tell me a place.");
                        int limit = Math.max(1, Math.min(10, a.optInt("limit", 5)));
                        boolean flyOnly = a.optBoolean("flying_only", true);
                        boolean withRoute = a.optBoolean("with_route", true);
                        int nm = radiusNm(a, 150);
                        Result r = fetchAround(me[0], me[1], nm);
                        if (r.ok.isEmpty()) return J.fail("Could not reach any live aircraft network. Check the internet.");
                        final double[] m = me;
                        double maxKm = nm / NM_PER_KM;
                        List<JSONObject> l = new ArrayList<>();
                        for (JSONObject p : r.list) {
                            if (flyOnly && onGround(p)) continue;
                            if (distKm(p, m) > maxKm) continue;
                            l.add(p);
                        }
                        Collections.sort(l, new Comparator<JSONObject>() {
                            @Override
                            public int compare(JSONObject x, JSONObject y) {
                                return Double.compare(distKm(x, m), distKm(y, m));
                            }
                        });
                        if (l.size() > limit) l = new ArrayList<>(l.subList(0, limit));
                        final JSONObject[] rows = new JSONObject[l.size()];
                        Thread[] th = new Thread[l.size()];
                        for (int i = 0; i < l.size(); i++) {
                            final int k = i;
                            final JSONObject p = l.get(i);
                            rows[k] = describe(p, m);
                            th[k] = new Thread(() -> {
                                if (withRoute) addRoute(rows[k], callsign(p));
                            });
                            th[k].start();
                        }
                        long end = System.currentTimeMillis() + 10000;
                        for (Thread t : th) {
                            try {
                                t.join(Math.max(1, end - System.currentTimeMillis()));
                            } catch (InterruptedException ignored) {
                            }
                        }
                        JSONArray arr = new JSONArray();
                        synchronized (ToolsPlanes.class) {
                            for (JSONObject o : rows) arr.put(o);
                        }
                        String note = sourcesNote(r) + ".";
                        if (withRoute) note += " Route and airline come from a public database and may be approximate or missing.";
                        return J.ok("count_shown", rows.length, "aircraft", arr, "note", note);
                    } catch (Throwable t) {
                        return J.fail("Plane list failed: " + t.getMessage());
                    }
                });

        reg("plane_selected",
                "Tells which plane the user has tapped on the Plane Earth screen right now: flight, airline, aircraft, route (from/to), altitude, speed, heading, kilometres flown and to go, and an ESTIMATED time left. Use for 'this plane', 'ei plane ta kothay jachhe', 'what am I looking at', 'এই প্লেনটা কোথায় যাচ্ছে', when Plane Earth is open. If nothing is selected it says so. Route and airline come from a free public database and may be missing; the time left is an estimate from current speed, never a schedule.",
                schema(""),
                (c, a) -> {
                    String s = PlaneActivity.selectedJson;
                    if (s == null || s.isEmpty()) return J.fail("No plane is selected. Open Plane Earth and tap a plane first.");
                    try {
                        JSONObject o = new JSONObject(s);
                        return J.ok("plane", o, "note", "Live position is real; route and airline are from a public database and may be missing; time left is an estimate.");
                    } catch (Throwable t) {
                        return J.fail("Could not read the selected plane.");
                    }
                });

        reg("flight_info",
                "Looks up ONE flight or aircraft by flight number (EK585, BG147, UAE585, BBC147) or registration (S2-AJB, A6-EDA): where it is right now (if heard live), altitude, speed, and the airline, aircraft model and origin->destination from a public route database. Use for 'where is flight X', 'EK585 কোথায়', 'এই ফ্লাইট কোথা থেকে কোথায় যাচ্ছে'. If the plane is not heard right now it says so; schedules, delays and gates are NOT available in free data.",
                schema("query:STRING:flight number or registration"),
                (c, a) -> {
                    try {
                        String q = a.optString("query").trim().toUpperCase(Locale.ROOT).replace(" ", "").replace("_", "");
                        if (q.isEmpty()) return J.fail("Which flight or registration?");
                        String enc = URLEncoder.encode(q, "UTF-8");
                        List<String> tries = new ArrayList<>();
                        tries.add(q);
                        String icao = icaoCallsign(q);
                        if (icao != null && !icao.equals(q)) tries.add(icao);
                        JSONObject found = null;
                        String usedCall = q;
                        List<String> failed = new ArrayList<>();
                        for (String t : tries) {
                            String e = URLEncoder.encode(t, "UTF-8");
                            String[] urls = {"https://api.adsb.lol/v2/callsign/" + e, "https://api.airplanes.live/v2/callsign/" + e,
                                    "https://api.adsb.lol/v2/reg/" + e, "https://api.airplanes.live/v2/reg/" + e};
                            for (String u : urls) {
                                try {
                                    JSONObject j = new JSONObject(GeminiRest.httpGet(u));
                                    JSONArray ac = j.optJSONArray("ac");
                                    if (ac == null) ac = j.optJSONArray("aircraft");
                                    if (ac != null) {
                                        for (int i = 0; i < ac.length(); i++) {
                                            JSONObject p = ac.optJSONObject(i);
                                            if (p != null && p.has("lat") && p.has("lon")) {
                                                found = p;
                                                break;
                                            }
                                        }
                                    }
                                } catch (Throwable ex) {
                                    failed.add(u.substring(8, u.indexOf('/', 8)));
                                }
                                if (found != null) break;
                            }
                            if (found != null) {
                                usedCall = t;
                                break;
                            }
                        }
                        double[] me = EarthTools.userPos(c);
                        JSONObject o;
                        if (found != null) {
                            o = describe(found, me);
                            o.put("live", true);
                            o.put("latitude", Math.round(found.optDouble("lat") * 1000) / 1000.0);
                            o.put("longitude", Math.round(found.optDouble("lon") * 1000) / 1000.0);
                            o.put("position_age_seconds", (int) age(found));
                            String cs = callsign(found);
                            addRoute(o, cs.isEmpty() ? usedCall : cs);
                            addAircraft(c, o, found.optString("hex"));
                        } else {
                            o = J.obj("live", false);
                            addRoute(o, icao != null ? icao : q);
                            JSONObject sch0 = FlightApis.lookup(c, iataFlight(q));
                            if (sch0 != null) o.put("schedule", sch0);
                            o.put("note", "Not heard on live ADS-B right now (it may be on the ground, out of receiver range, or the number is different). Try the airline's ICAO callsign (for example BBC147 for BG147).");
                            return J.ok("flight", q, "result", o);
                        }
                        String ifl = iataFlight(q);
                        if (ifl == null && found != null) ifl = iataFlight(callsign(found));
                        JSONObject sch = FlightApis.lookup(c, ifl);
                        if (sch != null) o.put("schedule", sch);
                        else if (!FlightApis.any(c)) o.put("schedule_note", "Schedules, delays and gates need a flight API key (Settings > Flight data APIs).");
                        o.put("source", "live ADS-B + public route database" + (sch != null ? " + " + sch.optString("source") : ""));
                        return J.ok("flight", q, "result", o);
                    } catch (Throwable t) {
                        return J.fail("Flight lookup failed: " + t.getMessage());
                    }
                });
    }

    /** BBC147 -> BG147 (airline's IATA flight number) when the airline is known; null otherwise. */
    static String iataFlight(String call) {
        if (call == null) return null;
        call = call.trim().toUpperCase(Locale.ROOT);
        if (call.matches("[A-Z0-9]{2}\\d{1,4}[A-Z]?") && ICAO.containsKey(call.substring(0, 2))) return call;
        if (call.length() < 4) return null;
        String pre = call.substring(0, 3), num = call.substring(3);
        if (!num.matches("\\d{1,4}[A-Z]?")) return null;
        for (Map.Entry<String, String> e : ICAO.entrySet()) if (e.getValue().equals(pre)) return e.getKey() + num;
        return null;
    }

    /** BG147 -> BBC147 when the airline code is known; null if not an airline flight number. */
    private static String icaoCallsign(String q) {
        if (q.length() < 3) return null;
        String code = q.substring(0, 2);
        String num = q.substring(2);
        if (!num.matches("\\d{1,4}[A-Z]?")) return null;
        String icao = ICAO.get(code);
        return icao == null ? null : icao + num;
    }

    /** Adds airline and origin/destination from adsbdb. Silent when nothing is found. */
    private static void addRoute(JSONObject o, String call) {
        if (call == null || call.isEmpty()) return;
        try {
            JSONObject j = new JSONObject(GeminiRest.httpGet("https://api.adsbdb.com/v0/callsign/" + URLEncoder.encode(call, "UTF-8")));
            JSONObject fr = j.optJSONObject("response") == null ? null : j.optJSONObject("response").optJSONObject("flightroute");
            if (fr == null) return;
            JSONObject al = fr.optJSONObject("airline");
            JSONObject org = fr.optJSONObject("origin"), dst = fr.optJSONObject("destination");
            synchronized (ToolsPlanes.class) {
                if (al != null) o.put("airline", al.optString("name"));
                if (org != null) o.put("from", place(org));
                if (dst != null) o.put("to", place(dst));
                o.put("route_note", "from a public route database; can be approximate, not a live schedule");
            }
        } catch (Throwable ignored) {
        }
    }

    private static String place(JSONObject a) {
        String city = a.optString("municipality");
        String code = a.optString("iata_code");
        String name = a.optString("name");
        String s = city.isEmpty() ? name : city;
        return code.isEmpty() ? s : s + " (" + code + ")";
    }

    private static void addAircraft(android.content.Context c, JSONObject o, String hex) {
        if (hex == null || hex.isEmpty()) return;
        try {
            JSONObject loc = PlaneData.aircraft(c, hex);
            if (loc != null && (!loc.optString("model").isEmpty() || !loc.optString("owner").isEmpty())) {
                if (!loc.optString("model").isEmpty()) o.put("aircraft_model", loc.optString("model"));
                if (!loc.optString("owner").isEmpty()) o.put("operator", loc.optString("owner"));
                if (!loc.optString("reg").isEmpty() && o.optString("registration").isEmpty()) o.put("registration", loc.optString("reg"));
                return;
            }
        } catch (Throwable ignored) {
        }
        try {
            JSONObject j = new JSONObject(GeminiRest.httpGet("https://api.adsbdb.com/v0/aircraft/" + hex));
            JSONObject ac = j.optJSONObject("response") == null ? null : j.optJSONObject("response").optJSONObject("aircraft");
            if (ac == null) return;
            String m = (ac.optString("manufacturer") + " " + ac.optString("type")).trim();
            if (!m.isEmpty()) o.put("aircraft_model", m);
            String own = ac.optString("registered_owner");
            if (!own.isEmpty()) o.put("operator", own);
        } catch (Throwable ignored) {
        }
    }
}
