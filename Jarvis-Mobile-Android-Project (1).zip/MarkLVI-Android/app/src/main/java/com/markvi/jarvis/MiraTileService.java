package com.markvi.jarvis;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Quick Settings button: one tap opens Mira and starts listening. */
public class MiraTileService extends TileService {
    @Override
    public void onStartListening() {
        try {
            Tile t = getQsTile();
            if (t != null) {
                t.setState(Tile.STATE_INACTIVE);
                t.setLabel("Mira");
                t.updateTile();
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onClick() {
        try {
            Intent i = new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("assist", true);
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(PendingIntent.getActivity(this, 9200, i,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            } else {
                startActivityAndCollapse(i);
            }
        } catch (Throwable t) {
            DebugLog.add("Quick tile failed: " + t);
        }
    }
}
