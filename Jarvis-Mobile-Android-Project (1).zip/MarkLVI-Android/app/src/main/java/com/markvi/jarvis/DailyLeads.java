package com.markvi.jarvis;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONObject;

import java.util.Calendar;

/** Daily lead update: runs the web lead search once a day and saves only NEW leads. Set up by the user's command. */
public class DailyLeads extends BroadcastReceiver {
    private static final int REQ = 7311;

    @Override
    public void onReceive(final Context ctx, Intent i) {
        final Context c = ctx.getApplicationContext();
        schedule(c); // arm tomorrow first
        boolean started = false;
        try {
            SeriousService.begin(c);
            started = true;
        } catch (Exception ignored) {
        }
        final boolean fgs0 = started;
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean fgs = fgs0;
                android.os.PowerManager.WakeLock wl = null;
                try {
                    android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
                    wl = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "mira:dailyleads");
                    wl.acquire(25 * 60 * 1000L);
                } catch (Exception ignored) {
                }
                try {
                    JSONObject cfg = new JSONObject(Prefs.sp(c).getString("daily_leads", "{}"));
                    if (!cfg.optBoolean("on")) return;
                    JSONObject a = J.obj("niche", cfg.optString("niche"), "city", cfg.optString("city"),
                            "count", cfg.optInt("count", 30), "new_only", true);
                    JSONObject r = ToolsLeads.runFindLeads(c, a);
                    if (r.optBoolean("ok", true) && r.optInt("new_leads", 0) > 0) {
                        Util.notifyAlert(c, 4720, "Daily leads",
                                r.optInt("new_leads") + " new " + cfg.optString("niche") + " leads in " + cfg.optString("city") + " saved in Downloads.");
                    } else {
                        Util.notifyAlert(c, 4720, "Daily leads", "No new leads today for " + cfg.optString("niche") + " in " + cfg.optString("city") + ".");
                    }
                } catch (Exception e) {
                    DebugLog.add("Daily leads failed: " + e.getMessage());
                    Util.notifyAlert(c, 4720, "Daily leads", "Today's lead update failed: " + e.getMessage());
                } finally {
                    if (fgs) {
                        try {
                            SeriousService.end(c);
                        } catch (Exception ignored) {
                        }
                    }
                    try {
                        if (wl != null && wl.isHeld()) wl.release();
                    } catch (Exception ignored) {
                    }
                }
            }
        }).start();
    }

    /** Arms the next run (or cancels when switched off). Also called after boot. */
    public static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(c, REQ, new Intent(c, DailyLeads.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            JSONObject cfg = new JSONObject(Prefs.sp(c).getString("daily_leads", "{}"));
            if (!cfg.optBoolean("on")) {
                am.cancel(pi);
                return;
            }
            Calendar t = Calendar.getInstance();
            t.set(Calendar.HOUR_OF_DAY, cfg.optInt("hour", 9));
            t.set(Calendar.MINUTE, cfg.optInt("minute", 0));
            t.set(Calendar.SECOND, 0);
            if (t.getTimeInMillis() <= System.currentTimeMillis() + 60000) t.add(Calendar.DAY_OF_YEAR, 1);
            long when = t.getTimeInMillis();
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (Exception e) {
            DebugLog.add("Daily leads schedule failed: " + e.getMessage());
        }
    }
}
