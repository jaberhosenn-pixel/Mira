package com.markvi.jarvis;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;

/** The assistant gesture was used: open Mira and start listening (MainActivity starts the session). */
public class MiraSession extends VoiceInteractionSession {
    public MiraSession(Context context) {
        super(context);
    }

    @Override
    public void onShow(Bundle args, int showFlags) {
        super.onShow(args, showFlags);
        try {
            Intent i = new Intent(getContext(), MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    .putExtra("assist", true);
            getContext().startActivity(i);
        } catch (Throwable t) {
            DebugLog.add("Assistant gesture could not open Mira: " + t);
        }
        hide();
    }
}
