package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Multi-step phone tasks with saved progress, and saved "learned" step sequences (macros). All run only when the user asks. */
final class ToolsAgentPlus {
    private ToolsAgentPlus() {}

    private static final String KEY_TASK = "phone_task";
    private static final String KEY_MACROS = "macros";

    static void register() {
        reg("phone_task",
                "Does a BIG job on the phone made of several parts, one part after another, and remembers how far it got. Give 'steps': an array of short plain-language goals, "
                        + "each one doable on one app screen flow (e.g. [\"open WhatsApp and find the chat with Rahim\",\"type 'I will be late' and send it\"]). "
                        + "Each step is run by the screen agent and double-checked on screen. It stops at the first step that fails and says which one. "
                        + "resume:true continues the last unfinished task from the failed step. Never use for passwords, payments or deleting data.",
                schema("", "goal:STRING:the whole job in one sentence", "steps:STRING:JSON array of step goals", "resume:BOOLEAN:continue the last unfinished task",
                        "background:BOOLEAN:run it in the background and notify when it ends (screen must stay usable by Mira)"),
                (c, a) -> phoneTask(c, a));

        reg("phone_task_status",
                "Shows the result of the last background phone task and whether one is running now.",
                schema(""),
                (c, a) -> {
                    JSONObject last = load(c, "phone_task_last");
                    return J.ok("running", BG_RUNNING.get(), "last", last == null ? "none yet" : last);
                });

        reg("notification_digest",
                "A short grouped summary of the notifications on the phone right now: per app and sender how many and the newest text, with urgent-looking ones first "
                        + "(OTP, bank, urgent, missed call). Use for 'what did I miss', 'any important notifications'. Read it to the user briefly.",
                schema(""),
                (c, a) -> notificationDigest(c));

        reg("find_files",
                "Finds files on the phone by name (PDF, documents, spreadsheets, images, audio, video, anything), newest first. Use for 'find the PDF about invoice', "
                        + "'where is the file named report'. Searches Downloads, Documents and the media library.",
                schema("query", "query:STRING:part of the file name", "type:STRING:pdf|doc|sheet|image|audio|video|any (default any)", "count:INTEGER:default 10, max 25"),
                (c, a) -> findFiles(c, a));

        reg("macro_save",
                "Saves a step sequence the user wants to repeat ('learn this'). 'steps' uses the same format as ui_flow. Give it a short name. "
                        + "Only save a sequence that has just worked (for example after a successful ui_flow).",
                schema("name,steps", "name:STRING:short name", "steps:STRING:JSON array of ui_flow steps", "description:STRING:what it does"),
                (c, a) -> macroSave(c, a));
        reg("macro_run",
                "Runs a saved macro by name (see macro_list). Only when the user asks.",
                schema("name", "name:STRING:macro name"),
                (c, a) -> macroRun(c, a));
        reg("macro_list",
                "Lists the saved macros.",
                schema(""),
                (c, a) -> macroList(c));
        reg("macro_remove",
                "Deletes a saved macro by name.",
                schema("name", "name:STRING:macro name"),
                (c, a) -> macroRemove(c, a));
    }

    // ------------------------------------------------------------------ phone_task

    private static JSONObject phoneTask(Context c, JSONObject a) {
        try {
            JSONObject saved = load(c, KEY_TASK);
            JSONArray steps;
            int from = 0;
            String goal = a.optString("goal");
            if (a.optBoolean("resume", false)) {
                if (saved == null || saved.optJSONArray("steps") == null || saved.optBoolean("finished", true)) return J.fail("there is no unfinished task to resume");
                steps = saved.getJSONArray("steps");
                from = saved.optInt("next", 0);
                goal = saved.optString("goal", goal);
            } else {
                steps = a.optJSONArray("steps");
                if (steps == null) {
                    try {
                        steps = new JSONArray(a.optString("steps"));
                    } catch (Exception e) {
                        return J.fail("steps must be a JSON array of short goals");
                    }
                }
                if (steps.length() == 0) return J.fail("steps is empty");
            }
            if (JarvisAccessibility.get() == null) return J.fail("Accessibility is OFF. Turn Mira ON in Settings > Open All Permissions > Accessibility. Nothing was done.");
            if (a.optBoolean("background", false)) {
                if (!BG_RUNNING.compareAndSet(false, true)) return J.fail("a background phone task is already running");
                final JSONArray st = steps;
                final int fr = from;
                final String gl = goal;
                final Context app = c.getApplicationContext();
                new Thread(() -> {
                    try {
                        JSONObject r = runSteps(app, gl, st, fr);
                        save(app, "phone_task_last", r);
                        Util.notifyAlert(app, 4720, "Mira task " + ("ok".equals(r.optString("status")) ? "finished" : "stopped"),
                                "ok".equals(r.optString("status")) ? gl : r.optString("error"));
                    } finally {
                        BG_RUNNING.set(false);
                    }
                }, "mira-phone-task").start();
                return J.started("note", "the task runs in the background; the user gets a notification when it ends. phone_task_status shows the result.");
            }
            return runSteps(c, goal, steps, from);
        } catch (Throwable t) {
            return J.fail("phone task failed: " + t.getMessage());
        }
    }

    private static final java.util.concurrent.atomic.AtomicBoolean BG_RUNNING = new java.util.concurrent.atomic.AtomicBoolean(false);

    private static JSONObject runSteps(Context c, String goal, JSONArray steps, int from) {
        try {
            int n = Math.min(steps.length(), 12);
            JSONArray report = new JSONArray();
            for (int i = from; i < n; i++) {
                String g = steps.optString(i);
                DebugLog.add("Phone task step " + (i + 1) + "/" + n + ": " + g);
                SeriousLive.step("tool", "Phone task " + (i + 1) + "/" + n, g);
                JSONObject r;
                try {
                    r = ToolsApps.screenAgent(c, g, 10);
                } catch (Exception e) {
                    r = J.fail(String.valueOf(e.getMessage()));
                }
                boolean ok = "done".equals(r.optString("agent_result"));
                report.put(J.obj("step", i + 1, "goal", g, "result", ok ? (r.optBoolean("verified") ? "done and confirmed on screen" : "done, not confirmed") : "failed",
                        "detail", ok ? r.optString("note") : r.optString("error")));
                save(c, KEY_TASK, J.obj("goal", goal, "steps", steps, "next", ok ? i + 1 : i, "finished", ok && i + 1 >= n));
                if (!ok) {
                    return J.obj("status", "failed", "error", "step " + (i + 1) + " did not work: " + g, "report", report,
                            "note", "Tell the user which step failed. They can fix the screen and say 'resume the task'.");
                }
            }
            return J.obj("status", "ok", "report", report, "note", "all " + n + " steps were run; each is listed with whether the screen confirmed it");
        } catch (Throwable t) {
            return J.fail("phone task failed: " + t.getMessage());
        }
    }

    // ------------------------------------------------------------------ macros

    private static JSONObject macroSave(Context c, JSONObject a) {
        try {
            String name = a.optString("name").trim().toLowerCase(java.util.Locale.ROOT);
            if (name.isEmpty()) return J.fail("name is required");
            JSONArray steps = a.optJSONArray("steps");
            if (steps == null) {
                try {
                    steps = new JSONArray(a.optString("steps"));
                } catch (Exception e) {
                    return J.fail("steps must be a JSON array in the ui_flow format");
                }
            }
            if (steps.length() == 0) return J.fail("steps is empty");
            JSONObject all = load(c, KEY_MACROS);
            if (all == null) all = new JSONObject();
            if (all.length() >= 40 && !all.has(name)) return J.fail("too many macros (40); remove one first");
            all.put(name, J.obj("steps", steps, "description", a.optString("description"), "saved", System.currentTimeMillis()));
            save(c, KEY_MACROS, all);
            return J.ok("saved", name, "steps", steps.length());
        } catch (Throwable t) {
            return J.fail("could not save: " + t.getMessage());
        }
    }

    private static JSONObject macroRun(Context c, JSONObject a) {
        try {
            String name = a.optString("name").trim().toLowerCase(java.util.Locale.ROOT);
            JSONObject all = load(c, KEY_MACROS);
            JSONObject m = all == null ? null : all.optJSONObject(name);
            if (m == null) return J.fail("no macro named '" + name + "'. Use macro_list.");
            return Tools.dispatch(c, "ui_flow", J.obj("steps", m.getJSONArray("steps")));
        } catch (Throwable t) {
            return J.fail("macro failed: " + t.getMessage());
        }
    }

    private static JSONObject macroList(Context c) {
        try {
            JSONObject all = load(c, KEY_MACROS);
            JSONArray out = new JSONArray();
            if (all != null) {
                for (Iterator<String> it = all.keys(); it.hasNext(); ) {
                    String k = it.next();
                    JSONObject m = all.optJSONObject(k);
                    out.put(J.obj("name", k, "description", m == null ? "" : m.optString("description"), "steps", m == null || m.optJSONArray("steps") == null ? 0 : m.optJSONArray("steps").length()));
                }
            }
            return J.ok("count", out.length(), "macros", out);
        } catch (Throwable t) {
            return J.fail(String.valueOf(t.getMessage()));
        }
    }

    private static JSONObject macroRemove(Context c, JSONObject a) {
        try {
            String name = a.optString("name").trim().toLowerCase(java.util.Locale.ROOT);
            JSONObject all = load(c, KEY_MACROS);
            if (all == null || !all.has(name)) return J.fail("no macro named '" + name + "'");
            all.remove(name);
            save(c, KEY_MACROS, all);
            return J.ok("removed", name);
        } catch (Throwable t) {
            return J.fail(String.valueOf(t.getMessage()));
        }
    }

    // ------------------------------------------------------------------ notification digest

    private static JSONObject notificationDigest(Context c) {
        try {
            if (!NotifCatcher.hasAccess(c)) return J.fail("Notification access is OFF. Settings > Open All Permissions > Notification access > turn Mira on.");
            java.util.LinkedHashMap<String, JSONObject> groups = new java.util.LinkedHashMap<>();
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.US);
            for (NotifCatcher.Entry e : NotifCatcher.entries()) {
                if (e.group) continue;
                String key = e.app + "|" + e.sender;
                JSONObject g = groups.get(key);
                String low = (e.text + " " + e.sender).toLowerCase(java.util.Locale.ROOT);
                boolean urgent = low.matches(".*(otp|code|urgent|জরুরি|missed call|মিসড|bank|ব্যাংক|payment|পেমেন্ট|security|verify).*");
                if (g == null) {
                    g = J.obj("app", e.app, "from", e.sender, "count", 0, "newest", e.text, "time", f.format(new java.util.Date(e.time)), "urgent", urgent);
                    groups.put(key, g);
                }
                g.put("count", g.optInt("count") + 1);
                if (urgent) g.put("urgent", true);
            }
            JSONArray urgent = new JSONArray(), rest = new JSONArray();
            for (JSONObject g : groups.values()) (g.optBoolean("urgent") ? urgent : rest).put(g);
            JSONArray all = new JSONArray();
            for (int i = 0; i < urgent.length(); i++) all.put(urgent.get(i));
            for (int i = 0; i < rest.length() && all.length() < 20; i++) all.put(rest.get(i));
            return all.length() == 0 ? J.ok("note", "no notifications right now") : J.ok("groups", all.length(), "digest", all, "note", "urgent ones are first; urgent is a keyword guess, not a certainty");
        } catch (Throwable t) {
            return J.fail("digest failed: " + t.getMessage());
        }
    }

    // ------------------------------------------------------------------ file search

    private static JSONObject findFiles(Context c, JSONObject a) {
        try {
            final String q = a.optString("query").trim().toLowerCase(java.util.Locale.ROOT);
            if (q.isEmpty()) return J.fail("query is required");
            final String type = a.optString("type", "any").toLowerCase(java.util.Locale.ROOT);
            final int max = Math.max(1, Math.min(25, a.optInt("count", 10)));
            final String[] exts = extsFor(type);
            java.util.LinkedHashMap<String, long[]> found = new java.util.LinkedHashMap<>(); // path -> {time, size}
            try (android.database.Cursor cur = c.getContentResolver().query(android.provider.MediaStore.Files.getContentUri("external"),
                    new String[]{android.provider.MediaStore.MediaColumns.DATA, android.provider.MediaStore.MediaColumns.DATE_MODIFIED, android.provider.MediaStore.MediaColumns.SIZE},
                    android.provider.MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?", new String[]{"%" + q + "%"}, android.provider.MediaStore.MediaColumns.DATE_MODIFIED + " DESC")) {
                while (cur != null && cur.moveToNext() && found.size() < 200) {
                    String p = cur.getString(0);
                    if (p != null && extOk(p, exts)) found.put(p, new long[]{cur.getLong(1) * 1000, cur.getLong(2)});
                }
            } catch (Throwable ignored) {
            }
            java.io.File dl = SeriousMode.root();
            java.io.File[] roots = {dl, new java.io.File(dl.getParentFile(), "Documents")};
            for (java.io.File r : roots) walk(r, q, exts, found, 0);
            java.util.List<java.util.Map.Entry<String, long[]>> list = new java.util.ArrayList<>(found.entrySet());
            java.util.Collections.sort(list, (x, y) -> Long.compare(y.getValue()[0], x.getValue()[0]));
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US);
            JSONArray out = new JSONArray();
            for (java.util.Map.Entry<String, long[]> e : list) {
                if (out.length() >= max) break;
                out.put(J.obj("path", e.getKey(), "modified", f.format(new java.util.Date(e.getValue()[0])), "kb", e.getValue()[1] / 1024));
            }
            return out.length() == 0 ? J.ok("note", "no file with '" + q + "' in its name was found. If the file should exist, the Files/Storage permission may be missing.", "files", out)
                    : J.ok("count", out.length(), "files", out);
        } catch (Throwable t) {
            return J.fail("file search failed: " + t.getMessage());
        }
    }

    private static String[] extsFor(String t) {
        switch (t) {
            case "pdf": return new String[]{".pdf"};
            case "doc": return new String[]{".doc", ".docx", ".txt", ".odt", ".rtf", ".md"};
            case "sheet": return new String[]{".xls", ".xlsx", ".csv", ".ods"};
            case "image": return new String[]{".jpg", ".jpeg", ".png", ".webp", ".gif", ".heic"};
            case "audio": return new String[]{".mp3", ".m4a", ".wav", ".ogg", ".aac", ".opus"};
            case "video": return new String[]{".mp4", ".mkv", ".webm", ".3gp", ".mov"};
            default: return null;
        }
    }

    private static boolean extOk(String path, String[] exts) {
        if (exts == null) return true;
        String l = path.toLowerCase(java.util.Locale.ROOT);
        for (String e : exts) if (l.endsWith(e)) return true;
        return false;
    }

    private static void walk(java.io.File d, String q, String[] exts, java.util.Map<String, long[]> out, int depth) {
        if (d == null || depth > 4 || out.size() >= 300) return;
        java.io.File[] fs = d.listFiles();
        if (fs == null) return;
        for (java.io.File f : fs) {
            if (f.isDirectory()) walk(f, q, exts, out, depth + 1);
            else if (f.getName().toLowerCase(java.util.Locale.ROOT).contains(q) && extOk(f.getName(), exts)) out.put(f.getAbsolutePath(), new long[]{f.lastModified(), f.length()});
        }
    }

    private static JSONObject load(Context c, String key) {
        try {
            String s = Prefs.sp(c).getString(key, "");
            return s.isEmpty() ? null : new JSONObject(s);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void save(Context c, String key, JSONObject o) {
        Prefs.sp(c).edit().putString(key, o.toString()).apply();
    }
}
