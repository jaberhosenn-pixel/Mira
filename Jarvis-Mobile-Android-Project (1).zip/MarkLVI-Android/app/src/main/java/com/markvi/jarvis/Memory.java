package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/** Long-term memory (mobile twin of memory/memory_manager.py). category -> key -> value. */
public final class Memory {
    private Memory() {}

    private static final int PROMPT_BUDGET = 3000;

    private static synchronized JSONObject load(Context c) {
        return J.parse(Prefs.sp(c).getString("memory", "{}"));
    }

    private static synchronized void store(Context c, JSONObject m) {
        Prefs.sp(c).edit().putString("memory", m.toString()).apply();
    }

    public static synchronized void save(Context c, String category, String key, String value) {
        if (category == null || category.trim().isEmpty()) category = "notes";
        category = category.trim().toLowerCase(Locale.ROOT);
        JSONObject m = load(c);
        JSONObject cat = m.optJSONObject(category);
        if (cat == null) cat = new JSONObject();
        J.put(cat, key.trim().toLowerCase(Locale.ROOT).replace(' ', '_'), value);
        J.put(m, category, cat);
        store(c, m);
    }

    public static synchronized String recall(Context c, String query) {
        JSONObject m = load(c);
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        StringBuilder sb = new StringBuilder();
        Iterator<String> cats = m.keys();
        while (cats.hasNext()) {
            String cat = cats.next();
            JSONObject o = m.optJSONObject(cat);
            if (o == null) continue;
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                String v = o.optString(k);
                if (q.isEmpty() || cat.contains(q) || k.contains(q) || v.toLowerCase(Locale.ROOT).contains(q)) {
                    sb.append(cat).append(" / ").append(k).append(": ").append(v).append('\n');
                }
            }
        }
        return sb.toString().trim();
    }

    /** Memory block for the system prompt; keys that do not fit are listed under [ALSO REMEMBERED]. */
    public static synchronized String promptBlock(Context c) {
        JSONObject m = load(c);
        StringBuilder shown = new StringBuilder();
        List<String> hidden = new ArrayList<>();
        Iterator<String> cats = m.keys();
        while (cats.hasNext()) {
            String cat = cats.next();
            JSONObject o = m.optJSONObject(cat);
            if (o == null) continue;
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                String line = cat + "/" + k + ": " + o.optString(k) + "\n";
                if (shown.length() + line.length() <= PROMPT_BUDGET) shown.append(line);
                else hidden.add(cat + "/" + k);
            }
        }
        if (shown.length() == 0 && hidden.isEmpty()) return "(nothing stored yet)";
        StringBuilder out = new StringBuilder(shown.toString().trim());
        if (!hidden.isEmpty()) {
            out.append("\n[ALSO REMEMBERED] ");
            for (int i = 0; i < hidden.size(); i++) {
                if (i > 0) out.append(", ");
                out.append(hidden.get(i));
            }
        }
        return out.toString();
    }

    public static synchronized JSONArray all(Context c) {
        JSONArray a = new JSONArray();
        JSONObject m = load(c);
        Iterator<String> cats = m.keys();
        while (cats.hasNext()) {
            String cat = cats.next();
            JSONObject o = m.optJSONObject(cat);
            if (o == null) continue;
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                a.put(J.obj("category", cat, "key", k, "value", o.optString(k)));
            }
        }
        return a;
    }

    public static synchronized void clear(Context c) {
        store(c, new JSONObject());
    }
}
