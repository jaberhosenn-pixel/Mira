package com.markvi.jarvis;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Live feed of a running Serious-mode job. The HUD polls state(); nothing here touches the network. */
final class SeriousLive {
    private SeriousLive() {}

    private static final Object LOCK = new Object();
    private static final List<JSONObject> EVENTS = new ArrayList<>();
    private static boolean active = false;
    private static String job = "";
    private static String summary = "";
    private static String previewPath = "";
    private static int version = 0;
    private static int previewVersion = 0;
    private static long startedAt = 0;
    private static String codeName = "";
    private static String codeText = "";
    private static int codeVersion = 0;

    static void begin(String j) {
        synchronized (LOCK) {
            EVENTS.clear();
            active = true;
            job = j == null ? "" : j;
            summary = "";
            previewPath = "";
            codeName = "";
            codeText = "";
            codeVersion = 0;
            startedAt = System.currentTimeMillis();
            version++;
        }
        step("start", "Job started", job);
    }

    static void end(String s) {
        synchronized (LOCK) {
            active = false;
            summary = s == null ? "" : s;
            version++;
        }
        step("done", "Finished", summary);
    }

    static boolean isActive() {
        synchronized (LOCK) {
            return active;
        }
    }

    /** kind: start | think | say | tool | result | file | error | done */
    static void step(String kind, String title, String detail) {
        synchronized (LOCK) {
            if (!active && !"done".equals(kind)) return;
            try {
                if (detail != null && detail.length() > 400) detail = detail.substring(0, 400) + "…";
                EVENTS.add(J.obj("k", kind, "t", title == null ? "" : title, "d", detail == null ? "" : detail,
                        "at", System.currentTimeMillis() - startedAt));
                while (EVENTS.size() > 80) EVENTS.remove(0);
                version++;
            } catch (Throwable ignored) {
            }
        }
    }

    /** What the AI is writing right now (file text or plain words), shown typing live in the Code tab. */
    static void code(String name, String text) {
        synchronized (LOCK) {
            if (!active || text == null) return;
            if (text.length() > 60000) text = "…" + text.substring(text.length() - 60000);
            if (text.equals(codeText) && name.equals(codeName)) return;
            codeName = name;
            codeText = text;
            codeVersion++;
            version++;
        }
    }

    static String codeText() {
        synchronized (LOCK) {
            return codeText;
        }
    }

    /** Value of a JSON string field inside text that may still be arriving (cut off anywhere). null when the field has not started. */
    static String partialJsonString(String json, String key) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\"" + java.util.regex.Pattern.quote(key) + "\"\\s*:\\s*\"").matcher(json);
        if (!m.find()) return null;
        StringBuilder sb = new StringBuilder();
        int i = m.end(), n = json.length();
        while (i < n) {
            char ch = json.charAt(i);
            if (ch == '"') break;
            if (ch == '\\') {
                if (i + 1 >= n) break;
                char e = json.charAt(i + 1);
                if (e == 'u') {
                    if (i + 6 > n) break;
                    try {
                        sb.append((char) Integer.parseInt(json.substring(i + 2, i + 6), 16));
                    } catch (Exception ex) {
                        break;
                    }
                    i += 6;
                    continue;
                }
                sb.append(e == 'n' ? '\n' : e == 't' ? '\t' : e == 'r' ? '\r' : e == 'b' ? '\b' : e == 'f' ? '\f' : e);
                i += 2;
                continue;
            }
            sb.append(ch);
            i++;
        }
        return sb.toString();
    }

    /** A file was saved or changed; .html files become the live preview. */
    static void file(String path) {
        if (path == null) return;
        synchronized (LOCK) {
            if (!active) return;
            if (path.toLowerCase(java.util.Locale.ROOT).matches(".*\\.html?$")) {
                previewPath = path;
                previewVersion++;
                version++;
            }
        }
        step("file", "Saved " + path.substring(path.lastIndexOf('/') + 1), path);
    }

    /** Human title for a tool call, from its name and arguments. */
    static String describeTool(String name, JSONObject a) {
        try {
            switch (name) {
                case "save_file": return "Saving " + a.optString("filename", "a file");
                case "edit_file": return "Editing " + a.optString("path", "a file").replaceAll(".*/", "");
                case "make_excel": return "Making Excel " + a.optString("filename", "");
                case "preview_website": return "Opening the preview";
                default: return "Using " + name;
            }
        } catch (Throwable t) {
            return "Using " + name;
        }
    }

    static String state(int since) {
        synchronized (LOCK) {
            try {
                JSONObject o = new JSONObject();
                o.put("v", version);
                o.put("active", active);
                o.put("job", job);
                o.put("path", previewPath);
                o.put("pv", previewVersion);
                o.put("cv", codeVersion);
                o.put("cn", codeName);
                if (since != version) {
                    JSONArray arr = new JSONArray();
                    for (JSONObject e : EVENTS) arr.put(e);
                    o.put("events", arr);
                }
                return o.toString();
            } catch (Throwable t) {
                return "{}";
            }
        }
    }
}
