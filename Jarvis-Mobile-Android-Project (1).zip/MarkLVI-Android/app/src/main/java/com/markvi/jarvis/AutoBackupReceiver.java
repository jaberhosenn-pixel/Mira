package com.markvi.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Nightly backup: writes Mira-backup-DATE.json to Downloads, then plans the next night. */
public class AutoBackupReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(final Context c, Intent i) {
        final Context app = c.getApplicationContext();
        ToolsExtra.scheduleBackup(app); // plan tomorrow first so a failure never stops the routine
        final android.os.PowerManager.WakeLock wl = ((android.os.PowerManager) app.getSystemService(Context.POWER_SERVICE))
                .newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "mira:backup");
        wl.acquire(60000L);
        new Thread(() -> {
            try {
                String path = Backup.export(app, ToolsExtra.cachedLocal(app), false);
                DebugLog.add("Nightly backup saved: " + path);
                Util.notifyAlert(app, 4820, "Mira backup", "Saved to Downloads: " + new java.io.File(path).getName());
            } catch (Throwable t) {
                DebugLog.add("Nightly backup failed: " + t);
                Util.notifyAlert(app, 4821, "Mira backup failed", String.valueOf(t.getMessage()));
            } finally {
                if (wl.isHeld()) wl.release();
            }
        }, "mira-backup").start();
    }
}
