package com.markvi.jarvis;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Offline Mira (step 1). No internet and no API key: the phone's own offline speech recogniser, a rule based command
 * router, and the phone's own text to speech. It only does what it can do for real and says so otherwise.
 */
public final class OfflineMira {
    private OfflineMira() {}

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static SpeechRecognizer sr;
    private static TextToSpeech tts;
    private static boolean ttsReady, active;
    private static String lang = "bn-BD";
    private static int silent;
    private static Runnable onDone;
    private static Context app;

    // ------------------------------------------------------------------ online check

    public static boolean online(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            return nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
        } catch (Throwable t) {
            return true; // unknown: behave as before (Gemini)
        }
    }

    public static boolean forced(Context c) {
        return Prefs.sp(c).getBoolean("force_offline", false);
    }

    public static boolean shouldUse(Context c) {
        return forced(c) || !online(c);
    }

    // ------------------------------------------------------------------ session

    public static synchronized void start(Context c, Runnable done) {
        if (active) return;
        active = true;
        app = c.getApplicationContext();
        onDone = done;
        silent = 0;
        lang = "bn-BD";
        whisperBroken = false;
        Bus.state("CONNECTING");
        Bus.log("Offline mode: ON");
        MAIN.post(() -> {
            if (tts == null) {
                tts = new TextToSpeech(app, st -> {
                    ttsReady = st == TextToSpeech.SUCCESS;
                    MAIN.post(() -> say("অফলাইন মোড চালু। বলুন।", true));
                });
            } else {
                say("অফলাইন মোড চালু। বলুন।", true);
            }
        });
    }

    public static synchronized void stop() {
        if (!active) return;
        active = false;
        Bus.log("Offline mode: OFF");
        WhisperEngine.cancel();
        MAIN.post(() -> {
            new Thread(WhisperEngine::release, "mira-wrel").start();
            try { if (sr != null) { sr.cancel(); sr.destroy(); } } catch (Throwable ignored) { }
            sr = null;
            try { if (tts != null) tts.stop(); } catch (Throwable ignored) { }
            Bus.state("IDLE");
            Runnable d = onDone;
            onDone = null;
            if (d != null) d.run();
        });
    }

    public static boolean isActive() { return active; }

    /** Speaks something that arrived while the offline session is running (for example a scan result). */
    public static void announce(String text) {
        MAIN.post(() -> { if (active) say(text, true); });
    }

    private static void say(String text, boolean thenListen) {
        if (!active) return;
        Bus.state("SPEAKING");
        Bus.Ui u = Bus.ui;
        if (u != null) u.onAssistantText(text, true);
        if (!ttsReady) {
            // no voice available: the text is on screen, keep listening
            if (thenListen) MAIN.postDelayed(OfflineMira::listen, 600);
            return;
        }
        try {
            Locale l = new Locale("bn", "BD");
            boolean bn = text.matches("(?s).*[\\u0980-\\u09FF].*");
            if (!bn || tts.isLanguageAvailable(l) < TextToSpeech.LANG_AVAILABLE) l = bn ? Locale.getDefault() : Locale.US;
            tts.setLanguage(l);
            tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { if (thenListen) MAIN.post(OfflineMira::listen); }
                @Override public void onError(String id) { if (thenListen) MAIN.post(OfflineMira::listen); }
            });
            tts.speak(text.length() > 300 ? text.substring(0, 300) : text, TextToSpeech.QUEUE_FLUSH, null, "mira-off");
        } catch (Throwable t) {
            if (thenListen) MAIN.postDelayed(OfflineMira::listen, 600);
        }
    }

    private static boolean whisperBroken;

    private static void listenWhisper() {
        Bus.state("LISTENING");
        new Thread(() -> {
            String t = WhisperEngine.heardOnce(app, Prefs.sp(app).getString("whisper_lang", "bn"));
            MAIN.post(() -> {
                if (!active) return;
                if (t == null) { whisperBroken = true; Bus.log("Whisper failed, using the phone recogniser"); listen(); return; }
                if (t.isEmpty()) {
                    silent++;
                    if (silent >= 3) { say("কিছু শুনতে পাইনি, বন্ধ করছি।", false); MAIN.postDelayed(OfflineMira::stop, 2500); }
                    else listen();
                    return;
                }
                silent = 0;
                ArrayList<String> l = new ArrayList<>();
                l.add(t);
                handle(l);
            });
        }, "mira-whisper").start();
    }

    private static void listen() {
        if (!active) return;
        if (!whisperBroken && WhisperEngine.ready(app)) { listenWhisper(); return; }
        try {
            if (!SpeechRecognizer.isRecognitionAvailable(app)) {
                say("এই ফোনে স্পিচ রিকগনিশন পাওয়া যায়নি।", false);
                MAIN.postDelayed(OfflineMira::stop, 3000);
                return;
            }
            if (sr != null) sr.destroy();
            sr = SpeechRecognizer.createSpeechRecognizer(app);
            sr.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { Bus.state("LISTENING"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float v) { }
                @Override public void onBufferReceived(byte[] b) { }
                @Override public void onEndOfSpeech() { Bus.state("THINKING"); }
                @Override public void onPartialResults(Bundle b) { }
                @Override public void onEvent(int t, Bundle b) { }
                @Override public void onError(int e) {
                    if (!active) return;
                    if ((e == 12 || e == 13) && lang.startsWith("bn")) { // language not supported offline
                        lang = "en-US";
                        say("বাংলা অফলাইন স্পিচ নেই। ইংরেজিতে বলুন, যেমন flashlight on, call Rahim.", true);
                        return;
                    }
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        say("মাইক্রোফোনের পারমিশন দিন।", false);
                        MAIN.postDelayed(OfflineMira::stop, 3000);
                        return;
                    }
                    silent++;
                    if (silent >= 3) { say("কিছু শুনতে পাইনি, বন্ধ করছি।", false); MAIN.postDelayed(OfflineMira::stop, 2500); }
                    else MAIN.postDelayed(OfflineMira::listen, 400);
                }
                @Override public void onResults(Bundle b) {
                    ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l == null || l.isEmpty()) { silent++; MAIN.postDelayed(OfflineMira::listen, 300); return; }
                    silent = 0;
                    handle(l);
                }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            sr.startListening(i);
        } catch (Throwable t) {
            DebugLog.add("Offline listen failed: " + t);
            silent++;
            if (silent < 3) MAIN.postDelayed(OfflineMira::listen, 800); else stop();
        }
    }

    private static void handle(ArrayList<String> alts) {
        final String first = alts.get(0);
        Bus.Ui u = Bus.ui;
        if (u != null) u.onUserText(first, true);
        new Thread(() -> {
            String reply = null;
            for (String t : alts) {
                try { reply = route(app, t); } catch (Throwable ex) { DebugLog.add("Offline route: " + ex); }
                if (reply != null) break;
            }
            if (reply == null) reply = "বুঝতে পারিনি। বলুন: টর্চ জ্বালাও, ভলিউম বাড়াও, রহিমকে কল দাও, ১০ মিনিটের টাইমার, নোট লেখো।";
            final String r = reply;
            if (r.startsWith("\u0001")) { // stop request
                MAIN.post(() -> { say(r.substring(1), false); MAIN.postDelayed(OfflineMira::stop, 2000); });
            } else {
                MAIN.post(() -> say(r, true));
            }
        }, "mira-offline").start();
    }

    // ------------------------------------------------------------------ rules

    // ------------------------------------------------------------------ fuzzy matching (Whisper often misspells Bengali)

    private static final String[] VOCAB = {
            "টর্চ", "ফ্ল্যাশলাইট", "ভলিউম", "ব্রাইটনেস", "ওয়াইফাই", "ব্লুটুথ", "অ্যালার্ম", "টাইমার", "ব্যাটারি", "খরচ", "নোট",
            "কল", "ফোন", "খোলো", "ওপেন", "বাড়াও", "কমাও", "বন্ধ", "চালু", "জ্বালাও", "মিউট", "সাইলেন্ট", "লোকেশন",
            "এলার্ম", "ক্যালেন্ডার", "ইভেন্ট", "মেসেজ", "এসএমএস", "মিসড", "পাঠাও", "পড়ো", "অফলাইন", "অনলাইন", "ভাষা", "ইংরেজি", "বাংলা",
            "torch", "flashlight", "volume", "brightness", "wifi", "bluetooth", "alarm", "timer", "battery", "expense", "note",
            "call", "open", "increase", "decrease", "mute", "silent", "location", "calendar", "message", "missed", "offline", "online"};

    private static final java.util.Map<String, String> ALIAS = new java.util.HashMap<>();
    static {
        String[][] a = {{"টর্স", "টর্চ"}, {"টর্জ", "টর্চ"}, {"টরচ", "টর্চ"}, {"মিসদ", "মিসড"}, {"মিস্ড", "মিসড"}, {"খরছ", "খরচ"}, {"খরস", "খরচ"},
                {"কর্ল", "কল"}, {"ফোন", "ফোন"}, {"আলার্ম", "অ্যালার্ম"}, {"এলার্ম", "অ্যালার্ম"}, {"ওপেন", "ওপেন"}, {"নট", "নোট"},
                {"টাইমর", "টাইমার"}, {"ভলিউম", "ভলিউম"}, {"ভলুম", "ভলিউম"}, {"ওয়াইফাই", "ওয়াইফাই"}, {"ওয়াফাই", "ওয়াইফাই"}};
        for (String[] x : a) ALIAS.put(x[0], x[1]);
    }

    static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev; prev = cur; cur = t;
        }
        return prev[b.length()];
    }

    /** Spelling variants that sound the same: reduces many Bengali spellings to one before comparing. */
    static String skeleton(String w) {
        String x = java.text.Normalizer.normalize(w, java.text.Normalizer.Form.NFC).toLowerCase(Locale.ROOT);
        x = x.replace("\u09CD", "").replace("\u09BC", "").replace("\u200C", "").replace("\u200D", "")
                .replace("\u0982", "\u0999").replace("\u0983", "").replace("\u09C0", "\u09BF").replace("\u09C2", "\u09C1")
                .replace("\u09B6", "\u09B8").replace("\u09B7", "\u09B8").replace("\u09A3", "\u09A8")
                .replace("\u099C", "\u09AF").replace("\u09DF", "\u09AF").replace("\u09B0\u09CD", "\u09B0")
                .replace("\u09BE", "").replace("\u09CB", "").replace("\u09C7", "").replace("\u09C1", "").replace("\u09BF", "");
        return x;
    }

    /** Replaces each word by the closest known command word when it is nearly the same (typos, odd spellings). */
    static String fuzz(String text) {
        if (text == null) return "";
        text = text.replaceAll("ওয়াই\\s+ফাই", "ওয়াইফাই").replaceAll("ব্লু\\s+টুথ", "ব্লুটুথ").replaceAll("ফ্ল্যাশ\\s+লাইট", "ফ্ল্যাশলাইট");
        String[] tok = text.replaceAll("[\u0964?!,\"]", " ").trim().split("\\s+");
        StringBuilder out = new StringBuilder();
        for (String t : tok) {
            String best = t;
            String al = ALIAS.get(t);
            if (al != null) best = al;
            else if (t.length() >= 2) {
                int bestD = 99;
                String sk = skeleton(t);
                for (String v : VOCAB) {
                    if (v.equalsIgnoreCase(t)) { best = t; bestD = -1; break; }
                    String vs = skeleton(v);
                    int d = lev(sk, vs);
                    int lim = sk.length() <= 3 ? 0 : sk.length() <= 6 ? 1 : 2;
                    if (d <= lim && d < bestD) { bestD = d; best = v; }
                }
            }
            out.append(best).append(' ');
        }
        return out.toString().trim();
    }

    private static String speakList(JSONObject r, int max) {
        try {
            org.json.JSONArray arr = null;
            java.util.Iterator<String> it = r.keys();
            while (it.hasNext()) { Object o = r.opt(it.next()); if (o instanceof org.json.JSONArray) { arr = (org.json.JSONArray) o; break; } }
            if (arr == null || arr.length() == 0) return null;
            StringBuilder b = new StringBuilder();
            for (int i = 0; i < arr.length() && i < max; i++) {
                JSONObject e = arr.optJSONObject(i);
                if (e == null) continue;
                String who = e.optString("title", e.optString("from", e.optString("name", "")));
                String what = e.optString("text", e.optString("type", ""));
                String when = e.optString("begin", e.optString("time", ""));
                b.append(i + 1).append(". ");
                if (!who.isEmpty()) b.append(who).append(' ');
                if (!what.isEmpty() && !what.equals(who)) b.append(what.length() > 80 ? what.substring(0, 80) : what).append(' ');
                if (!when.isEmpty()) b.append(when);
                b.append(". ");
            }
            return b.toString().trim();
        } catch (Throwable t) { return null; }
    }

    static String digits(String s) {
        StringBuilder b = new StringBuilder();
        for (char ch : s.toCharArray()) b.append(ch >= '০' && ch <= '৯' ? (char) ('0' + ch - '০') : ch);
        return b.toString();
    }

    private static boolean has(String s, String re) {
        return Pattern.compile(re, Pattern.CASE_INSENSITIVE).matcher(s).find();
    }

    private static String result(JSONObject r, String ok) {
        String st = r.optString("status");
        if ("done".equals(st) || "started".equals(st)) return ok;
        String e = r.optString("error");
        return e.isEmpty() ? "পারলাম না।" : "পারলাম না: " + e;
    }

    private static String act(Context c, String action, String okMsg) {
        return result(Tools.dispatchUser(c, "phone_settings", J.obj("action", action)), okMsg);
    }

    /** Returns the spoken answer, or null when no rule matches. A leading \u0001 means: say it, then stop. */
    static String route(Context c, String raw) {
        String fx = fuzz(digits(raw == null ? "" : raw.trim()));
        String s = fx.toLowerCase(Locale.ROOT);
        if (s.isEmpty()) return null;
        raw = fx;

        if (has(s, "(বন্ধ কর|থামো|থাম|ধন্যবাদ|\\bstop\\b|\\bbye\\b|\\bexit\\b|শুভ রাত্রি)")) return "\u0001ঠিক আছে।";

        // things that need the internet: say so honestly, never invent
        if (has(s, "(আইএসএস|iss|ভূমিকম্প|earthquake|রাডার|radar|খবর|news|আবহাওয়া|weather|বাতাসের মান|aqi|ডলার|dollar|সোনার|gold|প্লেন|plane|flight)"))
            return "এটা লাইভ তথ্য, ইন্টারনেট ছাড়া দিতে পারব না। নেট আসলে বলবেন।";

        // torch / flashlight
        if (has(s, "(টর্চ|torch|flash ?light|ফ্ল্যাশ|ফ্লাশ)")) {
            if (has(s, "(বন্ধ|অফ|নিভা|off)")) return act(c, "flashlight_off", "টর্চ বন্ধ।");
            return act(c, "flashlight_on", "টর্চ জ্বলছে।");
        }
        // volume
        if (has(s, "(ভলিউম|volume|আওয়াজ|সাউন্ড)")) {
            if (has(s, "(বাড়া|বেশি|up|increase)")) return act(c, "volume_up", "ভলিউম বাড়ালাম।");
            if (has(s, "(কমা|কম|down|decrease|low)")) return act(c, "volume_down", "ভলিউম কমালাম।");
            Matcher m = Pattern.compile("(\\d{1,3})").matcher(s);
            if (m.find()) {
                int lv = Math.min(100, Integer.parseInt(m.group(1)));
                return result(Tools.dispatchUser(c, "phone_settings", J.obj("action", "volume_set", "level", lv)), "ভলিউম " + lv + " করলাম।");
            }
        }
        if (has(s, "(মিউট|mute|সাইলেন্ট|silent)")) {
            if (has(s, "(unmute|আনমিউট)")) return act(c, "unmute", "মিউট খুললাম।");
            return act(c, "mute", "মিউট করলাম।");
        }
        // brightness
        if (has(s, "(ব্রাইটনেস|brightness|আলো)")) {
            if (has(s, "(বাড়া|বেশি|up)")) return act(c, "brightness_up", "ব্রাইটনেস বাড়ালাম।");
            if (has(s, "(কমা|কম|down)")) return act(c, "brightness_down", "ব্রাইটনেস কমালাম।");
        }
        // panels
        if (has(s, "(ওয়াই ?ফাই|wifi|wi-fi)")) return act(c, "wifi", "ওয়াইফাই সেটিংস খুলছি।");
        if (has(s, "(ব্লুটুথ|bluetooth)")) return act(c, "bluetooth", "ব্লুটুথ সেটিংস খুলছি।");
        if (has(s, "(লোকেশন|location)") && has(s, "(খোল|open|সেটিং)")) return act(c, "location", "লোকেশন সেটিংস খুলছি।");
        if (has(s, "(ডু নট ডিস্টার্ব|do not disturb|\\bdnd\\b)")) return act(c, has(s, "(বন্ধ|off)") ? "do_not_disturb_off" : "do_not_disturb_on", "ঠিক আছে।");
        if (has(s, "(প্লে|play|pause|পজ|গান থামা)") && has(s, "(গান|মিউজিক|music|play|pause)")) return act(c, "play_pause", "ঠিক আছে।");

        // battery / time / date
        if (has(s, "(ব্যাটারি|battery|চার্জ)")) {
            try {
                BatteryManager bm = (BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
                int p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                return "ব্যাটারি " + p + " শতাংশ।";
            } catch (Throwable t) { return "ব্যাটারি জানতে পারলাম না।"; }
        }
        if (has(s, "(কয়টা|কটা|সময়|what time|\\btime\\b)")) {
            Calendar k = Calendar.getInstance();
            int h = k.get(Calendar.HOUR), mi = k.get(Calendar.MINUTE);
            return "এখন " + (h == 0 ? 12 : h) + " টা " + mi + " মিনিট।";
        }
        if (has(s, "(তারিখ|আজ কত|what date|\\bdate\\b)")) {
            Calendar k = Calendar.getInstance();
            return "আজ " + k.get(Calendar.DAY_OF_MONTH) + "/" + (k.get(Calendar.MONTH) + 1) + "/" + k.get(Calendar.YEAR);
        }

        // expenses (from SMS and notes, works offline)
        if (has(s, "(কত খরচ|খরচ কত|how much.*spen)")) {
            JSONObject r = Tools.dispatchUser(c, "expense_month", new JSONObject());
            if (!"done".equals(r.optString("status"))) return r.optString("error", "খরচ বের করতে পারলাম না।");
            return "এই মাসে মোট " + r.optLong("grand_total_tk") + " টাকা। আজ এসএমএস থেকে " + r.optLong("sms_today_tk") + " টাকা।";
        }
        Matcher ex = Pattern.compile("(?:খরচ|expense|spent).*?(\\d+)|(\\d+)\\s*(?:টাকা|taka|tk).*?(?:খরচ|লিখ)").matcher(s);
        if (ex.find() && has(s, "(লিখ|নোট|রাখ|add|note|write)")) {
            double amt = Double.parseDouble(ex.group(1) != null ? ex.group(1) : ex.group(2));
            return result(Tools.dispatchUser(c, "expense_note", J.obj("amount", amt, "note", raw)), amt + " টাকা খরচ লিখে রাখলাম।");
        }

        // timer / alarm
        Matcher tm = Pattern.compile("(\\d+)\\s*(মিনিট|minute|min|সেকেন্ড|second|sec|ঘণ্টা|ঘন্টা|hour)").matcher(s);
        if (has(s, "(টাইমার|timer|পর)") && tm.find() && !has(s, "(অ্যালার্ম|alarm|এলার্ম)")) {
            int n = Integer.parseInt(tm.group(1));
            String u = tm.group(2);
            int sec = u.startsWith("সেক") || u.startsWith("sec") ? n : (u.startsWith("ঘ") || u.startsWith("hour") ? n * 3600 : n * 60);
            return result(Tools.dispatchUser(c, "set_alarm_timer", J.obj("type", "timer", "seconds", sec)), "টাইমার সেট করলাম।");
        }
        if (has(s, "(অ্যালার্ম|এলার্ম|alarm)")) {
            Matcher at = Pattern.compile("(\\d{1,2})(?:[:.](\\d{2}))?").matcher(s);
            if (at.find()) {
                int h = Integer.parseInt(at.group(1)), mi = at.group(2) == null ? 0 : Integer.parseInt(at.group(2));
                if (h < 12 && has(s, "(রাত|বিকাল|সন্ধ্যা|দুপুর|\\bpm\\b)")) h += 12;
                if (h == 12 && has(s, "(ভোর|সকাল|\\bam\\b)")) h = 0;
                if (h > 23 || mi > 59) return "সময়টা বুঝতে পারিনি।";
                return result(Tools.dispatchUser(c, "set_alarm_timer", J.obj("type", "alarm", "hour", h, "minute", mi)),
                        "অ্যালার্ম " + h + " টা " + mi + " মিনিটে সেট করলাম।");
            }
            return "কয়টায় অ্যালার্ম দেব?";
        }

        // note
        Matcher nt = Pattern.compile("(?:নোট|note|লিখে রাখো|লিখে রাখ)\\s*(?:লেখো|করো|কর|:)?\\s*(.*)").matcher(raw == null ? "" : raw);
        if (has(s, "(নোট|note|লিখে রাখ)") && nt.find() && nt.group(1).trim().length() > 1) {
            return result(Tools.dispatchUser(c, "note_add", J.obj("text", nt.group(1).trim())), "নোট রাখলাম।");
        }

        // offline control
        if (has(s, "(অফলাইন|offline)") && has(s, "(চালু|on|মোড)") && !has(s, "(বন্ধ|off)")) {
            Prefs.sp(c).edit().putBoolean("force_offline", true).apply();
            return "অফলাইন মোড চালু থাকবে, নেট থাকলেও।";
        }
        if (has(s, "(অনলাইন|online)") || (has(s, "(অফলাইন|offline)") && has(s, "(বন্ধ|off)"))) {
            Prefs.sp(c).edit().putBoolean("force_offline", false).apply();
            return "অফলাইন মোড বন্ধ। নেট থাকলে আবার জেমিনি চলবে।";
        }
        if (has(s, "(ভাষা|language)")) {
            if (has(s, "(ইংরেজি|english)")) { Prefs.sp(c).edit().putString("whisper_lang", "en").apply(); return "ইংরেজি শুনব।"; }
            if (has(s, "(বাংলা|bangla|bengali)")) { Prefs.sp(c).edit().putString("whisper_lang", "bn").apply(); return "বাংলা শুনব।"; }
        }

        // camera: text / QR
        if (has(s, "(qr|কিউআর|বারকোড|barcode)")) return result(Tools.dispatchUser(c, "scan_camera", J.obj("kind", "code")), "ক্যামেরা খুলছি। কোডের ছবি তুলুন।");
        if (has(s, "(স্ক্যান|scan|ছবি থেকে|লেখা পড়|ocr)")) return result(Tools.dispatchUser(c, "scan_camera", J.obj("kind", "text")), "ক্যামেরা খুলছি। লেখার ছবি তুলুন।");
        if (has(s, "(ফলো ?আপ|followup|follow up)") && has(s, "(কী কী|কি কি|list|দেখাও|বাকি)")) {
            JSONObject r = Tools.dispatchUser(c, "followup_list", new JSONObject());
            String t = speakList(r, 5);
            return t == null ? "কোনো ফলো-আপ বাকি নেই।" : "ফলো-আপ: " + t;
        }

        // read things from the phone (all offline)
        if (has(s, "(ক্যালেন্ডার|ইভেন্ট|মিটিং|calendar|schedule|appointment)")) {
            JSONObject r = Tools.dispatchUser(c, "calendar_list", J.obj("days", has(s, "(সপ্তাহ|week)") ? 7 : 2));
            if (!"done".equals(r.optString("status"))) return r.optString("error", "ক্যালেন্ডার পড়তে পারলাম না।");
            String t = speakList(r, 5);
            return t == null ? "কোনো ইভেন্ট নেই।" : "ইভেন্ট: " + t;
        }
        if (has(s, "(মিসড|missed|কে ফোন|who called)")) {
            JSONObject r = Tools.dispatchUser(c, "call_log_recent", J.obj("kind", "missed", "count", 5));
            if (!"done".equals(r.optString("status"))) return r.optString("error", "কল লগ পড়তে পারলাম না।");
            String t = speakList(r, 5);
            return t == null ? "কোনো মিসড কল নেই।" : "মিসড কল: " + t;
        }
        if (has(s, "(পড়ো|read|ওটিপি|otp)") && has(s, "(এসএমএস|মেসেজ|sms|message|ওটিপি|otp)") && !has(s, "(পাঠাও|send)")) {
            JSONObject r = Tools.dispatchUser(c, "read_sms", J.obj("count", 3));
            if (!"done".equals(r.optString("status"))) return r.optString("error", "মেসেজ পড়তে পারলাম না।");
            String t = speakList(r, 3);
            return t == null ? "নতুন মেসেজ নেই।" : t;
        }
        if (has(s, "(নোট|note)") && has(s, "(পড়ো|read|আমার|my|কী কী)")) {
            JSONObject r = Tools.dispatchUser(c, "note_list", J.obj("count", 5));
            String t = speakList(r, 5);
            return t == null ? "কোনো নোট নেই।" : "নোট: " + t;
        }
        if (has(s, "(আমি কোথায়|where am i|আমার লোকেশন)")) {
            JSONObject r = Tools.dispatchUser(c, "where_am_i", new JSONObject());
            if (!"done".equals(r.optString("status"))) return r.optString("error", "লোকেশন পেলাম না।");
            return String.format(Locale.US, "আপনি প্রায় অক্ষাংশ %.4f, দ্রাঘিমাংশ %.4f এ আছেন। নেট ছাড়া জায়গার নাম বলতে পারব না।",
                    r.optDouble("latitude"), r.optDouble("longitude"));
        }
        Matcher sm = Pattern.compile("(?:send\\s+(?:sms|message|text)\\s+to\\s+(\\S+)\\s+(.+))|(?:(\\S+)\\s*কে\\s*(?:এসএমএস|মেসেজ)\\s*(?:পাঠাও|দাও|করো)?\\s*(.+))", Pattern.CASE_INSENSITIVE)
                .matcher(raw.trim());
        if (has(s, "(এসএমএস|মেসেজ|sms|message|text)") && has(s, "(পাঠাও|দাও|send)") && sm.find()) {
            String to = sm.group(1) != null ? sm.group(1) : sm.group(3);
            String body = sm.group(2) != null ? sm.group(2) : sm.group(4);
            if (to != null && body != null && !body.trim().isEmpty())
                return result(Tools.dispatchUser(c, "send_message", J.obj("receiver", to, "message_text", body.trim(), "platform", "sms")),
                        to + " কে এসএমএস পাঠাচ্ছি। স্ক্রিনে অনুমতি দিন।");
        }

        // call
        Matcher cl = Pattern.compile("(?:call\\s+(.+))|(?:(.+?)\\s*কে\\s*(?:একটা\\s*)?(?:কল|ফোন))|(?:(.+?)\\s*(?:কল|ফোন)\\s*(?:দাও|করো|কর))").matcher(raw == null ? "" : raw.trim());
        if (has(s, "(call|কল|ফোন)") && cl.find()) {
            String who = cl.group(1) != null ? cl.group(1) : cl.group(2) != null ? cl.group(2) : cl.group(3);
            who = who == null ? "" : who.replaceAll("(?i)(please|একটু)", "").trim();
            if (!who.isEmpty()) return result(Tools.dispatchUser(c, "make_call", J.obj("receiver", who)), who + " কে কল করছি। স্ক্রিনে অনুমতি দিন।");
        }

        // open app
        Matcher op = Pattern.compile("(?:open\\s+(.+))|(?:(.+?)\\s*(?:খোল|ওপেন|চালু)(?:\\s*করো|\\s*কর|\\s*দাও)?)").matcher(raw == null ? "" : raw.trim());
        if (has(s, "(open|খোল|ওপেন)") && op.find()) {
            String app = op.group(1) != null ? op.group(1) : op.group(2);
            if (app != null && !app.trim().isEmpty())
                return result(Tools.dispatchUser(c, "open_app", J.obj("app_name", app.trim())), app.trim() + " খুলছি।");
        }

        // simple maths
        Matcher mm = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(\\+|plus|প্লাস|যোগ|-|minus|বিয়োগ|\\*|x|times|গুণ|into|/|divided by|ভাগ)\\s*(\\d+(?:\\.\\d+)?)").matcher(s);
        if (mm.find()) {
            double a = Double.parseDouble(mm.group(1)), b = Double.parseDouble(mm.group(3));
            String op2 = mm.group(2);
            double v;
            if (op2.matches("\\+|plus|প্লাস|যোগ")) v = a + b;
            else if (op2.matches("-|minus|বিয়োগ")) v = a - b;
            else if (op2.matches("\\*|x|times|গুণ|into")) v = a * b;
            else { if (b == 0) return "শূন্য দিয়ে ভাগ হয় না।"; v = a / b; }
            return "উত্তর " + (v == Math.rint(v) ? String.valueOf((long) v) : String.format(Locale.US, "%.2f", v));
        }
        return null;
    }
}
