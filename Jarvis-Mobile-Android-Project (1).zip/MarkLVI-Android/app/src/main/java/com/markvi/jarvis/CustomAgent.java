package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Typed-chat brain for any OpenAI-compatible provider (OpenRouter, Groq, DeepSeek, AgentRouter, ...).
 * Same phone tools as the Gemini agent; used when "another API provider" is switched on in Settings.
 */
public final class CustomAgent {
    private CustomAgent() {}

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final List<JSONObject> HISTORY = new ArrayList<>();

    private static final class ToolsRejected extends Exception {
        ToolsRejected(String m) {
            super(m);
        }
    }

    private static volatile long jobTokens;

    public static long lastJobTokens() {
        return jobTokens;
    }

    private static volatile String workingUrl = "";
    private static volatile String workingFor = "";

    /** Cleans what the user typed: quotes, spaces, missing https://, a pasted /chat/completions tail. */
    static String baseOf(Context c) throws Exception {
        String b = Prefs.customBase(c).trim().replace("\"", "").replace("'", "");
        if (b.isEmpty()) throw new Exception("Enter the Base URL of your provider in Settings.");
        if (!b.startsWith("http://") && !b.startsWith("https://")) b = "https://" + b;
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        for (String tail : new String[]{"/chat/completions", "/completions", "/models"}) {
            if (b.endsWith(tail)) b = b.substring(0, b.length() - tail.length());
        }
        while (b.endsWith("/")) b = b.substring(0, b.length() - 1);
        return b;
    }

    /** Usual address first; if the host has no /v1 in it, /v1 is the second guess. */
    static List<String> candidates(Context c) throws Exception {
        String b = baseOf(c);
        List<String> out = new ArrayList<>();
        if (workingFor.equals(b) && !workingUrl.isEmpty()) out.add(workingUrl);
        String u1 = b + "/chat/completions";
        if (!out.contains(u1)) out.add(u1);
        if (!java.util.regex.Pattern.compile("/v\\d").matcher(b.substring(b.indexOf("://") + 3)).find()) {
            String u2 = b + "/v1/chat/completions";
            if (!out.contains(u2)) out.add(u2);
        }
        return out;
    }

    static String modelsUrl(Context c) throws Exception {
        String w = workingUrl;
        String b = baseOf(c);
        if (workingFor.equals(b) && w.endsWith("/chat/completions")) return w.substring(0, w.length() - "/chat/completions".length()) + "/models";
        return b + "/models";
    }

    /** Asks the provider which models it offers (so the user can pick a real name). */
    public static List<String> listModels(Context c) throws Exception {
        if (Prefs.customKey(c).isEmpty()) throw new Exception("Enter the API key first.");
        List<String> urls = new ArrayList<>();
        urls.add(modelsUrl(c));
        String b = baseOf(c);
        if (!urls.contains(b + "/v1/models")) urls.add(b + "/v1/models");
        Exception last = null;
        for (String u : urls) {
            Request req = new Request.Builder().url(u)
                    .header("Authorization", "Bearer " + Prefs.customKey(c)).build();
            try (Response r = GeminiRest.HTTP.newCall(req).execute()) {
                String txt = r.body() == null ? "" : r.body().string();
                if (!r.isSuccessful()) {
                    last = new Exception("HTTP " + r.code());
                    continue;
                }
                JSONObject o = new JSONObject(txt);
                JSONArray d = o.optJSONArray("data");
                if (d == null) d = o.optJSONArray("models");
                List<String> ids = new ArrayList<>();
                for (int i = 0; d != null && i < d.length() && ids.size() < 60; i++) {
                    JSONObject m = d.optJSONObject(i);
                    String id = m == null ? d.optString(i) : m.optString("id", m.optString("name"));
                    if (!id.isEmpty()) ids.add(id);
                }
                if (!ids.isEmpty()) return ids;
                last = new Exception("the provider returned no model list");
            } catch (Exception e) {
                last = e;
            }
        }
        throw last == null ? new Exception("could not list models") : last;
    }

    private static void check(Context c) throws Exception {
        baseOf(c);
        if (Prefs.customKey(c).isEmpty()) throw new Exception("Enter the API key for your provider in Settings.");
        ensureModel(c);
    }

    private static final String[] SKIP = {"embed", "whisper", "tts", "audio", "image", "dall", "moderation", "rerank",
            "realtime", "transcribe", "guard", "sdxl", "flux", "stable", "diffusion", "video", "speech", "imagen", "veo", "ocr"};
    private static final String[] LIKE = {"claude-sonnet", "claude-3-7", "claude-3-5-sonnet", "claude", "gpt-5", "gpt-4.1", "gpt-4o",
            "gemini-2.5-flash", "gemini-3", "gemini", "deepseek-chat", "deepseek-v", "deepseek", "qwen", "llama-3.3-70b", "llama",
            "mistral", "grok", "kimi", "glm", "gpt"};

    /** The best everyday chat model in a provider's list (Claude, GPT, Gemini, DeepSeek ... in that taste order). */
    public static String pickBest(List<String> ids) {
        String best = "";
        int bestScore = Integer.MAX_VALUE;
        for (String id : ids) {
            String low = id.toLowerCase(java.util.Locale.ROOT);
            boolean skip = false;
            for (String k : SKIP) if (low.contains(k)) skip = true;
            if (skip) continue;
            int score = LIKE.length;
            for (int i = 0; i < LIKE.length; i++) {
                if (low.contains(LIKE[i])) {
                    score = i;
                    break;
                }
            }
            if (low.contains("mini") || low.contains("lite") || low.contains("nano")) score += 1; // slightly prefer full models
            if (score < bestScore) {
                bestScore = score;
                best = id;
            }
        }
        if (best.isEmpty() && !ids.isEmpty()) best = ids.get(0);
        return best;
    }

    /** No model typed: ask the provider what it has and take the best one. */
    private static synchronized void ensureModel(Context c) throws Exception {
        if (!Prefs.customModel(c).isEmpty()) return;
        List<String> ids = listModels(c);
        String m = pickBest(ids);
        if (m.isEmpty()) throw new Exception("This provider returned no models.");
        Prefs.sp(c).edit().putString("custom_model", m).putBoolean("custom_model_auto", true).apply();
        DebugLog.add("Provider model chosen automatically: " + m);
    }

    public static String currentModel(Context c) {
        return Prefs.customModel(c);
    }

    public static synchronized void reset() {
        HISTORY.clear();
    }

    /** Gemini-style declarations -> OpenAI "tools" (type names lower-cased). */
    private static JSONArray openAiTools() {
        JSONArray out = new JSONArray();
        JSONArray decls = Tools.declarations();
        for (int i = 0; i < decls.length(); i++) {
            JSONObject d = decls.optJSONObject(i);
            if (d == null) continue;
            JSONObject params = d.optJSONObject("parameters");
            lower(params);
            out.put(J.obj("type", "function", "function", J.obj(
                    "name", d.optString("name"),
                    "description", d.optString("description"),
                    "parameters", params == null ? J.obj("type", "object", "properties", new JSONObject()) : params)));
        }
        return out;
    }

    private static void lower(Object o) {
        try {
            if (o instanceof JSONObject) {
                JSONObject j = (JSONObject) o;
                if (j.has("type") && j.opt("type") instanceof String) {
                    j.put("type", j.getString("type").toLowerCase(java.util.Locale.ROOT));
                }
                java.util.Iterator<String> it = j.keys();
                List<String> keys = new ArrayList<>();
                while (it.hasNext()) keys.add(it.next());
                for (String k : keys) lower(j.opt(k));
            } else if (o instanceof JSONArray) {
                JSONArray a = (JSONArray) o;
                for (int i = 0; i < a.length(); i++) lower(a.opt(i));
            }
        } catch (Exception ignored) {
        }
    }

    public static synchronized String chat(Context c, String userText) throws Exception {
        return chat(c, userText, "", 0);
    }

    public static synchronized String chat(Context c, String userText, String extraSystem, int maxTokens) throws Exception {
        check(c);
        jobTokens = 0;
        int mark = HISTORY.size();
        try {
            return run(c, userText, extraSystem, maxTokens);
        } catch (Exception e) {
            while (HISTORY.size() > mark) HISTORY.remove(HISTORY.size() - 1); // keep the history clean for the next try
            if (Prefs.sp(c).getBoolean("custom_model_auto", false) && String.valueOf(e.getMessage()).toLowerCase(java.util.Locale.ROOT).contains("model")) {
                Prefs.sp(c).edit().putString("custom_model", "").apply(); // the auto pick no longer works: pick again
                ensureModel(c);
                return run(c, userText, extraSystem, maxTokens);
            }
            throw e;
        }
    }

    private static String run(Context c, String userText, String extraSystem, int maxTokens) throws Exception {
        HISTORY.add(J.obj("role", "user", "content", userText));
        String sys = Tools.systemPrompt(c)
                + "\n\n[TEXT CHAT MODE] The user typed this message. Reply in plain text (no markdown), short, in the "
                + "language of their message. Call tools when an action is requested; do not describe doing it."
                + extraSystem;
        JSONArray tools = openAiTools();
        boolean useTools = true;
        boolean streamOff = false; // set when this provider does not stream: we stay on step-by-step updates
        String last = "";

        for (int round = 0; round < (maxTokens > 0 ? 24 : 6); round++) {
            JSONArray msgs = new JSONArray();
            msgs.put(J.obj("role", "system", "content", sys));
            for (JSONObject h : HISTORY) msgs.put(h);
            JSONObject body = J.obj("model", Prefs.customModel(c), "messages", msgs);
            if (useTools) {
                J.put(body, "tools", tools);
            }
            if (maxTokens > 0) J.put(body, "max_tokens", maxTokens);
            JSONObject resp;
            if (maxTokens > 0) SeriousLive.step("think", "Thinking (step " + (round + 1) + ")", "");
            try {
                resp = null;
                if (maxTokens > 0 && !streamOff) {
                    resp = postStream(c, body);
                    if (resp == null) {
                        streamOff = true;
                        DebugLog.add("Provider did not stream; using step-by-step live view.");
                    }
                }
                if (resp == null) resp = post(c, body);
            } catch (ToolsRejected e) {
                if (useTools) {
                    useTools = false; // this provider/model does not support tools: answer in text only
                    DebugLog.add("Provider rejected tools; continuing without actions: " + e.getMessage());
                    round--;
                    continue;
                }
                throw e;
            }
            JSONArray ch = resp.optJSONArray("choices");
            if (ch == null || ch.length() == 0) throw new Exception("The provider returned no answer.");
            JSONObject msg = ch.getJSONObject(0).optJSONObject("message");
            if (msg == null) throw new Exception("The provider returned an empty answer.");

            String text = textOf(msg.opt("content"));
            JSONArray calls = msg.optJSONArray("tool_calls");
            for (int i = 0; calls != null && i < calls.length(); i++) {
                JSONObject tc0 = calls.optJSONObject(i);
                if (tc0 == null) continue;
                if (tc0.optString("id").isEmpty()) J.put(tc0, "id", "call_" + System.currentTimeMillis() + "_" + i);
                if (tc0.optString("type").isEmpty()) J.put(tc0, "type", "function");
                JSONObject f0 = tc0.optJSONObject("function");
                if (f0 != null && f0.opt("arguments") instanceof JSONObject) J.put(f0, "arguments", f0.optJSONObject("arguments").toString());
            }
            JSONObject keep = J.obj("role", "assistant", "content", text);
            if (calls != null && calls.length() > 0) J.put(keep, "tool_calls", calls);
            HISTORY.add(keep);
            if (!text.isEmpty()) last = text.trim();
            if (maxTokens > 0 && !text.isEmpty()) SeriousLive.step("say", "Mira", text.trim());

            if (calls == null || calls.length() == 0) {
                trim();
                return last.isEmpty() ? "Done." : last;
            }
            for (int i = 0; i < calls.length(); i++) {
                JSONObject tc = calls.getJSONObject(i);
                JSONObject fn = tc.optJSONObject("function");
                String name = fn == null ? "" : fn.optString("name");
                JSONObject args;
                try {
                    String raw = fn == null ? "" : fn.optString("arguments", "{}");
                    args = raw.trim().isEmpty() ? new JSONObject() : new JSONObject(raw);
                } catch (Exception e) {
                    args = new JSONObject();
                }
                Bus.log("Tool: " + name);
                if (maxTokens > 0) SeriousLive.step("tool", SeriousLive.describeTool(name, args), "");
                JSONObject r = Tools.dispatchUser(c, name, args);
                if (maxTokens > 0 && "failed".equals(r.optString("status"))) SeriousLive.step("error", name + " failed", r.optString("error", r.toString()));
                String rs = r.toString();
                if (rs.length() > 16000) rs = rs.substring(0, 16000) + "...[truncated]"; // keeps one huge tool result from inflating every later step's tokens
                HISTORY.add(J.obj("role", "tool", "tool_call_id", tc.optString("id"), "content", rs));
            }
        }
        trim();
        return last.isEmpty() ? "I ran several steps; check the phone to see where things stand." : last;
    }

    /** One plain question, no tools (used for the HUD's quick-ask features and the Test button). */
    public static String simple(Context c, String prompt) throws Exception {
        check(c);
        JSONObject body = J.obj("model", Prefs.customModel(c),
                "messages", J.arr(J.obj("role", "user", "content", prompt)));
        JSONObject resp = post(c, body);
        JSONArray ch = resp.optJSONArray("choices");
        if (ch == null || ch.length() == 0) throw new Exception("The provider returned no answer.");
        JSONObject msg = ch.getJSONObject(0).optJSONObject("message");
        return msg == null ? "" : textOf(msg.opt("content")).trim();
    }

    private static String textOf(Object content) {
        if (content == null || content == JSONObject.NULL) return "";
        if (content instanceof String) return (String) content;
        if (content instanceof JSONArray) {
            StringBuilder sb = new StringBuilder();
            JSONArray a = (JSONArray) content;
            for (int i = 0; i < a.length(); i++) {
                JSONObject p = a.optJSONObject(i);
                if (p != null) sb.append(p.optString("text"));
            }
            return sb.toString();
        }
        return String.valueOf(content);
    }

    private static void trim() {
        while (HISTORY.size() > 30) HISTORY.remove(0);
        while (!HISTORY.isEmpty() && !"user".equals(HISTORY.get(0).optString("role"))) HISTORY.remove(0);
    }

    /**
     * Same request as post() but with stream=true: the answer is read as it arrives and the text / file being written
     * is shown live in the HUD. Returns the finished answer in the normal (non-stream) shape, or null when this
     * provider cannot stream or anything goes wrong, so the caller falls back to post().
     */
    private static JSONObject postStream(Context c, JSONObject body0) {
        try {
            JSONObject body = new JSONObject(body0.toString());
            J.put(body, "stream", true);
            List<String> urls = new ArrayList<>();
            String base = baseOf(c);
            if (workingUrl != null && base.equals(workingFor)) urls.add(workingUrl);
            else urls.addAll(candidates(c));
            for (String url : urls) {
                Request req = new Request.Builder().url(url)
                        .header("Authorization", "Bearer " + Prefs.customKey(c))
                        .header("Content-Type", "application/json")
                        .header("Accept", "text/event-stream")
                        .header("HTTP-Referer", "https://mira.app")
                        .header("X-Title", "Mira")
                        .post(RequestBody.create(body.toString(), JSON)).build();
                try (Response r = GeminiRest.HTTP.newBuilder().readTimeout(120, TimeUnit.SECONDS).build().newCall(req).execute()) {
                    if (!r.isSuccessful() || r.body() == null) {
                        if (r.code() == 404 || r.code() == 405) continue;
                        return null;
                    }
                    String ct = String.valueOf(r.header("Content-Type", "")).toLowerCase(java.util.Locale.ROOT);
                    if (!ct.contains("event-stream")) return null; // the provider ignored stream=true
                    JSONObject out = readStream(new java.io.BufferedReader(new java.io.InputStreamReader(r.body().byteStream(), "UTF-8")));
                    if (out != null) {
                        workingUrl = url;
                        workingFor = base;
                    }
                    return out;
                }
            }
        } catch (Throwable t) {
            DebugLog.add("Streaming failed: " + t.getMessage());
        }
        return null;
    }

    private static JSONObject readStream(java.io.BufferedReader src) throws Exception {
        StringBuilder text = new StringBuilder();
        java.util.TreeMap<Integer, String[]> calls = new java.util.TreeMap<>(); // index -> {id, name, arguments}
        StringBuilder[] args = new StringBuilder[64];
        long lastPush = 0;
        boolean gotAny = false;
        String line;
        while ((line = src.readLine()) != null) {
            line = line.trim();
            if (!line.startsWith("data:")) continue;
            String d = line.substring(5).trim();
            if (d.equals("[DONE]")) break;
            JSONObject j;
            try {
                j = new JSONObject(d);
            } catch (Exception e) {
                continue;
            }
            if (j.has("error") && !j.has("choices")) throw new Exception("stream error");
            JSONObject us = j.optJSONObject("usage");
            if (us != null) jobTokens += us.optLong("total_tokens", us.optLong("prompt_tokens") + us.optLong("completion_tokens"));
            JSONArray ch = j.optJSONArray("choices");
            if (ch == null || ch.length() == 0) continue;
            JSONObject delta = ch.getJSONObject(0).optJSONObject("delta");
            if (delta == null) continue;
            gotAny = true;
            String cd = delta.optString("content", "");
            if (!cd.isEmpty() && !delta.isNull("content")) text.append(cd);
            JSONArray tcs = delta.optJSONArray("tool_calls");
            for (int i = 0; tcs != null && i < tcs.length(); i++) {
                JSONObject t = tcs.getJSONObject(i);
                int idx;
                if (t.has("index")) idx = t.optInt("index");
                else {
                    // some providers leave the index out: a new id means a new call, no id means the same call continues
                    String tid = t.optString("id");
                    idx = calls.isEmpty() ? 0 : calls.lastKey();
                    if (!tid.isEmpty()) {
                        boolean known = false;
                        for (java.util.Map.Entry<Integer, String[]> en : calls.entrySet()) if (en.getValue()[0].equals(tid)) { idx = en.getKey(); known = true; }
                        if (!known && !calls.isEmpty()) idx = calls.lastKey() + 1;
                    }
                }
                if (idx < 0 || idx >= args.length) continue;
                String[] e = calls.get(idx);
                if (e == null) {
                    e = new String[]{"", "", ""};
                    calls.put(idx, e);
                    args[idx] = new StringBuilder();
                }
                if (!t.optString("id").isEmpty()) e[0] = t.optString("id");
                JSONObject f = t.optJSONObject("function");
                if (f != null) {
                    if (!f.optString("name").isEmpty() && !e[1].equals(f.optString("name"))) e[1] = e[1] + f.optString("name");
                    if (!f.isNull("arguments")) args[idx].append(f.optString("arguments", ""));
                }
            }
            long now = System.currentTimeMillis();
            if (now - lastPush > 250) {
                lastPush = now;
                pushLive(text, calls, args);
            }
        }
        if (!gotAny) return null;
        pushLive(text, calls, args);
        JSONObject msg = J.obj("role", "assistant", "content", text.toString());
        if (!calls.isEmpty()) {
            JSONArray arr = new JSONArray();
            for (java.util.Map.Entry<Integer, String[]> en : calls.entrySet()) {
                String[] e = en.getValue();
                arr.put(J.obj("id", e[0], "type", "function",
                        "function", J.obj("name", e[1], "arguments", args[en.getKey()].length() == 0 ? "{}" : args[en.getKey()].toString())));
            }
            J.put(msg, "tool_calls", arr);
        }
        return J.obj("choices", new JSONArray().put(J.obj("message", msg)));
    }

    /** Shows what the AI is writing right now: the file text being saved, or its plain words. */
    private static void pushLive(StringBuilder text, java.util.TreeMap<Integer, String[]> calls, StringBuilder[] args) {
        for (java.util.Map.Entry<Integer, String[]> en : calls.entrySet()) {
            String name = en.getValue()[1];
            String a = args[en.getKey()].toString();
            String key = "save_file".equals(name) ? "content" : "edit_file".equals(name) ? "replace" : "make_excel".equals(name) ? "csv" : null;
            if (key == null) continue;
            String body = SeriousLive.partialJsonString(a, key);
            if (body == null) continue;
            String fn = "save_file".equals(name) || "make_excel".equals(name) ? SeriousLive.partialJsonString(a, "filename") : null;
            SeriousLive.code((fn == null || fn.isEmpty() ? name : fn), body);
            return;
        }
        if (text.length() > 0) SeriousLive.code("Mira", text.toString());
    }

    private static JSONObject post(Context c, JSONObject body) throws Exception {
        List<String> urls = candidates(c);
        String base = baseOf(c);
        Exception last = null;
        for (String url : urls) {
            for (int attempt = 0; attempt < 3; attempt++) {
                Request req = new Request.Builder()
                        .url(url)
                        .header("Authorization", "Bearer " + Prefs.customKey(c))
                        .header("Content-Type", "application/json")
                        .header("HTTP-Referer", "https://mira.app")
                        .header("X-Title", "Mira")
                        .post(RequestBody.create(body.toString(), JSON))
                        .build();
                try (Response r = GeminiRest.HTTP.newBuilder().readTimeout(90, TimeUnit.SECONDS).build().newCall(req).execute()) {
                    String txt = r.body() == null ? "" : r.body().string();
                    if (r.isSuccessful()) {
                        JSONObject o;
                        try {
                            o = new JSONObject(txt);
                        } catch (Exception e) {
                            last = new Exception("The provider did not return JSON. Check the Base URL (usually it ends with /v1). Got: "
                                    + GeminiRest.abbreviate(txt, 120));
                            break; // try the next address
                        }
                        if (o.has("error") && !o.has("choices")) {
                            JSONObject er = o.optJSONObject("error");
                            throw new Exception("Provider error: " + GeminiRest.abbreviate(er != null ? er.optString("message", er.toString()) : o.optString("error"), 160));
                        }
                        JSONObject us = o.optJSONObject("usage");
                        if (us != null) jobTokens += us.optLong("total_tokens", us.optLong("prompt_tokens") + us.optLong("completion_tokens"));
                        workingUrl = url;
                        workingFor = base;
                        return o;
                    }
                    String low = txt.toLowerCase(java.util.Locale.ROOT);
                    if (r.code() == 400 && low.contains("max_tokens") && body.has("max_tokens")) {
                        int lim = body.optInt("max_tokens", 4000); // newer models want max_completion_tokens instead
                        body.remove("max_tokens");
                        J.put(body, "max_completion_tokens", lim);
                        attempt--;
                        continue;
                    }
                    if (r.code() == 400 && low.contains("max_completion_tokens") && body.has("max_completion_tokens")) {
                        body.remove("max_completion_tokens"); // this provider takes neither: let it use its own limit
                        attempt--;
                        continue;
                    }
                    if (r.code() == 400 && body.has("tools") && (low.contains("tool") || low.contains("function"))) {
                        throw new ToolsRejected(GeminiRest.abbreviate(txt, 120));
                    }
                    if (r.code() == 404 || r.code() == 405) {
                        last = new Exception("Provider error " + r.code() + " (check the Base URL and model name): " + GeminiRest.abbreviate(txt, 120));
                        break; // wrong address: try the next candidate
                    }
                    if (r.code() == 429 || r.code() >= 500) {
                        last = new Exception("Provider error " + r.code() + (r.code() == 429 ? " (rate limit or no credit)" : " (provider is busy)")
                                + ": " + GeminiRest.abbreviate(txt, 120));
                        Thread.sleep(900L * (attempt + 1));
                        continue; // retry the same address
                    }
                    String hint = r.code() == 401 || r.code() == 403 ? " (the API key is wrong or not allowed)" : "";
                    throw new Exception("Provider error " + r.code() + hint + ": " + GeminiRest.abbreviate(txt, 160));
                } catch (java.io.IOException io) {
                    last = new Exception("Network problem: " + io.getMessage());
                    Thread.sleep(700L * (attempt + 1));
                }
            }
        }
        throw last != null ? last : new Exception("no answer from the provider");
    }
}
