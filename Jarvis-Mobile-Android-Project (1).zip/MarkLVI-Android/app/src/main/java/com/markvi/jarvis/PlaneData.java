package com.markvi.jarvis;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.zip.GZIPInputStream;

/**
 * Offline aircraft + airport data bundled in the app.
 * aircraft_db.txt.gz : tar1090-db (hex|registration|type code|model|owner), public data from the Mictronics database.
 * airports_db.txt.gz : OurAirports (public domain): icao|iata|name|city|country|lat|lon|size.
 * The aircraft file is unpacked once into the app's private folder and searched by hex with a binary search.
 */
final class PlaneData {
    private PlaneData() {}

    private static final String VER = "1";
    private static File acFile;
    private static String airportsJson;

    private static synchronized File aircraftFile(Context c) {
        if (acFile != null) return acFile;
        try {
            File dir = new File(c.getFilesDir(), "planedata");
            dir.mkdirs();
            File f = new File(dir, "aircraft_" + VER + ".txt");
            if (!f.exists() || f.length() < 1000000) {
                File tmp = new File(dir, "aircraft.tmp");
                try (InputStream in = new GZIPInputStream(c.getAssets().open("aircraft_db.txt.gz"), 65536);
                     FileOutputStream out = new FileOutputStream(tmp)) {
                    byte[] b = new byte[65536];
                    int n;
                    while ((n = in.read(b)) > 0) out.write(b, 0, n);
                }
                if (!tmp.renameTo(f)) return null;
            }
            acFile = f;
        } catch (Throwable t) {
            DebugLog.add("Aircraft database unavailable: " + t);
        }
        return acFile;
    }

    /** {reg,type,model,owner} for a 6-digit hex, or null when the database has no entry. */
    static JSONObject aircraft(Context c, String hex) {
        if (hex == null) return null;
        hex = hex.trim().toUpperCase(java.util.Locale.ROOT);
        if (!hex.matches("[0-9A-F]{6}")) return null;
        File f = aircraftFile(c);
        if (f == null) return null;
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            long lo = 0, hi = r.length();
            while (lo < hi) {
                long mid = (lo + hi) / 2;
                r.seek(mid > 0 ? mid - 1 : 0);
                if (mid > 0) r.readLine(); // move to the first line that starts at or after mid
                long pos = r.getFilePointer();
                String line = pos >= hi ? null : readUtf8Line(r);
                if (line == null) {
                    hi = mid;
                    continue;
                }
                int cmp = line.substring(0, Math.min(6, line.length())).compareTo(hex);
                if (cmp == 0) {
                    String[] p = line.split("\\|", -1);
                    JSONObject o = new JSONObject();
                    o.put("hex", hex);
                    o.put("reg", p.length > 1 ? p[1] : "");
                    o.put("type", p.length > 2 ? p[2] : "");
                    o.put("model", p.length > 3 ? p[3] : "");
                    o.put("owner", p.length > 4 ? p[4] : "");
                    return o;
                }
                if (cmp < 0) lo = r.getFilePointer();
                else hi = mid;
            }
        } catch (Throwable t) {
            DebugLog.add("Aircraft lookup failed: " + t);
        }
        return null;
    }

    private static String readUtf8Line(RandomAccessFile r) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        int ch;
        boolean any = false;
        while ((ch = r.read()) >= 0) {
            any = true;
            if (ch == '\n') break;
            bo.write(ch);
        }
        return any ? bo.toString("UTF-8") : null;
    }

    /** All bundled airports as JSON: [[name, iata, icao, lat, lng, size, country, city], ...] (size l/m/s). */
    static synchronized String airports(Context c) {
        if (airportsJson != null) return airportsJson;
        JSONArray out = new JSONArray();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new GZIPInputStream(c.getAssets().open("airports_db.txt.gz")), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\|", -1);
                if (p.length < 8) continue;
                JSONArray a = new JSONArray();
                a.put(p[2]).put(p[1]).put(p[0]).put(Double.parseDouble(p[5])).put(Double.parseDouble(p[6])).put(p[7]).put(p[4]).put(p[3]);
                out.put(a);
            }
        } catch (Throwable t) {
            DebugLog.add("Airport database unavailable: " + t);
            return "[]";
        }
        airportsJson = out.toString();
        return airportsJson;
    }
}
