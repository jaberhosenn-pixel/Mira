package com.markvi.jarvis;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Alarm and notification-button entry point for MiraTasks. */
public class TaskReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        final Context app = c.getApplicationContext();
        final int id = i.getIntExtra("id", 0);
        String act = i.getAction() == null ? "" : i.getAction();
        if (act.equals(MiraTasks.ACT_DONE)) {
            MiraTasks.done(app, id);
            return;
        }
        if (act.equals(MiraTasks.ACT_SNOOZE)) {
            MiraTasks.snooze(app, id, Math.max(1, i.getIntExtra("snooze_min", 10)));
            return;
        }
        final android.os.PowerManager.WakeLock wl = ((android.os.PowerManager) app.getSystemService(Context.POWER_SERVICE))
                .newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "mira:task");
        wl.acquire(90000L);
        new Thread(() -> {
            try {
                MiraTasks.execute(app, id, false);
            } catch (Throwable t) {
                DebugLog.add("Scheduled task crashed: " + t);
            } finally {
                if (wl.isHeld()) wl.release();
            }
        }, "mira-task").start();
    }
}
