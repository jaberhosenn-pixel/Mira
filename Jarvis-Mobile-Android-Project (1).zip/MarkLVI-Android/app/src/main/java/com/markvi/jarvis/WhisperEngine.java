package com.markvi.jarvis;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;

/** Offline speech to text with a Whisper model file the user downloaded. Bengali and English, no internet. */
final class WhisperEngine {
    private WhisperEngine() {}

    private static long ctx;
    private static volatile boolean cancel;
    static final String PROMPT = "টর্চ জ্বালাও, ভলিউম বাড়াও, রহিমকে কল দাও, ওয়াইফাই, ব্লুটুথ, অ্যালার্ম, টাইমার, নোট লেখো, ব্যাটারি কত, খরচ কত।";

    /** App copy first, then Downloads. Prefers multilingual base/small (a .en model cannot hear Bengali). */
    static File findModel(Context c) {
        File own = new File(c.getFilesDir(), "whisper.bin");
        if (own.isFile() && own.length() > 10_000_000) return own;
        File best = null;
        int bestScore = -1;
        for (File dir : new File[]{Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                new File("/sdcard/Download")}) {
            File[] fs = dir == null ? null : dir.listFiles();
            if (fs == null) continue;
            for (File f : fs) {
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (!n.startsWith("ggml-") || !n.contains(".bin") || n.contains(".en") || f.length() < 10_000_000) continue;
                int sc = n.contains("small") ? 3 : n.contains("base") ? 2 : n.contains("tiny") ? 1 : 0;
                if (n.contains("q5") || n.contains("q8")) sc += 0; // any quantisation is fine
                if (sc > bestScore) { bestScore = sc; best = f; }
            }
        }
        return best;
    }

    static boolean ready(Context c) {
        return WhisperLib.loaded && findModel(c) != null;
    }

    /** Copies the model into the app's private storage so it keeps working even if Downloads is cleaned. */
    static String importModel(Context c) {
        File m = findModel(c);
        if (m == null) return "Whisper model not found in Downloads (name must start with ggml- and not contain .en).";
        File own = new File(c.getFilesDir(), "whisper.bin");
        if (m.equals(own)) return "Whisper model is ready (" + own.length() / 1048576 + " MB).";
        try (InputStream in = new FileInputStream(m); OutputStream out = new FileOutputStream(own)) {
            byte[] b = new byte[1 << 16];
            int n;
            while ((n = in.read(b)) > 0) out.write(b, 0, n);
            return "Whisper model copied: " + m.getName() + " (" + own.length() / 1048576 + " MB).";
        } catch (Exception e) {
            own.delete();
            return "Could not copy the model: " + e.getMessage();
        }
    }

    private static synchronized boolean load(Context c) {
        if (ctx != 0) return true;
        File m = findModel(c);
        if (m == null || !WhisperLib.loaded) return false;
        long t0 = System.currentTimeMillis();
        try {
            ctx = WhisperLib.nativeInit(m.getAbsolutePath());
        } catch (Throwable t) {
            DebugLog.add("Whisper init crashed: " + t);
            ctx = 0;
        }
        Bus.log("Whisper: model " + m.getName() + (ctx != 0 ? " loaded in " + (System.currentTimeMillis() - t0) + " ms" : " FAILED to load"));
        return ctx != 0;
    }

    static synchronized void release() {
        cancel = true;
        if (ctx != 0) {
            try { WhisperLib.nativeFree(ctx); } catch (Throwable ignored) { }
            ctx = 0;
        }
    }

    static void cancel() { cancel = true; }

    /** Transcribes ready made 16 kHz audio (used by the offline wake word). Null when Whisper is unavailable. */
    static String transcribe(Context c, float[] audio, String lang, String prompt) {
        if (!load(c)) return null;
        try {
            synchronized (WhisperEngine.class) {
                if (ctx == 0) return null;
                return WhisperLib.nativeTranscribe(ctx, Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors() / 2)), audio, lang, prompt);
            }
        } catch (Throwable t) {
            DebugLog.add("Whisper transcribe crashed: " + t);
            return null;
        }
    }

    /**
     * Listens until the user stops talking, then transcribes. Blocking: call from a worker thread.
     * Returns "" when nothing was said, null when Whisper itself failed (caller falls back to the phone recogniser).
     */
    static String heardOnce(Context c, String lang) {
        cancel = false;
        if (!load(c)) return null;
        float[] audio = record();
        if (cancel) return "";
        if (audio == null) return null;
        if (audio.length < 8000) return ""; // under half a second
        long t0 = System.currentTimeMillis();
        String out;
        try {
            synchronized (WhisperEngine.class) {
                if (ctx == 0) return "";
                out = WhisperLib.nativeTranscribe(ctx, Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors() / 2)), audio, lang, PROMPT);
            }
        } catch (Throwable t) {
            DebugLog.add("Whisper transcribe crashed: " + t);
            return null;
        }
        if (out == null) return null;
        out = out.trim();
        Bus.log("Whisper heard (" + (System.currentTimeMillis() - t0) + " ms): " + out);
        // Whisper hallucinates these on silence/noise
        String lo = out.toLowerCase(Locale.ROOT);
        if (lo.matches("^[\\[(].*[\\])]$") || lo.equals("you") || lo.equals("thank you.") || lo.equals("thanks for watching!")) return "";
        return out;
    }

    /** 16 kHz mono PCM with a simple energy based start/stop detector. */
    private static float[] record() {
        final int rate = 16000;
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) return null;
        AudioRecord ar = null;
        try {
            ar = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate));
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) return null;
            ar.startRecording();
            short[] buf = new short[rate / 10]; // 100 ms
            float[] all = new float[rate * 12];
            int len = 0;
            double noise = 0;
            int calib = 0;
            boolean speaking = false;
            int quiet = 0, waited = 0;
            while (!cancel) {
                int n = ar.read(buf, 0, buf.length);
                if (n <= 0) return null;
                double sum = 0;
                for (int i = 0; i < n; i++) sum += buf[i] * (double) buf[i];
                double rms = Math.sqrt(sum / n);
                if (calib < 3) { noise = Math.max(noise, rms); calib++; continue; }
                double thr = Math.max(500, noise * 2.5);
                boolean loud = rms > thr;
                if (!speaking) {
                    waited++;
                    if (loud) speaking = true;
                    else if (waited > 70) return new float[0]; // 7 s of nothing
                    else continue;
                }
                for (int i = 0; i < n && len < all.length; i++) all[len++] = buf[i] / 32768f;
                quiet = loud ? 0 : quiet + 1;
                if (quiet >= 9 || len >= all.length) break; // 0.9 s of silence ends it
            }
            float[] out = new float[len];
            System.arraycopy(all, 0, out, 0, len);
            return out;
        } catch (Throwable t) {
            DebugLog.add("Whisper record failed: " + t);
            return null;
        } finally {
            try { if (ar != null) { ar.stop(); ar.release(); } } catch (Throwable ignored) { }
        }
    }
}
