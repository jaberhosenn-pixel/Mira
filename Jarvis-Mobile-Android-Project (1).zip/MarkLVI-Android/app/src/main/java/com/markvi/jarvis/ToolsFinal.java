package com.markvi.jarvis;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.telephony.SmsManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/**
 * Final-version extras, all additive: routines, notes, lead CRM, reply templates, invoices, photo search,
 * PIN protection, activity log, emergency alert, conversation styles.
 */
public final class ToolsFinal {
    private ToolsFinal() {}

    // ------------------------------------------------------------------ small storage helpers

    private static JSONArray load(Context c, String key) {
        try {
            return new JSONArray(Prefs.sp(c).getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static void save(Context c, String key, JSONArray a) {
        Prefs.sp(c).edit().putString(key, a.toString()).apply();
    }

    private static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    // ------------------------------------------------------------------ PIN guard and activity log

    /** Tools that act on other people or install things. They need the PIN when one is set. */
    private static final Set<String> SENSITIVE = new HashSet<>(Arrays.asList(
            "send_message", "make_call", "send_email_batch", "install_app", "ui_flow", "screen_agent", "restore_data", "reply_notification"));

    private static String hash(String salt, String pin) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] d = md.digest((salt + ":" + pin).getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format(Locale.US, "%02x", b));
        return sb.toString();
    }

    static boolean pinSet(Context c) {
        return !Prefs.sp(c).getString("pin_hash", "").isEmpty();
    }

    private static boolean pinOk(Context c, String pin) {
        try {
            String salt = Prefs.sp(c).getString("pin_salt", "");
            return pin != null && hash(salt, pin.trim()).equals(Prefs.sp(c).getString("pin_hash", ""));
        } catch (Exception e) {
            return false;
        }
    }

    /** Returns a failure to hand back to the model when the tool is locked, else null. Only for model-driven calls. */
    static JSONObject guard(Context c, String name) {
        try {
            if (!SENSITIVE.contains(name) || !pinSet(c)) return null;
            if (System.currentTimeMillis() < Prefs.sp(c).getLong("pin_until", 0)) return null;
            return J.fail("PIN protection is ON. Ask the user to say their PIN, call unlock_pin with it, then repeat this action.");
        } catch (Throwable t) {
            return null;
        }
    }

    /** Remembers the last tool calls so the user can see what Mira did. Never stores PINs. */
    static void log(Context c, String name, JSONObject args, JSONObject result) {
        try {
            if ("activity_log".equals(name) || "unlock_pin".equals(name) || "set_pin".equals(name) || "clear_pin".equals(name)) return;
            JSONArray a = load(c, "act_log");
            String brief = args == null ? "" : args.toString();
            if (brief.length() > 90) brief = brief.substring(0, 90) + "...";
            boolean ok = result != null && !"failed".equals(result.optString("status"));
            a.put(J.obj("t", System.currentTimeMillis(), "tool", name, "ok", ok, "args", brief));
            while (a.length() > 150) a.remove(0);
            save(c, "act_log", a);
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ routines (daily repeating reminders)

    private static long nextTrigger(String hhmm) {
        String[] p = hhmm.trim().split(":");
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(p[0].trim()));
        cal.set(Calendar.MINUTE, p.length > 1 ? Integer.parseInt(p[1].trim()) : 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() < System.currentTimeMillis() + 30000L) cal.add(Calendar.DAY_OF_YEAR, 1);
        return cal.getTimeInMillis();
    }

    static void scheduleRoutine(Context c, int id, String hhmm, String text) {
        try {
            long when = nextTrigger(hhmm);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            Intent i = new Intent(c, ReminderReceiver.class).putExtra("id", id).putExtra("msg", text)
                    .putExtra("routine_time", hhmm).putExtra("title", "Routine");
            PendingIntent pi = PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
                }
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (Throwable t) {
            DebugLog.add("Routine schedule failed: " + t);
        }
    }

    static void rearmRoutines(Context c) {
        JSONArray a = load(c, "routines");
        for (int i = 0; i < a.length(); i++) {
            JSONObject r = a.optJSONObject(i);
            if (r != null) scheduleRoutine(c, r.optInt("id"), r.optString("time"), r.optString("text"));
        }
    }

    // ------------------------------------------------------------------ prompt additions (style, translate, PIN)

    static String promptExtras(Context c) {
        StringBuilder sb = new StringBuilder();
        String style = Prefs.sp(c).getString("style", "normal");
        if ("friend".equals(style) && !SeriousMode.active(c)) {
            sb.append("[STYLE: FRIEND] Talk like a warm, close friend: relaxed, light humour, short sentences, caring. Still do every task correctly.\n");
        }
        String tr = Prefs.sp(c).getString("translate", "");
        if (!tr.isEmpty() && tr.contains("|")) {
            String[] p = tr.split("\\|");
            sb.append("[INTERPRETER MODE] Two people are talking through you. Whenever you hear ").append(p[0])
                    .append(", say it aloud in ").append(p[1]).append("; whenever you hear ").append(p[1])
                    .append(", say it aloud in ").append(p[0])
                    .append(". Say ONLY the translation, no comments, until the user says to stop interpreting.\n");
        }
        if (Prefs.sp(c).getBoolean("driving", false)) {
            sb.append("[DRIVING MODE] The user is driving. Answer in one or two short sentences, no lists, never ask them to look at or touch the screen. "
                    + "Read incoming messages briefly; before replying, say the reply back and wait for a yes unless they dictated it word for word.\n");
        }
        if (pinSet(c)) {
            sb.append("[PIN PROTECTION] A PIN is set. Before send_message, make_call, send_email_batch, install_app, ui_flow, screen_agent or restore_data, "
                    + "if a tool says the PIN is required, ask the user to say the PIN and call unlock_pin. Never reveal or guess the PIN.\n");
        }
        if (sb.length() == 0) return "";
        return "\n" + sb.toString().trim() + "\n";
    }

    // ------------------------------------------------------------------ registration

    static void register() {
        // ---- activity log + PIN + emergency
        reg("activity_log",
                "Shows what Mira did recently (the last tool calls with time and result). Use when the user asks what you did or whether something was sent.",
                schema("", "count:INTEGER:how many entries, default 15"),
                (c, a) -> {
                    JSONArray all = load(c, "act_log");
                    int n = Math.max(1, Math.min(60, a.optInt("count", 15)));
                    StringBuilder sb = new StringBuilder();
                    SimpleDateFormat f = new SimpleDateFormat("d MMM HH:mm", Locale.US);
                    for (int i = all.length() - 1; i >= 0 && n > 0; i--, n--) {
                        JSONObject e = all.optJSONObject(i);
                        if (e == null) continue;
                        sb.append(f.format(new Date(e.optLong("t")))).append("  ").append(e.optString("tool"))
                                .append(e.optBoolean("ok") ? "  ok" : "  FAILED").append("  ").append(e.optString("args")).append('\n');
                    }
                    return J.ok("log", sb.length() == 0 ? "nothing recorded yet" : sb.toString().trim());
                });

        reg("set_pin",
                "Turns on PIN protection (4-8 digits). After this, sending messages, calls, installs and screen automation need the PIN spoken first. "
                        + "If a PIN already exists, old_pin is required.",
                schema("pin", "pin:STRING:new PIN, digits only", "old_pin:STRING:current PIN if one exists"),
                (c, a) -> {
                    String pin = a.optString("pin").trim();
                    if (!pin.matches("\\d{4,8}")) return J.fail("the PIN must be 4 to 8 digits");
                    if (pinSet(c) && !pinOk(c, a.optString("old_pin"))) return J.fail("the old PIN is wrong");
                    String salt = Long.toHexString(System.nanoTime());
                    Prefs.sp(c).edit().putString("pin_salt", salt).putString("pin_hash", hash(salt, pin))
                            .putLong("pin_until", 0).apply();
                    return J.ok("note", "PIN protection is on");
                });

        reg("unlock_pin",
                "Unlocks the protected actions for 10 minutes when the user says the correct PIN.",
                schema("pin", "pin:STRING:the PIN the user said, digits only"),
                (c, a) -> {
                    if (!pinSet(c)) return J.ok("note", "no PIN is set");
                    if (!pinOk(c, a.optString("pin").replaceAll("\\D", ""))) return J.fail("wrong PIN");
                    Prefs.sp(c).edit().putLong("pin_until", System.currentTimeMillis() + 10 * 60 * 1000L).apply();
                    return J.ok("note", "unlocked for 10 minutes");
                });

        reg("clear_pin",
                "Turns PIN protection off. Needs the current PIN.",
                schema("pin", "pin:STRING:current PIN"),
                (c, a) -> {
                    if (!pinSet(c)) return J.ok("note", "no PIN was set");
                    if (!pinOk(c, a.optString("pin").replaceAll("\\D", ""))) return J.fail("wrong PIN");
                    Prefs.sp(c).edit().remove("pin_hash").remove("pin_salt").remove("pin_until").apply();
                    return J.ok("note", "PIN protection is off");
                });

        reg("set_emergency_contacts",
                "Saves the people who get an SMS with the user's location when emergency_alert is used. Names or numbers, comma separated.",
                schema("contacts", "contacts:STRING:comma separated names or phone numbers"),
                (c, a) -> {
                    JSONArray out = new JSONArray();
                    StringBuilder bad = new StringBuilder();
                    for (String s : a.optString("contacts").split(",")) {
                        s = s.trim();
                        if (s.isEmpty()) continue;
                        String num = Util.resolveNumber(c, s);
                        if (num == null) bad.append(s).append("; ");
                        else out.put(num);
                    }
                    if (out.length() == 0) return J.fail("could not find any of those contacts" + (bad.length() > 0 ? ": " + bad : ""));
                    save(c, "emergency", out);
                    return J.ok("saved", out.length(), "not_found", bad.toString());
                });

        reg("emergency_alert",
                "EMERGENCY: sends an SMS with the user's live location link to the saved emergency contacts. Use only when the user says it is an emergency or asks for help to be sent.",
                schema(""),
                (c, a) -> emergency(c));

        // ---- routines
        reg("routine_add",
                "Creates a routine that repeats EVERY day at a time and announces the text (example: 08:00 'read my plan for today'). time is 24h HH:mm.",
                schema("time,text", "time:STRING:24h time like 08:00", "text:STRING:what to say or do"),
                (c, a) -> {
                    String time = a.optString("time").trim();
                    if (!time.matches("\\d{1,2}:\\d{2}")) return J.fail("time must look like 08:00");
                    int id = 1000000000 + (int) (System.currentTimeMillis() % 900000000L);
                    JSONArray all = load(c, "routines");
                    all.put(J.obj("id", id, "time", time, "text", a.optString("text")));
                    save(c, "routines", all);
                    scheduleRoutine(c, id, time, a.optString("text"));
                    return J.ok("id", id, "every_day_at", time);
                });

        reg("routine_list",
                "Lists the daily routines.",
                schema(""),
                (c, a) -> J.ok("routines", load(c, "routines")));

        reg("routine_remove",
                "Deletes a daily routine by id or by a word from its text.",
                schema("which", "which:STRING:id or part of the text"),
                (c, a) -> {
                    String w = a.optString("which").toLowerCase(Locale.ROOT).trim();
                    JSONArray all = load(c, "routines"), keep = new JSONArray();
                    int removed = 0;
                    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
                    for (int i = 0; i < all.length(); i++) {
                        JSONObject r = all.optJSONObject(i);
                        if (r == null) continue;
                        if (!w.isEmpty() && (String.valueOf(r.optInt("id")).equals(w) || r.optString("text").toLowerCase(Locale.ROOT).contains(w))) {
                            Intent in = new Intent(c, ReminderReceiver.class);
                            PendingIntent pi = PendingIntent.getBroadcast(c, r.optInt("id"), in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                            am.cancel(pi);
                            removed++;
                        } else {
                            keep.put(r);
                        }
                    }
                    save(c, "routines", keep);
                    return removed > 0 ? J.ok("removed", removed) : J.fail("no routine matched");
                });

        // ---- notes
        reg("note_add",
                "Saves a quick note the user dictates (an idea, a to-do, a phone number...).",
                schema("text", "text:STRING:the note"),
                (c, a) -> {
                    JSONArray all = load(c, "notes");
                    all.put(J.obj("t", System.currentTimeMillis(), "text", a.optString("text")));
                    while (all.length() > 300) all.remove(0);
                    save(c, "notes", all);
                    return J.ok("saved", all.length());
                });

        reg("note_list",
                "Reads back saved notes, newest first. Optional query filters them.",
                schema("", "query:STRING:word to look for", "count:INTEGER:how many, default 10"),
                (c, a) -> {
                    JSONArray all = load(c, "notes");
                    String q = a.optString("query").toLowerCase(Locale.ROOT).trim();
                    int n = Math.max(1, Math.min(40, a.optInt("count", 10)));
                    JSONArray out = new JSONArray();
                    SimpleDateFormat f = new SimpleDateFormat("d MMM HH:mm", Locale.US);
                    for (int i = all.length() - 1; i >= 0 && out.length() < n; i--) {
                        JSONObject e = all.optJSONObject(i);
                        if (e == null) continue;
                        if (!q.isEmpty() && !e.optString("text").toLowerCase(Locale.ROOT).contains(q)) continue;
                        out.put(f.format(new Date(e.optLong("t"))) + " - " + e.optString("text"));
                    }
                    return J.ok("notes", out);
                });

        // ---- lead CRM
        reg("crm_add",
                "Adds or updates a lead/client in the follow-up book. status: new, contacted, interested, negotiation, won, lost. follow_up is a date yyyy-MM-dd.",
                schema("name", "name:STRING:business or person", "phone:STRING:phone", "email:STRING:email",
                        "status:STRING:new | contacted | interested | negotiation | won | lost",
                        "note:STRING:short note", "follow_up:STRING:next follow-up date yyyy-MM-dd"),
                (c, a) -> crmUpsert(c, a));

        reg("crm_update",
                "Updates an existing lead in the follow-up book by name (status, note, next follow-up date).",
                schema("name", "name:STRING:lead name", "status:STRING:new status", "note:STRING:note to add",
                        "follow_up:STRING:next follow-up date yyyy-MM-dd"),
                (c, a) -> crmUpsert(c, a));

        reg("crm_list",
                "Lists leads from the follow-up book, optionally only one status or matching a word.",
                schema("", "status:STRING:filter by status", "query:STRING:word in name or note"),
                (c, a) -> {
                    JSONArray all = load(c, "crm"), out = new JSONArray();
                    String st = a.optString("status").toLowerCase(Locale.ROOT).trim();
                    String q = a.optString("query").toLowerCase(Locale.ROOT).trim();
                    for (int i = 0; i < all.length(); i++) {
                        JSONObject e = all.optJSONObject(i);
                        if (e == null) continue;
                        if (!st.isEmpty() && !st.equals(e.optString("status"))) continue;
                        String hay = (e.optString("name") + " " + e.optString("note")).toLowerCase(Locale.ROOT);
                        if (!q.isEmpty() && !hay.contains(q)) continue;
                        out.put(e);
                    }
                    return J.ok("count", out.length(), "leads", out);
                });

        reg("crm_due",
                "Shows the leads whose follow-up date is today or already past (not won/lost). Use for 'who should I follow up today'.",
                schema(""),
                (c, a) -> {
                    JSONArray all = load(c, "crm"), out = new JSONArray();
                    String t = today();
                    for (int i = 0; i < all.length(); i++) {
                        JSONObject e = all.optJSONObject(i);
                        if (e == null) continue;
                        String f = e.optString("follow_up");
                        String st = e.optString("status");
                        if (!f.isEmpty() && f.compareTo(t) <= 0 && !"won".equals(st) && !"lost".equals(st)) out.put(e);
                    }
                    return J.ok("today", t, "count", out.length(), "due", out);
                });

        // ---- reply templates
        reg("template_save",
                "Saves a reusable reply (for WhatsApp/email) under a short name.",
                schema("name,text", "name:STRING:short name", "text:STRING:the message text"),
                (c, a) -> {
                    JSONArray all = load(c, "templates"), out = new JSONArray();
                    String nm = a.optString("name").trim().toLowerCase(Locale.ROOT);
                    for (int i = 0; i < all.length(); i++) {
                        JSONObject e = all.optJSONObject(i);
                        if (e != null && !nm.equals(e.optString("name"))) out.put(e);
                    }
                    out.put(J.obj("name", nm, "text", a.optString("text")));
                    save(c, "templates", out);
                    return J.ok("saved", nm);
                });

        reg("template_get",
                "Returns a saved reply by name, or lists all names when name is empty. Then send it with send_message if the user asked.",
                schema("", "name:STRING:template name"),
                (c, a) -> {
                    JSONArray all = load(c, "templates");
                    String nm = a.optString("name").trim().toLowerCase(Locale.ROOT);
                    JSONArray names = new JSONArray();
                    for (int i = 0; i < all.length(); i++) {
                        JSONObject e = all.optJSONObject(i);
                        if (e == null) continue;
                        names.put(e.optString("name"));
                        if (!nm.isEmpty() && (nm.equals(e.optString("name")) || e.optString("name").contains(nm))) {
                            return J.ok("name", e.optString("name"), "text", e.optString("text"));
                        }
                    }
                    return nm.isEmpty() ? J.ok("templates", names) : J.fail("no template called " + nm);
                });

        // ---- invoice / quotation
        reg("make_invoice",
                "Makes an invoice or quotation as a PDF in Downloads. items_json is a JSON array like [{\"name\":\"Website\",\"qty\":1,\"price\":15000}]. Totals are computed in code.",
                schema("client,items_json", "kind:STRING:invoice | quotation", "client:STRING:client name",
                        "items_json:STRING:JSON array of {name, qty, price}", "currency:STRING:e.g. BDT, USD (default BDT)",
                        "note:STRING:optional footer note"),
                (c, a) -> makeInvoice(c, a));

        // ---- photos
        reg("find_photos",
                "Finds photos from the gallery by age: days_ago=1 means the last day. Can open the newest match in the gallery.",
                schema("", "days_ago:INTEGER:how many days back, default 1", "limit:INTEGER:max results, default 10",
                        "open:BOOLEAN:open the newest one in the gallery"),
                (c, a) -> findPhotos(c, a));

        // ---- style and interpreter
        reg("set_style",
                "Changes how Mira talks: friend (warm, relaxed) or normal. Serious mode has its own heavy tone. Applies after a short reconnect.",
                schema("style", "style:STRING:friend | normal"),
                (c, a) -> {
                    String s = "friend".equalsIgnoreCase(a.optString("style")) ? "friend" : "normal";
                    Prefs.sp(c).edit().putString("style", s).apply();
                    refreshLive();
                    return J.ok("style", s);
                });

        reg("translate_mode",
                "Interpreter mode: Mira repeats everything she hears in the other language until stopped. action on needs language_a and language_b (example Bangla and English).",
                schema("action", "action:STRING:on | off", "language_a:STRING:first language", "language_b:STRING:second language"),
                (c, a) -> {
                    boolean on = !"off".equalsIgnoreCase(a.optString("action"));
                    if (on) {
                        String x = a.optString("language_a", "Bangla").replace("|", " ").trim();
                        String y = a.optString("language_b", "English").replace("|", " ").trim();
                        Prefs.sp(c).edit().putString("translate", x + "|" + y).apply();
                    } else {
                        Prefs.sp(c).edit().remove("translate").apply();
                    }
                    refreshLive();
                    return J.ok("interpreter", on);
                });
    }

    private static void refreshLive() {
        try {
            JarvisService s = JarvisService.get();
            if (s != null) s.applyModeChange();
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ CRM

    private static JSONObject crmUpsert(Context c, JSONObject a) {
        String name = a.optString("name").trim();
        if (name.isEmpty()) return J.fail("name is empty");
        JSONArray all = load(c, "crm");
        JSONObject hit = null;
        for (int i = 0; i < all.length(); i++) {
            JSONObject e = all.optJSONObject(i);
            if (e != null && e.optString("name").equalsIgnoreCase(name)) hit = e;
        }
        boolean isNew = hit == null;
        if (isNew) {
            hit = J.obj("name", name, "status", "new", "added", today());
            all.put(hit);
        }
        String[] keys = {"phone", "email", "status", "follow_up"};
        for (String k : keys) {
            String v = a.optString(k).trim();
            if (!v.isEmpty()) J.put(hit, k, k.equals("status") ? v.toLowerCase(Locale.ROOT) : v);
        }
        String note = a.optString("note").trim();
        if (!note.isEmpty()) {
            String old = hit.optString("note");
            J.put(hit, "note", old.isEmpty() ? note : old + " | " + note);
        }
        save(c, "crm", all);
        return J.ok(isNew ? "added" : "updated", name, "lead", hit);
    }

    // ------------------------------------------------------------------ emergency

    private static JSONObject emergency(Context c) {
        JSONArray nums = load(c, "emergency");
        if (nums.length() == 0) return J.fail("no emergency contacts saved; ask the user to name them and call set_emergency_contacts");
        if (c.checkSelfPermission(android.Manifest.permission.SEND_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return J.fail("SMS permission is missing");
        }
        String where = "location unknown";
        try {
            if (c.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    || c.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
                Location best = null;
                for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER}) {
                    try {
                        Location l = lm.getLastKnownLocation(p);
                        if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                    } catch (Exception ignored) {
                    }
                }
                if (best != null) {
                    where = "https://maps.google.com/?q=" + best.getLatitude() + "," + best.getLongitude();
                }
            }
        } catch (Throwable ignored) {
        }
        String who = Prefs.userName(c).isEmpty() ? "Your contact" : Prefs.userName(c);
        String text = "EMERGENCY! " + who + " needs help right now. Location: " + where;
        SmsManager sm = Build.VERSION.SDK_INT >= 31 ? c.getSystemService(SmsManager.class) : SmsManager.getDefault();
        int sent = 0;
        for (int i = 0; i < nums.length(); i++) {
            try {
                sm.sendMultipartTextMessage(nums.optString(i), null, sm.divideMessage(text), null, null);
                sent++;
            } catch (Throwable t) {
                DebugLog.add("Emergency SMS failed for one contact: " + t);
            }
        }
        return sent > 0 ? J.ok("sent_to", sent, "location", where, "note", "SMS handed to the network; delivery cannot be confirmed")
                : J.fail("could not send the SMS");
    }

    // ------------------------------------------------------------------ photos

    private static JSONObject findPhotos(Context c, JSONObject a) {
        int days = Math.max(0, a.optInt("days_ago", 1));
        int limit = Math.max(1, Math.min(30, a.optInt("limit", 10)));
        long since = System.currentTimeMillis() / 1000L - days * 86400L;
        JSONArray out = new JSONArray();
        Uri first = null;
        try (Cursor cur = c.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED},
                MediaStore.Images.Media.DATE_ADDED + " >= ?", new String[]{String.valueOf(since)},
                MediaStore.Images.Media.DATE_ADDED + " DESC")) {
            if (cur == null) return J.fail("the gallery could not be read");
            SimpleDateFormat f = new SimpleDateFormat("d MMM HH:mm", Locale.US);
            while (cur.moveToNext() && out.length() < limit) {
                long id = cur.getLong(0);
                Uri u = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, String.valueOf(id));
                if (first == null) first = u;
                out.put(cur.getString(1) + " (" + f.format(new Date(cur.getLong(2) * 1000L)) + ")");
            }
        } catch (SecurityException se) {
            return J.fail("photo access is not allowed: grant All files access / Photos permission in Mira's setup page");
        }
        if (first != null && a.optBoolean("open", false)) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(first, "image/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Util.launch(c, i);
            } catch (Throwable t) {
                DebugLog.add("Could not open the photo: " + t);
            }
        }
        return J.ok("found", out.length(), "photos", out);
    }

    // ------------------------------------------------------------------ invoice PDF

    private static JSONObject makeInvoice(Context c, JSONObject a) throws Exception {
        JSONArray items;
        try {
            items = new JSONArray(a.optString("items_json"));
        } catch (Exception e) {
            return J.fail("items_json is not valid JSON");
        }
        if (items.length() == 0) return J.fail("no items");
        String kind = "quotation".equalsIgnoreCase(a.optString("kind")) ? "QUOTATION" : "INVOICE";
        String cur = a.optString("currency", "BDT").trim();
        if (cur.isEmpty()) cur = "BDT";
        String client = a.optString("client").trim();
        String from = Prefs.userName(c).isEmpty() ? Prefs.assistantName(c) : Prefs.userName(c);
        String date = new SimpleDateFormat("d MMM yyyy", Locale.US).format(new Date());
        String no = new SimpleDateFormat("yyMMdd-HHmm", Locale.US).format(new Date());

        android.graphics.pdf.PdfDocument pdf = new android.graphics.pdf.PdfDocument();
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        final int W = 595, H = 842, M = 40;
        int pageNo = 1;
        android.graphics.pdf.PdfDocument.Page page = pdf.startPage(new android.graphics.pdf.PdfDocument.PageInfo.Builder(W, H, pageNo).create());
        android.graphics.Canvas cv = page.getCanvas();
        int y = 60;
        p.setColor(0xFF0B3C49);
        p.setTextSize(26f);
        p.setFakeBoldText(true);
        cv.drawText(kind, M, y, p);
        p.setFakeBoldText(false);
        p.setTextSize(11f);
        p.setColor(0xFF444444);
        y += 24;
        cv.drawText("No: " + no + "     Date: " + date, M, y, p);
        y += 16;
        cv.drawText("From: " + from, M, y, p);
        y += 16;
        cv.drawText("To: " + client, M, y, p);
        y += 30;

        p.setFakeBoldText(true);
        p.setColor(0xFF000000);
        cv.drawText("Item", M, y, p);
        cv.drawText("Qty", 340, y, p);
        cv.drawText("Price", 410, y, p);
        cv.drawText("Total", 490, y, p);
        p.setFakeBoldText(false);
        y += 6;
        p.setColor(0xFF999999);
        cv.drawLine(M, y, W - M, y, p);
        y += 18;
        p.setColor(0xFF000000);

        double grand = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it == null) continue;
            double qty = it.optDouble("qty", 1);
            double price = it.optDouble("price", 0);
            double line = qty * price;
            grand += line;
            if (y > H - 100) {
                pdf.finishPage(page);
                pageNo++;
                page = pdf.startPage(new android.graphics.pdf.PdfDocument.PageInfo.Builder(W, H, pageNo).create());
                cv = page.getCanvas();
                y = 60;
            }
            String nm = it.optString("name");
            if (nm.length() > 48) nm = nm.substring(0, 48) + "...";
            cv.drawText(nm, M, y, p);
            cv.drawText(trim(qty), 340, y, p);
            cv.drawText(trim(price), 410, y, p);
            cv.drawText(trim(line), 490, y, p);
            y += 20;
        }
        y += 4;
        p.setColor(0xFF999999);
        cv.drawLine(M, y, W - M, y, p);
        y += 24;
        p.setColor(0xFF000000);
        p.setFakeBoldText(true);
        p.setTextSize(14f);
        cv.drawText("TOTAL: " + trim(grand) + " " + cur, 360, y, p);
        p.setFakeBoldText(false);
        p.setTextSize(11f);
        String note = a.optString("note").trim();
        if (!note.isEmpty()) {
            y += 34;
            p.setColor(0xFF444444);
            cv.drawText(note.length() > 90 ? note.substring(0, 90) : note, M, y, p);
        }
        pdf.finishPage(page);

        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (!dir.exists()) dir.mkdirs();
        String safe = client.replaceAll("[^A-Za-z0-9]+", "_");
        if (safe.isEmpty()) safe = "client";
        File out = new File(dir, kind.charAt(0) + kind.substring(1).toLowerCase(Locale.ROOT) + "_" + safe + "_" + no + ".pdf");
        try (FileOutputStream fo = new FileOutputStream(out)) {
            pdf.writeTo(fo);
        } finally {
            pdf.close();
        }
        return J.ok("saved_to", out.getAbsolutePath(), "total", trim(grand) + " " + cur);
    }

    private static String trim(double v) {
        if (v == Math.rint(v)) return String.valueOf((long) v);
        return String.format(Locale.US, "%.2f", v);
    }
}
