package com.markvi.jarvis;

import android.service.voice.VoiceInteractionService;

/** Lets Mira be chosen as the phone's default digital assistant (side key / home long-press opens her). */
public class MiraInteractionService extends VoiceInteractionService {
}
