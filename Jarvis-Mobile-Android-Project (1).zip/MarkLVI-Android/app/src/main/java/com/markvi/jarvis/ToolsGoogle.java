package com.markvi.jarvis;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/**
 * Google Calendar (through the phone's own calendar, which Google Calendar syncs with), Gmail (compose + recent mail from notifications)
 * and personalised email drafts for a leads file. No Google sign-in is needed: everything goes through the apps already on the phone.
 */
final class ToolsGoogle {
    private ToolsGoogle() {}

    private static final SimpleDateFormat FMT = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);

    static void register() {
        reg("calendar_list",
                "Lists the user's upcoming Google Calendar events (read directly from the phone's calendar). days = how many days ahead (default 7).",
                schema("", "days:INTEGER:days ahead, default 7, max 60"),
                (c, a) -> calendarList(c, a.optInt("days", 7)));

        reg("calendar_add",
                "Adds an event straight into the user's Google Calendar (saved immediately, no form). begin/end are 'YYYY-MM-DD HH:MM' local time. "
                        + "Use this instead of calendar_event when the user just wants it added.",
                schema("title,begin",
                        "title:STRING:event title",
                        "begin:STRING:start 'YYYY-MM-DD HH:MM'",
                        "end:STRING:end 'YYYY-MM-DD HH:MM' (default one hour)",
                        "location:STRING:optional place",
                        "description:STRING:optional notes",
                        "reminder_minutes:INTEGER:reminder before the event, default 30"),
                (c, a) -> calendarAdd(c, a));

        reg("calendar_update",
                "Changes an existing calendar event (title, time, place, notes) by event_id from calendar_list. Only the fields given are changed. "
                        + "begin/end are 'YYYY-MM-DD HH:MM'; if only begin is given the event keeps its length.",
                schema("event_id",
                        "event_id:INTEGER:id from calendar_list",
                        "title:STRING:new title",
                        "begin:STRING:new start 'YYYY-MM-DD HH:MM'",
                        "end:STRING:new end 'YYYY-MM-DD HH:MM'",
                        "location:STRING:new place",
                        "description:STRING:new notes"),
                (c, a) -> calendarUpdate(c, a));

        reg("calendar_search",
                "Finds calendar events whose title, place or notes contain a word, in the next/previous days. days_ahead default 60, days_back default 0.",
                schema("query", "query:STRING:word to look for", "days_ahead:INTEGER:default 60, max 365", "days_back:INTEGER:default 0, max 365"),
                (c, a) -> calendarSearch(c, a));

        reg("calendar_delete",
                "Deletes one calendar event by event_id (from calendar_list). The user approves on screen first.",
                schema("event_id,title", "event_id:INTEGER:id from calendar_list", "title:STRING:the event title, for the approval screen"),
                (c, a) -> calendarDelete(c, a));

        reg("gmail_recent",
                "Reads the most recent Gmail messages the phone has shown as notifications (sender, subject, preview). "
                        + "Mira cannot open the whole inbox: only mail that arrived as a notification. Needs notification access.",
                schema(""),
                (c, a) -> gmailRecent(c));

        reg("email_draft",
                "Opens Gmail with the recipient, subject and body filled in but NOT sent, so the user can review it. Use when the user says draft / "
                        + "write an email but not 'send'.",
                schema("receiver,subject,body", "receiver:STRING:email address", "subject:STRING:subject", "body:STRING:body text"),
                (c, a) -> {
                    openDraft(c, a.optString("receiver"), a.optString("subject"), a.optString("body"));
                    return J.started("note", "Gmail opened with the draft; nothing has been sent");
                });

        reg("draft_lead_emails",
                "Writes a short personalised email for each lead that has an Email in a saved leads .csv and saves them as a drafts CSV "
                        + "(Email,Name,Subject,Body) in Downloads. Nothing is sent. Use open_email_draft to review one in Gmail or send_email_batch for a single common message.",
                schema("path,offer",
                        "path:STRING:full path of the leads .csv",
                        "offer:STRING:what the user offers (service, price idea, goal of the email)",
                        "sender:STRING:the user's name / business name to sign with",
                        "language:STRING:email language, default the language of the offer text",
                        "max:INTEGER:how many drafts, default 20, max 30"),
                (c, a) -> draftLeadEmails(c, a));

        reg("open_email_draft",
                "Opens row number N (1 = first) of a drafts CSV from draft_lead_emails in Gmail, unsent, so the user can review and send it.",
                schema("path,row", "path:STRING:drafts csv path", "row:INTEGER:row number starting at 1"),
                (c, a) -> {
                    String csv = SeriousMode.readText(a.optString("path"));
                    if (csv == null) return J.fail("drafts file not found in Downloads");
                    List<List<String>> rows = parseCsv(csv);
                    int r = a.optInt("row", 1);
                    if (r < 1 || r >= rows.size() || rows.get(r).size() < 4) return J.fail("no such row");
                    List<String> x = rows.get(r);
                    openDraft(c, x.get(0), x.get(2), x.get(3));
                    return J.started("note", "draft " + r + " opened in Gmail for " + x.get(0) + "; not sent");
                });
    }

    // ------------------------------------------------------------------ calendar

    private static boolean has(Context c, String p) {
        return c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private static JSONObject calendarList(Context c, int days) {
        if (!has(c, Manifest.permission.READ_CALENDAR)) return J.fail("Calendar permission is missing. Allow Calendar for Mira in the phone's App info > Permissions.");
        days = Math.max(1, Math.min(60, days));
        long now = System.currentTimeMillis();
        Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b, now);
        ContentUris.appendId(b, now + days * 86400000L);
        JSONArray out = new JSONArray();
        try (Cursor cur = c.getContentResolver().query(b.build(), new String[]{CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.EVENT_LOCATION,
                CalendarContract.Instances.ALL_DAY}, null, null, CalendarContract.Instances.BEGIN + " ASC")) {
            while (cur != null && cur.moveToNext() && out.length() < 40) {
                boolean allDay = cur.getInt(5) == 1;
                SimpleDateFormat f = new SimpleDateFormat(allDay ? "yyyy-MM-dd" : "yyyy-MM-dd HH:mm", Locale.US);
                if (allDay) f.setTimeZone(TimeZone.getTimeZone("UTC"));
                out.put(J.obj("event_id", cur.getLong(0), "title", cur.getString(1) == null ? "" : cur.getString(1),
                        "begin", f.format(new Date(cur.getLong(2))), "end", f.format(new Date(cur.getLong(3))),
                        "location", cur.getString(4) == null ? "" : cur.getString(4), "all_day", allDay));
            }
        } catch (Exception e) {
            return J.fail("could not read the calendar: " + e.getMessage());
        }
        return J.ok("count", out.length(), "events", out);
    }

    private static long pickCalendar(Context c) {
        long best = -1;
        int bestScore = -1;
        try (Cursor cur = c.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI,
                new String[]{CalendarContract.Calendars._ID, CalendarContract.Calendars.ACCOUNT_TYPE, CalendarContract.Calendars.IS_PRIMARY,
                        CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL, CalendarContract.Calendars.VISIBLE}, null, null, null)) {
            while (cur != null && cur.moveToNext()) {
                if (cur.getInt(3) < CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) continue;
                int score = 1 + (cur.getInt(4) == 1 ? 1 : 0) + ("com.google".equals(cur.getString(1)) ? 4 : 0) + (cur.getInt(2) == 1 ? 8 : 0);
                if (score > bestScore) {
                    bestScore = score;
                    best = cur.getLong(0);
                }
            }
        } catch (Exception ignored) {
        }
        return best;
    }

    private static JSONObject calendarAdd(Context c, JSONObject a) throws Exception {
        if (!has(c, Manifest.permission.WRITE_CALENDAR)) return J.fail("Calendar permission is missing. Allow Calendar for Mira in the phone's App info > Permissions.");
        Date b = FMT.parse(a.optString("begin"));
        if (b == null) return J.fail("could not read the begin time");
        Date e = a.optString("end").isEmpty() ? new Date(b.getTime() + 3600000L) : FMT.parse(a.optString("end"));
        if (e == null || e.before(b)) e = new Date(b.getTime() + 3600000L);
        long cal = pickCalendar(c);
        if (cal < 0) return J.fail("no writable calendar on this phone; open Google Calendar once and sign in");
        ContentValues v = new ContentValues();
        v.put(CalendarContract.Events.CALENDAR_ID, cal);
        v.put(CalendarContract.Events.TITLE, a.optString("title"));
        v.put(CalendarContract.Events.DTSTART, b.getTime());
        v.put(CalendarContract.Events.DTEND, e.getTime());
        v.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
        v.put(CalendarContract.Events.EVENT_LOCATION, a.optString("location"));
        v.put(CalendarContract.Events.DESCRIPTION, a.optString("description"));
        v.put(CalendarContract.Events.HAS_ALARM, 1);
        ContentResolver cr = c.getContentResolver();
        Uri u = cr.insert(CalendarContract.Events.CONTENT_URI, v);
        if (u == null) return J.fail("the calendar refused the event");
        long id = ContentUris.parseId(u);
        try {
            ContentValues r = new ContentValues();
            r.put(CalendarContract.Reminders.EVENT_ID, id);
            r.put(CalendarContract.Reminders.MINUTES, Math.max(0, a.optInt("reminder_minutes", 30)));
            r.put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT);
            cr.insert(CalendarContract.Reminders.CONTENT_URI, r);
        } catch (Exception ignored) {
        }
        return J.ok("event_id", id, "note", "added to the calendar; Google Calendar syncs it to the account shortly");
    }

    private static JSONObject calendarUpdate(Context c, JSONObject a) throws Exception {
        if (!has(c, Manifest.permission.WRITE_CALENDAR)) return J.fail("Calendar permission is missing");
        long id = a.optLong("event_id", -1);
        if (id < 0) return J.fail("event_id is required");
        Uri uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id);
        long oldB = 0, oldE = 0;
        try (Cursor cur = c.getContentResolver().query(uri, new String[]{CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND}, null, null, null)) {
            if (cur == null || !cur.moveToFirst()) return J.fail("event not found");
            oldB = cur.getLong(0);
            oldE = cur.getLong(1);
        }
        ContentValues v = new ContentValues();
        if (a.has("title") && !a.optString("title").isEmpty()) v.put(CalendarContract.Events.TITLE, a.optString("title"));
        if (a.has("location")) v.put(CalendarContract.Events.EVENT_LOCATION, a.optString("location"));
        if (a.has("description")) v.put(CalendarContract.Events.DESCRIPTION, a.optString("description"));
        if (!a.optString("begin").isEmpty()) {
            Date b = FMT.parse(a.optString("begin"));
            if (b == null) return J.fail("could not read begin time");
            long len = oldE > oldB ? oldE - oldB : 3600000L;
            Date e = a.optString("end").isEmpty() ? new Date(b.getTime() + len) : FMT.parse(a.optString("end"));
            if (e == null || e.before(b)) e = new Date(b.getTime() + len);
            v.put(CalendarContract.Events.DTSTART, b.getTime());
            v.put(CalendarContract.Events.DTEND, e.getTime());
            v.put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().getID());
        }
        if (v.size() == 0) return J.fail("nothing to change");
        int n = c.getContentResolver().update(uri, v, null, null);
        return n > 0 ? J.ok("updated", n) : J.fail("the calendar refused the change (it may be read-only, e.g. a holidays calendar)");
    }

    private static JSONObject calendarSearch(Context c, JSONObject a) {
        if (!has(c, Manifest.permission.READ_CALENDAR)) return J.fail("Calendar permission is missing");
        String q = a.optString("query").trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return J.fail("query is required");
        long now = System.currentTimeMillis();
        long from = now - Math.max(0, Math.min(365, a.optInt("days_back", 0))) * 86400000L;
        long to = now + Math.max(1, Math.min(365, a.optInt("days_ahead", 60))) * 86400000L;
        Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b, from);
        ContentUris.appendId(b, to);
        JSONArray out = new JSONArray();
        try (Cursor cur = c.getContentResolver().query(b.build(), new String[]{CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE,
                CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.EVENT_LOCATION,
                CalendarContract.Instances.DESCRIPTION}, null, null, CalendarContract.Instances.BEGIN + " ASC")) {
            while (cur != null && cur.moveToNext() && out.length() < 30) {
                String hay = ((cur.getString(1) == null ? "" : cur.getString(1)) + " " + (cur.getString(4) == null ? "" : cur.getString(4)) + " "
                        + (cur.getString(5) == null ? "" : cur.getString(5))).toLowerCase(Locale.ROOT);
                if (!hay.contains(q)) continue;
                out.put(J.obj("event_id", cur.getLong(0), "title", cur.getString(1) == null ? "" : cur.getString(1),
                        "begin", FMT.format(new Date(cur.getLong(2))), "end", FMT.format(new Date(cur.getLong(3))),
                        "location", cur.getString(4) == null ? "" : cur.getString(4)));
            }
        } catch (Exception e) {
            return J.fail("could not read the calendar: " + e.getMessage());
        }
        return J.ok("count", out.length(), "events", out);
    }

    private static JSONObject calendarDelete(Context c, JSONObject a) {
        if (!has(c, Manifest.permission.WRITE_CALENDAR)) return J.fail("Calendar permission is missing");
        long id = a.optLong("event_id", -1);
        if (id < 0) return J.fail("event_id is required");
        if (!Bus.confirm("Delete calendar event: " + a.optString("title") + " ?")) return J.obj("status", "declined", "note", "the user did not approve");
        int n = c.getContentResolver().delete(ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id), null, null);
        return n > 0 ? J.ok("deleted", n) : J.fail("event not found");
    }

    // ------------------------------------------------------------------ gmail

    private static JSONObject gmailRecent(Context c) {
        if (!NotifCatcher.hasAccess(c)) return J.fail("Notification access is off. Turn it on for Mira in the phone's notification access settings; Mira reads Gmail only from notifications.");
        JSONArray out = new JSONArray();
        try {
            JSONArray all = new JSONArray(NotifCatcher.json());
            for (int i = 0; i < all.length() && out.length() < 15; i++) {
                JSONObject o = all.getJSONObject(i);
                if (o.optString("app").toLowerCase(Locale.ROOT).contains("gmail")) {
                    out.put(J.obj("from_or_subject", o.optString("sender"), "preview", o.optString("desc"), "time", o.optString("time")));
                }
            }
        } catch (Exception e) {
            return J.fail("could not read notifications: " + e.getMessage());
        }
        return J.ok("count", out.length(), "messages", out,
                "note", "only mail that showed up as a notification is visible; this is not the full inbox");
    }

    static void openDraft(Context c, String to, String subject, String body) {
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to.trim(), "@,;")
                + "?subject=" + Uri.encode(subject) + "&body=" + Uri.encode(body)));
        try {
            c.getPackageManager().getPackageInfo("com.google.android.gm", 0);
            i.setPackage("com.google.android.gm");
        } catch (Exception ignored) {
        }
        Util.launch(c, i);
    }

    // ------------------------------------------------------------------ lead -> email drafts

    static List<List<String>> parseCsv(String csv) {
        List<List<String>> rows = new ArrayList<>();
        for (String line : csv.split("\\r?\\n")) {
            if (!line.trim().isEmpty()) rows.add(ToolsLeads.splitCsv(line));
        }
        return rows;
    }

    private static JSONObject draftLeadEmails(Context c, JSONObject a) throws Exception {
        String csv = SeriousMode.readText(a.optString("path"));
        if (csv == null) return J.fail("leads file not found in Downloads");
        List<List<String>> rows = parseCsv(csv);
        if (rows.size() < 2) return J.fail("the file is empty");
        int ei = -1, ni = -1, wi = -1, ti = -1;
        for (int i = 0; i < rows.get(0).size(); i++) {
            String h = rows.get(0).get(i).trim().toLowerCase(Locale.ROOT);
            if (h.equals("email")) ei = i;
            else if (h.equals("name")) ni = i;
            else if (h.equals("website")) wi = i;
            else if (h.equals("notes")) ti = i;
        }
        if (ei < 0 || ni < 0) return J.fail("the file needs Name and Email columns");
        int max = Math.max(1, Math.min(30, a.optInt("max", 20)));
        List<String[]> leads = new ArrayList<>(); // email, name, website, notes
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (int r = 1; r < rows.size() && leads.size() < max; r++) {
            List<String> x = rows.get(r);
            if (x.size() <= ei) continue;
            String em = x.get(ei).trim().toLowerCase(Locale.ROOT);
            if (!em.matches("[a-z0-9._%+\\-]+@[a-z0-9.\\-]+\\.[a-z]{2,}") || !seen.add(em)) continue;
            leads.add(new String[]{em, x.size() > ni ? x.get(ni) : "", wi >= 0 && x.size() > wi ? x.get(wi) : "", ti >= 0 && x.size() > ti ? x.get(ti) : ""});
        }
        if (leads.isEmpty()) return J.fail("no valid email addresses in the file");

        String offer = a.optString("offer"), sender = a.optString("sender"), lang = a.optString("language");
        StringBuilder out = new StringBuilder("Email,Name,Subject,Body\n");
        int done = 0;
        for (int s = 0; s < leads.size(); s += 5) {
            List<String[]> chunk = leads.subList(s, Math.min(leads.size(), s + 5));
            JSONArray in = new JSONArray();
            for (int k = 0; k < chunk.size(); k++) in.put(J.obj("i", k, "name", chunk.get(k)[1], "website", chunk.get(k)[2], "notes", chunk.get(k)[3]));
            String prompt = "Write one short, polite, personalised cold email (60 to 110 words) for each business below. "
                    + "What I offer: " + offer + ". Sign as: " + (sender.isEmpty() ? "the sender" : sender) + ". "
                    + (lang.isEmpty() ? "Write in the language of the offer text." : "Write in " + lang + ".") + " "
                    + "Rules: use only the facts given (name, website, notes); never invent facts, awards or numbers about them; no false claims or fake urgency; "
                    + "one clear call to action; end with one line saying they can simply reply 'no' and no more mail will be sent. "
                    + "Return ONLY a JSON array, same order, items {\"i\":number,\"subject\":string,\"body\":string}. Businesses: " + in;
            String raw;
            try {
                raw = SeriousMode.providerReady(c) ? CustomAgent.simple(c, prompt) : GeminiRest.generate(c, prompt);
            } catch (Exception ex) {
                DebugLog.add("draft batch failed: " + ex.getMessage());
                continue;
            }
            int b0 = raw.indexOf('['), b1 = raw.lastIndexOf(']');
            if (b0 < 0 || b1 <= b0) continue;
            try {
                JSONArray arr = new JSONArray(raw.substring(b0, b1 + 1));
                for (int k = 0; k < arr.length(); k++) {
                    JSONObject o = arr.optJSONObject(k);
                    if (o == null) continue;
                    int idx = o.optInt("i", k);
                    if (idx < 0 || idx >= chunk.size() || o.optString("body").isEmpty()) continue;
                    String[] l = chunk.get(idx);
                    out.append(ToolsLeads.csv(l[0])).append(',').append(ToolsLeads.csv(l[1])).append(',')
                            .append(ToolsLeads.csv(o.optString("subject"))).append(',').append(ToolsLeads.csv(o.optString("body"))).append('\n');
                    done++;
                }
            } catch (Exception ex) {
                DebugLog.add("draft parse failed: " + ex.getMessage());
            }
        }
        if (done == 0) return J.fail("the AI did not return usable drafts; try again or check the provider/key");
        String base = new java.io.File(a.optString("path")).getName().replaceAll("\\.csv$", "");
        java.io.File f = SeriousMode.saveBytes(c, "email-drafts-" + base + ".csv", out.toString().getBytes("UTF-8"), base);
        return J.ok("drafts", done, "file", f.getAbsolutePath(),
                "note", "nothing was sent. Review them (open_email_draft shows one in Gmail). Only email businesses with a public business address, and honour any 'no' reply.");
    }
}
