#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include "whisper.h"

#define UNUSED(x) (void)(x)

JNIEXPORT jlong JNICALL
Java_com_markvi_jarvis_WhisperLib_nativeInit(JNIEnv *env, jclass cls, jstring path) {
    UNUSED(cls);
    const char *p = (*env)->GetStringUTFChars(env, path, NULL);
    struct whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = 0;
    struct whisper_context *ctx = whisper_init_from_file_with_params(p, cp);
    (*env)->ReleaseStringUTFChars(env, path, p);
    return (jlong) ctx;
}

JNIEXPORT void JNICALL
Java_com_markvi_jarvis_WhisperLib_nativeFree(JNIEnv *env, jclass cls, jlong ptr) {
    UNUSED(env); UNUSED(cls);
    if (ptr) whisper_free((struct whisper_context *) ptr);
}

/* Returns the recognised text, or null on failure. samples: 16 kHz mono float -1..1. */
JNIEXPORT jstring JNICALL
Java_com_markvi_jarvis_WhisperLib_nativeTranscribe(JNIEnv *env, jclass cls, jlong ptr, jint threads,
                                                   jfloatArray audio, jstring lang, jstring prompt) {
    UNUSED(cls);
    struct whisper_context *ctx = (struct whisper_context *) ptr;
    if (!ctx) return NULL;
    jfloat *a = (*env)->GetFloatArrayElements(env, audio, NULL);
    jsize n = (*env)->GetArrayLength(env, audio);
    const char *lg = (*env)->GetStringUTFChars(env, lang, NULL);

    const char *pr = (*env)->GetStringUTFChars(env, prompt, NULL);
    struct whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.print_realtime = 0;
    p.print_progress = 0;
    p.print_timestamps = 0;
    p.print_special = 0;
    p.translate = 0;
    p.language = lg;
    p.n_threads = threads;
    p.no_context = 1;
    p.single_segment = 1;
    p.suppress_blank = 1;
    p.initial_prompt = pr;

    jstring out = NULL;
    if (whisper_full(ctx, p, a, n) == 0) {
        int segs = whisper_full_n_segments(ctx);
        size_t cap = 1;
        for (int i = 0; i < segs; i++) cap += strlen(whisper_full_get_segment_text(ctx, i)) + 1;
        char *buf = (char *) calloc(cap, 1);
        for (int i = 0; i < segs; i++) {
            strcat(buf, whisper_full_get_segment_text(ctx, i));
        }
        out = (*env)->NewStringUTF(env, buf);
        free(buf);
    }
    (*env)->ReleaseStringUTFChars(env, prompt, pr);
    (*env)->ReleaseStringUTFChars(env, lang, lg);
    (*env)->ReleaseFloatArrayElements(env, audio, a, JNI_ABORT);
    return out;
}

JNIEXPORT jint JNICALL
Java_com_markvi_jarvis_WhisperLib_nativeSupported(JNIEnv *env, jclass cls) {
    UNUSED(env); UNUSED(cls);
    return 1;
}
