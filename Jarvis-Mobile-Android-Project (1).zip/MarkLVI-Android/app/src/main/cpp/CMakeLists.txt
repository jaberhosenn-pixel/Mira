cmake_minimum_required(VERSION 3.18)

# The Gradle "debug" build would compile Whisper without optimisation (many times slower). Always optimise.
if (NOT CMAKE_BUILD_TYPE STREQUAL "Release")
    set(CMAKE_BUILD_TYPE Release CACHE STRING "" FORCE)
endif()

project(mira_whisper C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_C_STANDARD 11)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

if (ANDROID AND NOT ANDROID_ABI STREQUAL "arm64-v8a")
    # 32-bit phones: a small stub library, so the app still installs and runs (Whisper just stays unavailable)
    add_library(mirawhisper SHARED jni_stub.c)
    return()
endif()

# whisper.cpp v1.8.2 (MIT), CPU only
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(GGML_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(GGML_CCACHE OFF CACHE BOOL "" FORCE)

add_subdirectory(wcpp/ggml ggml_build)

add_library(mirawhisper SHARED wcpp/src/whisper.cpp jni.c)
target_compile_definitions(mirawhisper PRIVATE WHISPER_VERSION="1.8.2")
target_include_directories(mirawhisper PRIVATE wcpp/include wcpp/src wcpp/ggml/include wcpp/ggml/src)
target_compile_options(mirawhisper PRIVATE -O3 -ffunction-sections -fdata-sections)
target_link_options(mirawhisper PRIVATE -Wl,--gc-sections)
if (ANDROID)
    find_library(LOG_LIB log)
    target_link_libraries(mirawhisper ggml ${LOG_LIB} android)
else()
    target_link_libraries(mirawhisper ggml)
endif()
