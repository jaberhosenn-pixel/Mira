#include <jni.h>

/* Used on 32-bit phones: Whisper is not built there, Mira falls back to the phone's own speech recogniser. */
JNIEXPORT jlong JNICALL Java_com_markvi_jarvis_WhisperLib_nativeInit(JNIEnv *env, jclass cls, jstring path) { (void)env; (void)cls; (void)path; return 0; }
JNIEXPORT void JNICALL Java_com_markvi_jarvis_WhisperLib_nativeFree(JNIEnv *env, jclass cls, jlong ptr) { (void)env; (void)cls; (void)ptr; }
JNIEXPORT jstring JNICALL Java_com_markvi_jarvis_WhisperLib_nativeTranscribe(JNIEnv *env, jclass cls, jlong ptr, jint threads, jfloatArray audio, jstring lang, jstring prompt) { (void)env; (void)cls; (void)ptr; (void)threads; (void)audio; (void)lang; (void)prompt; return NULL; }
JNIEXPORT jint JNICALL Java_com_markvi_jarvis_WhisperLib_nativeSupported(JNIEnv *env, jclass cls) { (void)env; (void)cls; return 0; }
