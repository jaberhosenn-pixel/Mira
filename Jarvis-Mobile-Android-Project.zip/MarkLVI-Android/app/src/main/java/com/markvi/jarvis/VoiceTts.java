package com.markvi.jarvis;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Speaks typed-chat replies and voice demos with the real Gemini human voices (24 kHz, same prebuilt
 * voices as the live session) instead of the phone's robotic text-to-speech.
 */
public final class VoiceTts {
    private VoiceTts() {}

    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String[] MODELS = {"gemini-2.5-flash-preview-tts", "gemini-2.5-pro-preview-tts"};
    private static final int RATE = 24000;
    private static final ExecutorService POOL = Executors.newCachedThreadPool();

    public static volatile String lastError = "";
    private static volatile boolean cancelled;
    private static volatile AudioTrack track;
    private static final Object LOCK = new Object();

    public static void stop() {
        cancelled = true;
        AudioTrack t = track;
        if (t != null) {
            try {
                t.pause();
                t.flush();
            } catch (Exception ignored) {
            }
        }
    }

    /** Speaks the text with the given voice. Returns true when real voice audio was played. */
    public static boolean speak(Context c, String text, String voice) {
        synchronized (LOCK) {
            cancelled = false;
            lastError = "";
            if (Prefs.apiKey(c).isEmpty()) {
                lastError = "No Gemini API key saved";
                return false;
            }
            List<String> parts = split(text);
            if (parts.isEmpty()) return false;
            boolean any = false;
            // ask for every part at once so there is no waiting gap between sentences
            List<Future<byte[]>> jobs = new ArrayList<>();
            for (String part : parts) jobs.add(fetch(c, part, voice));
            AudioTrack t = null;
            try {
                t = openTrack();
                track = t;
                for (int i = 0; i < parts.size() && !cancelled; i++) {
                    byte[] pcm = jobs.get(i).get();
                    if (pcm == null || pcm.length == 0) continue;
                    play(t, pcm);
                    any = true;
                }
                if (any && !cancelled) {
                    try {
                        Thread.sleep(250);
                    } catch (InterruptedException ignored) {
                    }
                }
            } catch (Exception e) {
                Bus.log("Voice error: " + e.getMessage());
            } finally {
                track = null;
                if (t != null) {
                    try {
                        t.stop();
                    } catch (Exception ignored) {
                    }
                    t.release();
                }
                Bus.Ui u = Bus.ui;
                if (u != null) u.onLevels(0, 0);
            }
            return any;
        }
    }

    /** Quick check used by the debugger: can we get real voice audio right now? */
    public static String probe(Context c, String voice) {
        lastError = "";
        if (Prefs.apiKey(c).isEmpty()) return "FAILED (no API key)";
        byte[] pcm = synth(c, "Testing.", voice);
        if (pcm != null && pcm.length > 0) return "OK (" + pcm.length / 2 + " samples, 24 kHz)";
        return "FAILED (" + (lastError.isEmpty() ? "no audio returned" : lastError) + ")";
    }

    private static AudioTrack openTrack() {
        int min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack t = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                .setBufferSizeInBytes(Math.max(min * 2, 48000))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        t.play();
        return t;
    }

    /** Writes PCM to the speaker in 40 ms slices, reporting the loudness so the hologram's mouth follows. */
    private static void play(AudioTrack t, byte[] pcm) {
        final int slice = RATE / 25 * 2; // 40 ms of 16-bit mono
        // short fade at both ends so chunks join without clicks
        fade(pcm);
        for (int off = 0; off < pcm.length && !cancelled; off += slice) {
            int n = Math.min(slice, pcm.length - off);
            t.write(pcm, off, n);
            Bus.Ui u = Bus.ui;
            if (u != null) u.onLevels(0, level(pcm, off, n));
        }
    }

    private static void fade(byte[] pcm) {
        int n = Math.min(48, pcm.length / 2 / 8);
        for (int i = 0; i < n; i++) {
            float g = i / (float) n;
            scale(pcm, i, g);
            scale(pcm, pcm.length / 2 - 1 - i, g);
        }
    }

    private static void scale(byte[] pcm, int sampleIndex, float g) {
        int s = (short) ((pcm[2 * sampleIndex] & 0xff) | (pcm[2 * sampleIndex + 1] << 8));
        s = Math.round(s * g);
        pcm[2 * sampleIndex] = (byte) (s & 0xff);
        pcm[2 * sampleIndex + 1] = (byte) ((s >> 8) & 0xff);
    }

    private static float level(byte[] pcm, int off, int len) {
        long sum = 0;
        int n = len / 2;
        if (n == 0) return 0f;
        for (int i = 0; i < n; i++) {
            int s = (short) ((pcm[off + 2 * i] & 0xff) | (pcm[off + 2 * i + 1] << 8));
            sum += (long) s * s;
        }
        double rms = Math.sqrt(sum / (double) n) / 32768.0;
        return (float) Math.min(1.0, rms * 4.0);
    }

    // ------------------------------------------------------------------ text -> audio

    private static List<String> split(String text) {
        List<String> out = new ArrayList<>();
        String clean = text == null ? "" : text.replaceAll("[*#`_~]", " ").replaceAll("[ \\t]+", " ").trim();
        if (clean.isEmpty()) return out;
        StringBuilder cur = new StringBuilder();
        for (String s : clean.split("(?<=[.!?।\\n])\\s*")) {
            if (s.trim().isEmpty()) continue;
            if (cur.length() > 0 && cur.length() + s.length() > 650) {
                out.add(cur.toString().trim());
                cur.setLength(0);
            }
            cur.append(s).append(' ');
        }
        if (cur.toString().trim().length() > 0) out.add(cur.toString().trim());
        return out;
    }

    private static Future<byte[]> fetch(final Context c, final String text, final String voice) {
        return POOL.submit(new Callable<byte[]>() {
            @Override
            public byte[] call() {
                return synth(c, text, voice);
            }
        });
    }

    private static byte[] synth(Context c, String text, String voice) {
        String key = Prefs.apiKey(c);
        JSONObject body = J.obj(
                "contents", J.arr(J.obj("parts", J.arr(J.obj("text", "Say this in a natural, warm, relaxed human voice, like a real person talking: " + text)))),
                "generationConfig", J.obj(
                        "responseModalities", J.arr("AUDIO"),
                        "speechConfig", J.obj("voiceConfig", J.obj("prebuiltVoiceConfig", J.obj("voiceName", voice)))));
        for (String model : MODELS) {
            if (cancelled) return null;
            try {
                Request req = new Request.Builder()
                        .url("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent?key=" + key)
                        .post(RequestBody.create(body.toString(), JSON))
                        .build();
                try (Response r = GeminiRest.HTTP.newCall(req).execute()) {
                    String txt = r.body() == null ? "" : r.body().string();
                    if (!r.isSuccessful()) {
                        lastError = "Gemini voice error " + r.code() + (r.code() == 429 ? " (free quota used up)" : "");
                        if (r.code() == 400 || r.code() == 401 || r.code() == 403) return null;
                        continue;
                    }
                    JSONArray cands = J.parse(txt).optJSONArray("candidates");
                    if (cands == null || cands.length() == 0) continue;
                    JSONObject content = cands.optJSONObject(0).optJSONObject("content");
                    JSONArray parts = content == null ? null : content.optJSONArray("parts");
                    if (parts == null) continue;
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    for (int i = 0; i < parts.length(); i++) {
                        JSONObject inl = parts.optJSONObject(i).optJSONObject("inlineData");
                        if (inl == null) inl = parts.optJSONObject(i).optJSONObject("inline_data");
                        if (inl != null && !inl.optString("data").isEmpty()) {
                            byte[] b = Base64.decode(inl.optString("data"), Base64.DEFAULT);
                            bo.write(b, 0, b.length);
                        }
                    }
                    if (bo.size() > 0) return bo.toByteArray();
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }
}
