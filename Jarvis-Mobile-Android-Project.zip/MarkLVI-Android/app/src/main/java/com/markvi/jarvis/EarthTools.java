package com.markvi.jarvis;

import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Voice tools for the Earth tab: open a place, distance between two places, live distance, where am I. All free services. */
public final class EarthTools {
    private EarthTools() {}

    static volatile Location fix;
    private static volatile boolean haveTarget;
    private static volatile double tLat, tLng;
    private static volatile String tName = "";

    private static final OkHttpClient HTTP = new OkHttpClient.Builder()
            .connectTimeout(6, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).callTimeout(10, TimeUnit.SECONDS).build();
    private static final String UA = "MiraAssistant/11 (personal Android app)";

    static void register() {
        reg("earth_open",
                "Opens the Earth tab (a 3D globe) and zooms to a place. Use when the user says 'open Earth', 'show X on Earth', 'distance from A to B' or "
                        + "'I am going to X, tell me the distance'. place = destination. from = starting place; leave empty to measure from the user's live GPS position. "
                        + "With place empty it just opens Earth on the user's location. Tell the user the distance_km out loud in their language.",
                schema("", "place:STRING:destination or place to show", "from:STRING:starting place, empty means the user's current location"),
                (c, a) -> open(c, a.optString("place").trim(), a.optString("from").trim()));

        reg("earth_distance_now",
                "Gives the live distance from the user's current GPS position to the last place opened on Earth. Use when the user asks 'how far now' or 'how much is left'.",
                schema(""),
                (c, a) -> {
                    if (!haveTarget) return J.fail("no destination is set; ask where they are going and call earth_open");
                    double[] me = userPos(c);
                    if (me == null) return J.fail("the phone location is not available; ask the user to turn Location on");
                    double km = haversine(me[0], me[1], tLat, tLng);
                    return J.ok("to", tName, "distance_km", round(km), "direction", compass(bearing(me[0], me[1], tLat, tLng)));
                });

        reg("earth_where_am_i",
                "Opens Earth zoomed to the user's current position and tells the address. Use for 'where am I' on the globe.",
                schema(""),
                (c, a) -> {
                    double[] me = userPos(c);
                    if (me == null) return J.fail("the phone location is not available; ask the user to turn Location on");
                    EarthActivity.send(c, J.obj("type", "me"));
                    String addr = reverse(me[0], me[1]);
                    return J.ok("lat", me[0], "lng", me[1], "address", addr == null ? "unknown" : addr);
                });

        reg("earth_view",
                "Switches the Earth tab view. mode: satellite (real photos), map (street map) or detail (satellite with sharp roads and 3D buildings, best for seeing buildings up close). Use when the user says detail view, show buildings, 3D buildings, map view or satellite view.",
                schema("", "mode:STRING:satellite, map or detail"),
                (c, a) -> {
                    String m = a.optString("mode").trim().toLowerCase(java.util.Locale.ROOT);
                    if (!m.equals("map") && !m.equals("detail")) m = "satellite";
                    EarthActivity.send(c, J.obj("type", "view", "mode", m));
                    return J.ok("mode", m);
                });

        reg("earth_close",
                "Closes the Earth tab.",
                schema(""),
                (c, a) -> {
                    EarthActivity.closeIfOpen();
                    return J.ok();
                });
    }

    // ------------------------------------------------------------------ main action

    private static JSONObject open(Context c, String place, String from) throws Exception {
        double[] me = userPos(c);
        if (place.isEmpty()) {
            EarthActivity.send(c, J.obj("type", "me"));
            return J.ok("note", me == null ? "Earth opened; the phone location is not available yet (turn Location on)" : "Earth opened on the user's location");
        }
        JSONObject to = geocode(place);
        if (to == null) return J.fail("could not find '" + place + "' on the map; ask for the name again or a bigger nearby place");

        JSONObject start;
        boolean live = false;
        if (!from.isEmpty()) {
            start = geocode(from);
            if (start == null) return J.fail("could not find '" + from + "' on the map");
        } else if (me != null) {
            start = J.obj("lat", me[0], "lng", me[1], "name", "You");
            live = true;
        } else {
            // no GPS: just show the place
            EarthActivity.send(c, J.obj("type", "goto", "lat", to.optDouble("lat"), "lng", to.optDouble("lng"), "name", place));
            tLat = to.optDouble("lat");
            tLng = to.optDouble("lng");
            tName = place;
            haveTarget = true;
            return J.ok("place", place, "note", "shown on Earth; the phone location is not available, so no distance from the user (turn Location on)");
        }

        double sLat = start.optDouble("lat"), sLng = start.optDouble("lng");
        double dLat = to.optDouble("lat"), dLng = to.optDouble("lng");
        double km = haversine(sLat, sLng, dLat, dLng);
        String dir = compass(bearing(sLat, sLng, dLat, dLng));

        double roadKm = -1;
        long roadMin = -1;
        try {
            Request rq = new Request.Builder().header("User-Agent", UA).url("https://router.project-osrm.org/route/v1/driving/"
                    + sLng + "," + sLat + ";" + dLng + "," + dLat + "?overview=false").build();
            try (Response r = HTTP.newCall(rq).execute()) {
                if (r.isSuccessful() && r.body() != null) {
                    JSONObject j = new JSONObject(r.body().string());
                    JSONArray routes = j.optJSONArray("routes");
                    if (routes != null && routes.length() > 0) {
                        roadKm = routes.getJSONObject(0).optDouble("distance") / 1000.0;
                        roadMin = Math.round(routes.getJSONObject(0).optDouble("duration") / 60.0);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        String road = roadKm > 0 ? Math.round(roadKm) + " km, about " + durationText(roadMin) : "";

        String fromName = live ? "You" : from;
        EarthActivity.send(c, J.obj("type", "route",
                "from", J.obj("lat", sLat, "lng", sLng, "name", fromName),
                "to", J.obj("lat", dLat, "lng", dLng, "name", place),
                "live", live, "road", road));
        tLat = dLat;
        tLng = dLng;
        tName = place;
        haveTarget = true;

        JSONObject out = J.ok("from", live ? "your current location" : from, "to", place, "distance_km", round(km), "direction", dir);
        if (roadKm > 0) {
            J.put(out, "road_km", Math.round(roadKm));
            J.put(out, "road_time", durationText(roadMin));
        }
        J.put(out, "note", "distance_km is straight-line (as the crow flies); road_km is by road when present");
        return out;
    }

    // ------------------------------------------------------------------ helpers

    /** The user's position: the newest GPS fix the Earth tab saw, else the phone's last known location. */
    static double[] userPos(Context c) {
        Location f = fix;
        if (f != null && System.currentTimeMillis() - f.getTime() < 10 * 60 * 1000L) return new double[]{f.getLatitude(), f.getLongitude()};
        try {
            if (c.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && c.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return f == null ? null : new double[]{f.getLatitude(), f.getLongitude()};
            }
            LocationManager lm = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
            Location best = f;
            for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER}) {
                try {
                    Location l = lm.getLastKnownLocation(p);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (Exception ignored) {
                }
            }
            return best == null ? null : new double[]{best.getLatitude(), best.getLongitude()};
        } catch (Throwable t) {
            return null;
        }
    }

    /** Free OpenStreetMap Nominatim search. Returns {lat, lng, name} or null. */
    private static JSONObject geocode(String q) {
        try {
            Request rq = new Request.Builder().header("User-Agent", UA)
                    .url("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&accept-language=en&q=" + URLEncoder.encode(q, "UTF-8")).build();
            try (Response r = HTTP.newCall(rq).execute()) {
                if (!r.isSuccessful() || r.body() == null) return null;
                JSONArray a = new JSONArray(r.body().string());
                if (a.length() == 0) return null;
                JSONObject o = a.getJSONObject(0);
                return J.obj("lat", Double.parseDouble(o.getString("lat")), "lng", Double.parseDouble(o.getString("lon")),
                        "name", o.optString("display_name", q));
            }
        } catch (Throwable t) {
            DebugLog.add("Geocode failed for '" + q + "': " + t);
            return null;
        }
    }

    private static String reverse(double lat, double lng) {
        try {
            Request rq = new Request.Builder().header("User-Agent", UA)
                    .url("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=16&accept-language=en&lat=" + lat + "&lon=" + lng).build();
            try (Response r = HTTP.newCall(rq).execute()) {
                if (!r.isSuccessful() || r.body() == null) return null;
                return new JSONObject(r.body().string()).optString("display_name", null);
            }
        } catch (Throwable t) {
            return null;
        }
    }

    static double haversine(double lat1, double lng1, double lat2, double lng2) {
        double r = 6371.0088;
        double dLat = Math.toRadians(lat2 - lat1), dLng = Math.toRadians(lng2 - lng1);
        double s = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return 2 * r * Math.asin(Math.min(1.0, Math.sqrt(s)));
    }

    static double bearing(double lat1, double lng1, double lat2, double lng2) {
        double y = Math.sin(Math.toRadians(lng2 - lng1)) * Math.cos(Math.toRadians(lat2));
        double x = Math.cos(Math.toRadians(lat1)) * Math.sin(Math.toRadians(lat2))
                - Math.sin(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.cos(Math.toRadians(lng2 - lng1));
        return (Math.toDegrees(Math.atan2(y, x)) + 360.0) % 360.0;
    }

    static String compass(double b) {
        String[] d = {"north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"};
        return d[(int) Math.round(b / 45.0) % 8];
    }

    private static double round(double km) {
        return km < 100 ? Math.round(km * 10.0) / 10.0 : (double) Math.round(km);
    }

    private static String durationText(long min) {
        if (min < 60) return min + " min";
        return String.format(Locale.US, "%d h %d min", min / 60, min % 60);
    }
}
