package com.markvi.jarvis;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Backup and restore of Mira's settings, memory, expenses, reminders and Serious-mode history list. One JSON file in Downloads. */
public final class Backup {
    private Backup() {}

    /** Set by the voice tools; the HUD page picks it up (it owns the localStorage part) and does the job. */
    public static volatile String pending = null;

    private static boolean secret(String k) {
        String l = k.toLowerCase(Locale.ROOT);
        return l.contains("api_key") || l.equals("custom_key") || l.contains("secret") || l.contains("token");
    }

    /** Writes the backup file and returns its path. localJson is a JSON object of the page's localStorage. */
    public static String export(Context c, String localJson, boolean withKeys) throws Exception {
        JSONObject root = new JSONObject();
        root.put("app", "mira");
        root.put("version", 1);
        root.put("created", System.currentTimeMillis());
        root.put("with_keys", withKeys);
        JSONObject prefs = new JSONObject();
        for (Map.Entry<String, ?> e : Prefs.sp(c).getAll().entrySet()) {
            String k = e.getKey();
            Object v = e.getValue();
            if (v == null || (!withKeys && secret(k))) continue;
            if (k.equals("daily_seen")) continue; // rebuilt automatically
            String t = v instanceof Boolean ? "b" : v instanceof Integer ? "i" : v instanceof Long ? "l" : v instanceof Float ? "f" : "s";
            prefs.put(k, J.obj("t", t, "v", v instanceof java.util.Set ? v.toString() : v));
        }
        root.put("prefs", prefs);
        JSONObject local = new JSONObject();
        try {
            if (localJson != null && !localJson.isEmpty()) local = new JSONObject(localJson);
        } catch (Exception ignored) {
        }
        if (!withKeys) {
            java.util.Iterator<String> it = local.keys();
            java.util.List<String> drop = new java.util.ArrayList<>();
            while (it.hasNext()) {
                String k = it.next();
                if (secret(k)) drop.add(k);
            }
            for (String k : drop) local.remove(k);
        }
        root.put("local", local);
        File idx = new File(c.getFilesDir(), "serious_index.json");
        if (idx.exists()) root.put("serious_index", readAll(idx));
        String name = "Mira-backup-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date()) + ".json";
        File f = new File(SeriousMode.root(), name);
        SeriousMode.root().mkdirs();
        try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) {
            o.write(root.toString().getBytes("UTF-8"));
        }
        return f.getAbsolutePath();
    }

    /** Applies the newest backup in Downloads. Returns {ok, file, prefs, local(json string)} for the page to apply localStorage. */
    public static JSONObject restore(Context c) {
        try {
            File[] all = SeriousMode.root().listFiles();
            File best = null;
            if (all != null) {
                for (File f : all) {
                    if (f.getName().startsWith("Mira-backup-") && f.getName().endsWith(".json") && (best == null || f.lastModified() > best.lastModified())) best = f;
                }
            }
            if (best == null) return J.fail("no Mira-backup-*.json file found in Downloads");
            JSONObject root = new JSONObject(readAll(best));
            if (!"mira".equals(root.optString("app"))) return J.fail("that file is not a Mira backup");
            JSONObject prefs = root.optJSONObject("prefs");
            SharedPreferences.Editor ed = Prefs.sp(c).edit();
            int n = 0;
            if (prefs != null) {
                java.util.Iterator<String> it = prefs.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    JSONObject o = prefs.optJSONObject(k);
                    if (o == null) continue;
                    String t = o.optString("t");
                    if (t.equals("b")) ed.putBoolean(k, o.optBoolean("v"));
                    else if (t.equals("i")) ed.putInt(k, o.optInt("v"));
                    else if (t.equals("l")) ed.putLong(k, o.optLong("v"));
                    else if (t.equals("f")) ed.putFloat(k, (float) o.optDouble("v"));
                    else ed.putString(k, o.optString("v"));
                    n++;
                }
            }
            ed.apply();
            String idx = root.optString("serious_index", "");
            if (!idx.isEmpty()) {
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(new File(c.getFilesDir(), "serious_index.json"))) {
                    o.write(idx.getBytes("UTF-8"));
                }
            }
            DailyLeads.schedule(c);
            ToolsCore.rescheduleAll(c);
            JSONObject local = root.optJSONObject("local");
            return J.obj("ok", true, "file", best.getAbsolutePath(), "prefs", n, "local", local == null ? "{}" : local.toString());
        } catch (Exception e) {
            return J.fail("restore failed: " + e.getMessage());
        }
    }

    private static String readAll(File f) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        try (FileInputStream in = new FileInputStream(f)) {
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
        }
        return bo.toString("UTF-8");
    }

    static void registerTools() {
        reg("backup_data",
                "Saves a backup file of Mira's settings, memories, expenses, reminders and serious-mode history to Downloads (Mira-backup-DATE.json). "
                        + "Only when the user asks. API keys are left out unless the user says to include them. Mira's screen must be open.",
                schema("include_keys", "include_keys:BOOLEAN:true only if the user asked to include API keys"),
                (c, a) -> {
                    pending = a.optBoolean("include_keys", false) ? "backup_keys" : "backup";
                    return J.ok("note", "backup is running on the Mira screen; the file will appear in Downloads");
                });
        reg("restore_data",
                "Restores the newest Mira-backup file from Downloads over the current settings. Only when the user clearly asks. The user approves on screen first.",
                schema(""),
                (c, a) -> {
                    if (!Bus.confirm("Restore Mira from the newest backup in Downloads? Current settings and memories will be replaced.")) {
                        return J.obj("status", "declined", "note", "the user did not approve");
                    }
                    pending = "restore";
                    return J.ok("note", "restoring on the Mira screen; the app will reload");
                });
    }
}
