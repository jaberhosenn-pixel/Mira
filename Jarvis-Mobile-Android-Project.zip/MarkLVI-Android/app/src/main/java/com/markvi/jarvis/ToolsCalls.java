package com.markvi.jarvis;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/** Incoming call helpers: who is calling, answer, decline, "I'm busy" by SMS/WhatsApp, and Mira's voice played into a call. Only on the user's command. */
final class ToolsCalls {
    private ToolsCalls() {}

    static final String BUSY_TEXT_BN = "আমি মীরা, ওনার ডিজিটাল সহকারী। উনি এখন একটু ব্যস্ত আছেন, পরে আপনাকে ফোন করবেন।";
    static final String BUSY_SMS_BN = "আমি এখন একটু ব্যস্ত আছি, পরে আপনাকে ফোন করবো।";

    static void register() {
        reg("incoming_call",
                "Tells who is calling right now (name from contacts and number), or says no call is ringing. Also checks for a WhatsApp call notification. "
                        + "Use when the user asks who is calling or before answering.",
                schema(""), (c, a) -> incoming(c));

        reg("answer_call",
                "Answers the ringing phone call (normal phone calls, not WhatsApp). speaker=true puts it on loudspeaker.",
                schema("", "speaker:BOOLEAN:true to use the loudspeaker"),
                (c, a) -> {
                    JSONObject chk = needReady(c, true);
                    if (chk != null) return chk;
                    tm(c).acceptRingingCall();
                    if (a.optBoolean("speaker", false)) {
                        waitState(c, TelephonyManager.EXTRA_STATE_OFFHOOK, 4000);
                        audio(c).setSpeakerphoneOn(true);
                    }
                    return J.ok("note", "call answered");
                });

        reg("reject_call",
                "Declines / ends the ringing or current phone call (normal phone calls, not WhatsApp).",
                schema(""),
                (c, a) -> {
                    JSONObject chk = needReady(c, false);
                    if (chk != null) return chk;
                    if (!hangUp(c)) return J.fail("this phone version cannot end calls from an app (needs Android 9 or newer)");
                    return J.ok("note", "call ended");
                });

        reg("decline_with_message",
                "Declines the ringing call (or uses the last caller within 10 minutes) and sends them a short 'I am busy' message by SMS or WhatsApp. "
                        + "Only when the user asks. text defaults to a polite Bangla busy message.",
                schema("", "text:STRING:the message, in the user's language",
                        "platform:STRING:sms (default) | whatsapp"),
                (c, a) -> declineWithMessage(c, a));

        reg("answer_and_say_busy",
                "Answers the ringing phone call, plays Mira's voice saying the user is busy (through the loudspeaker so the caller hears it through the "
                        + "phone's microphone) and then hangs up. Normal phone calls only. Only when the user asks. text is optional.",
                schema("", "text:STRING:what Mira says; default is a polite Bangla line saying she is the user's assistant and the user is busy",
                        "hang_up:BOOLEAN:hang up afterwards (default true)",
                        "repeat:INTEGER:how many times to say it (default 2, max 3)"),
                (c, a) -> answerAndSayBusy(c, a));

        reg("call_log_recent",
                "Lists the latest phone calls (incoming, missed, outgoing) with name, number, time and duration. Use for 'who called me', 'missed calls'. "
                        + "kind: all | missed | incoming | outgoing.",
                schema("", "kind:STRING:all (default) | missed | incoming | outgoing", "count:INTEGER:how many, default 10, max 30"),
                (c, a) -> {
                    if (!has(c, Manifest.permission.READ_CALL_LOG)) return J.fail("Call log permission is missing. Allow 'Call log' in Mira's All Permissions page.");
                    String kind = a.optString("kind", "all").toLowerCase(Locale.ROOT);
                    int max = Math.max(1, Math.min(30, a.optInt("count", 10)));
                    JSONArray out = new JSONArray();
                    java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
                    try (Cursor cur = c.getContentResolver().query(android.provider.CallLog.Calls.CONTENT_URI,
                            new String[]{android.provider.CallLog.Calls.NUMBER, android.provider.CallLog.Calls.DATE, android.provider.CallLog.Calls.TYPE,
                                    android.provider.CallLog.Calls.DURATION}, null, null, android.provider.CallLog.Calls.DATE + " DESC")) {
                        while (cur != null && cur.moveToNext() && out.length() < max) {
                            int t = cur.getInt(2);
                            String tn = t == android.provider.CallLog.Calls.MISSED_TYPE ? "missed" : t == android.provider.CallLog.Calls.INCOMING_TYPE ? "incoming"
                                    : t == android.provider.CallLog.Calls.OUTGOING_TYPE ? "outgoing" : t == android.provider.CallLog.Calls.REJECTED_TYPE ? "rejected" : "other";
                            if (!kind.equals("all") && !tn.equals(kind) && !(kind.equals("missed") && tn.equals("rejected"))) continue;
                            String num = cur.getString(0) == null ? "" : cur.getString(0);
                            String nm = nameFor(c, num);
                            out.put(J.obj("type", tn, "name", nm.isEmpty() ? "not in contacts" : nm, "number", num.isEmpty() ? "hidden" : num,
                                    "time", f.format(new java.util.Date(cur.getLong(1))), "seconds", cur.getInt(3)));
                        }
                    } catch (Exception e) {
                        return J.fail("could not read the call log: " + e.getMessage());
                    }
                    return J.ok("count", out.length(), "calls", out);
                });

        reg("whatsapp_call_action",
                "Answers or declines a ringing WhatsApp call by tapping its button on screen. Needs Accessibility, an unlocked screen with the call notification showing. "
                        + "Not reliable, tell the user so.",
                schema("action", "action:STRING:answer | decline"),
                (c, a) -> {
                    if (JarvisAccessibility.get() == null) return J.fail("Accessibility is off");
                    boolean ans = "answer".equalsIgnoreCase(a.optString("action"));
                    ArrayList<String> labels = new ArrayList<>(ans ? Arrays.asList("Answer", "Accept", "Pick up") : Arrays.asList("Decline", "Reject", "Dismiss"));
                    boolean ok = JarvisAccessibility.tapAnyTextWithin(labels, 3500);
                    return ok ? J.obj("status", "unverified", "note", "button tapped") : J.fail("could not find the button on screen (screen locked or call banner gone)");
                });
    }

    // ------------------------------------------------------------------ helpers

    private static TelecomManager tm(Context c) {
        return (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
    }

    private static AudioManager audio(Context c) {
        return (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
    }

    /** Live call state straight from the phone; falls back to what the broadcast receiver last saw. */
    static String callState(Context c) {
        try {
            int st = ((TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE)).getCallState();
            if (st == TelephonyManager.CALL_STATE_RINGING) return TelephonyManager.EXTRA_STATE_RINGING;
            if (st == TelephonyManager.CALL_STATE_OFFHOOK) return TelephonyManager.EXTRA_STATE_OFFHOOK;
            return TelephonyManager.EXTRA_STATE_IDLE;
        } catch (Throwable t) {
            return CallReceiver.state;
        }
    }

    /** Number of the current or latest caller: from the broadcast, else from the call log (calls that just ended). */
    static String callerNumber(Context c) {
        if (!CallReceiver.number.isEmpty() && System.currentTimeMillis() - CallReceiver.ringTime < 600000L) return CallReceiver.number;
        if (!has(c, Manifest.permission.READ_CALL_LOG)) return "";
        try (Cursor cur = c.getContentResolver().query(android.provider.CallLog.Calls.CONTENT_URI,
                new String[]{android.provider.CallLog.Calls.NUMBER, android.provider.CallLog.Calls.DATE, android.provider.CallLog.Calls.TYPE},
                android.provider.CallLog.Calls.DATE + " > ?", new String[]{String.valueOf(System.currentTimeMillis() - 600000L)},
                android.provider.CallLog.Calls.DATE + " DESC")) {
            while (cur != null && cur.moveToNext()) {
                int type = cur.getInt(2);
                if (type == android.provider.CallLog.Calls.INCOMING_TYPE || type == android.provider.CallLog.Calls.MISSED_TYPE
                        || type == android.provider.CallLog.Calls.REJECTED_TYPE) {
                    String n = cur.getString(0);
                    if (n != null && !n.isEmpty()) return n;
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static boolean has(Context c, String p) {
        return c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private static JSONObject needReady(Context c, boolean mustRing) {
        if (!has(c, Manifest.permission.ANSWER_PHONE_CALLS)) {
            return J.fail("Phone-call permission is missing. Open Settings > Permissions in Mira and allow 'Answer calls'.");
        }
        if (mustRing && !TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c))) return J.fail("no phone call is ringing right now");
        return null;
    }

    private static void waitState(Context c, String want, long ms) {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end && !want.equals(callState(c))) {
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    @SuppressWarnings("deprecation")
    private static boolean hangUp(Context c) {
        if (Build.VERSION.SDK_INT < 28) return false;
        return tm(c).endCall();
    }

    static String nameFor(Context c, String number) {
        if (number == null || number.isEmpty() || !has(c, Manifest.permission.READ_CONTACTS)) return "";
        try (Cursor cur = c.getContentResolver().query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) return cur.getString(0);
        } catch (Exception ignored) {
        }
        return "";
    }

    private static JSONObject incoming(Context c) {
        JSONObject out = new JSONObject();
        boolean ringing = TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c));
        J.put(out, "status", "done");
        J.put(out, "phone_call_ringing", ringing);
        if (ringing || System.currentTimeMillis() - CallReceiver.ringTime < 600000 || !callerNumber(c).isEmpty()) {
            String n = callerNumber(c);
            J.put(out, ringing ? "number" : "last_caller_number", n.isEmpty() ? "hidden or not available" : n);
            String name = nameFor(c, n);
            J.put(out, ringing ? "name" : "last_caller_name", name.isEmpty() ? "not in contacts" : name);
        }
        if (!has(c, Manifest.permission.READ_CALL_LOG) || !has(c, Manifest.permission.READ_PHONE_STATE)) {
            J.put(out, "warning", "the caller number may be missing: allow 'Call log' and 'Phone state' in Mira's permission page");
        }
        try {
            JSONArray all = new JSONArray(NotifCatcher.json());
            for (int i = 0; i < all.length(); i++) {
                JSONObject o = all.getJSONObject(i);
                String app = o.optString("app").toLowerCase(Locale.ROOT);
                String txt = (o.optString("desc") + " " + o.optString("sender")).toLowerCase(Locale.ROOT);
                if (app.contains("whatsapp") && (txt.contains("incoming") && txt.contains("call"))) {
                    J.put(out, "whatsapp_call_notification", o.optString("sender") + " at " + o.optString("time") + " (may already be over)");
                    break;
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private static JSONObject declineWithMessage(Context c, JSONObject a) throws Exception {
        boolean ringing = TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c));
        String number = callerNumber(c);
        if (!ringing && number.isEmpty()) return J.fail("no recent call to answer with a message");
        if (number.isEmpty()) return J.fail("the caller's number is hidden or not available (check Call log permission)");
        String text = a.optString("text").trim();
        if (text.isEmpty()) text = BUSY_SMS_BN;
        String platform = a.optString("platform", "sms").toLowerCase(Locale.ROOT);
        String who = nameFor(c, number);
        if (ringing && has(c, Manifest.permission.ANSWER_PHONE_CALLS)) hangUp(c);
        if (platform.equals("whatsapp")) {
            JSONObject r = Tools.dispatch(c, "send_message", J.obj("receiver", number, "message_text", text, "platform", "whatsapp"));
            J.put(r, "to", who.isEmpty() ? number : who);
            return r;
        }
        if (!has(c, Manifest.permission.SEND_SMS)) return J.fail("SMS permission is missing");
        SmsManager sm = Build.VERSION.SDK_INT >= 31 ? c.getSystemService(SmsManager.class) : SmsManager.getDefault();
        sm.sendMultipartTextMessage(number, null, sm.divideMessage(text), null, null);
        return J.obj("status", "unverified", "to", who.isEmpty() ? number : who, "note", "call declined and SMS handed to the network; delivery cannot be confirmed");
    }

    private static JSONObject answerAndSayBusy(Context c, JSONObject a) throws Exception {
        JSONObject chk = needReady(c, true);
        if (chk != null) return chk;
        String text = a.optString("text").trim();
        if (text.isEmpty()) text = BUSY_TEXT_BN;
        // make the voice first, while the phone is still ringing, so there is no silence after answering
        byte[] pcm = VoiceTts.render(c, text, Prefs.voice(c));
        if (pcm == null) {
            return J.fail("could not prepare Mira's voice (" + VoiceTts.lastError + "). The call was NOT answered; use decline_with_message instead.");
        }
        if (!TelephonyManager.EXTRA_STATE_RINGING.equals(callState(c))) return J.fail("the call stopped ringing");
        AudioManager am = audio(c);
        int oldVol = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        boolean oldSpeaker = am.isSpeakerphoneOn();
        tm(c).acceptRingingCall();
        try {
            waitState(c, TelephonyManager.EXTRA_STATE_OFFHOOK, 5000);
            if (!TelephonyManager.EXTRA_STATE_OFFHOOK.equals(callState(c))) return J.fail("could not answer the call");
            am.setSpeakerphoneOn(true);
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
            Thread.sleep(900); // let the line connect
            int times = Math.max(1, Math.min(3, a.optInt("repeat", 2)));
            for (int k = 0; k < times; k++) {
                if (!TelephonyManager.EXTRA_STATE_OFFHOOK.equals(callState(c))) break; // caller already hung up
                VoiceTts.playPcm(pcm);
                Thread.sleep(900);
            }
        } finally {
            try {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, oldVol, 0);
                am.setSpeakerphoneOn(oldSpeaker);
            } catch (Exception ignored) {
            }
        }
        boolean hang = a.optBoolean("hang_up", true);
        if (hang) hangUp(c);
        return J.obj("status", "unverified", "note", "Mira's voice was played through the speaker" + (hang ? " and the call was ended" : "")
                + "; whether the caller heard it clearly depends on the phone, nobody can confirm");
    }
}
