package com.markvi.jarvis;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import org.json.JSONObject;
import org.vosk.LibVosk;
import org.vosk.LogLevel;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;

import okhttp3.Request;
import okhttp3.Response;

/** Always-on "Hey Mira" / "Hey Jarvis" listener. Runs fully on the phone (Vosk), free, no account. */
public final class WakeEngine {
    private WakeEngine() {}

    private static final String[] MODEL_URLS = {
            "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
            "https://huggingface.co/rhasspy/vosk-models/resolve/main/en/vosk-model-small-en-us-0.15.zip"};

    private static volatile boolean running;
    /** Consecutive failed starts; the service backs off instead of blinking the microphone every few seconds. */
    static volatile int fails;
    private static Thread thread;

    public static File modelDir(Context c) {
        return new File(c.getFilesDir(), "vosk-model");
    }

    public static boolean hasModel(Context c) {
        return new File(modelDir(c), ".ok").exists();
    }

    public static boolean isRunning() {
        return running || fbRunning;
    }

    // ---- fallback: the phone's own speech recognizer, used until / unless the Vosk model is downloaded
    private static volatile boolean fbRunning;
    private static SpeechRecognizer sr;
    private static Handler fbH;

    public static boolean fallbackRunning() {
        return fbRunning;
    }

    public static void startFallback(final Context ctx, final Runnable onWake) {
        if (fbRunning) return;
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            DebugLog.add("Wake fallback: no speech recognizer on this phone");
            return;
        }
        fbRunning = true;
        fbH = new Handler(Looper.getMainLooper());
        DebugLog.add("Wake fallback: using the phone's own speech recognizer");
        fbH.post(() -> fbListen(ctx.getApplicationContext(), onWake));
    }

    public static void stopFallback() {
        fbRunning = false;
        if (fbH != null) fbH.post(() -> {
            try {
                if (sr != null) {
                    sr.destroy();
                    sr = null;
                }
            } catch (Throwable ignored) {
            }
        });
    }

    private static void fbListen(final Context ctx, final Runnable onWake) {
        if (!fbRunning) return;
        try {
            if (sr != null) sr.destroy();
            sr = SpeechRecognizer.createSpeechRecognizer(ctx);
            sr.setRecognitionListener(new RecognitionListener() {
                private void check(Bundle b, boolean fin) {
                    ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (l == null) return;
                    for (String t : l) {
                        String said = t.toLowerCase(Locale.ROOT);
                        if (fin) Bus.log("HEARD: " + said);
                        if (matches(said)) {
                            fbRunning = false;
                            try {
                                sr.destroy();
                            } catch (Throwable ignored) {
                            }
                            sr = null;
                            onWake.run();
                            return;
                        }
                    }
                }

                @Override public void onReadyForSpeech(Bundle p) {}
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float v) {}
                @Override public void onBufferReceived(byte[] b) {}
                @Override public void onEndOfSpeech() {}
                @Override public void onEvent(int t, Bundle b) {}

                @Override
                public void onError(int e) {
                    if (fbRunning) fbH.postDelayed(() -> fbListen(ctx, onWake), e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500 : 400);
                }

                @Override
                public void onResults(Bundle b) {
                    check(b, true);
                    if (fbRunning) fbH.postDelayed(() -> fbListen(ctx, onWake), 250);
                }

                @Override
                public void onPartialResults(Bundle b) {
                    check(b, false);
                }
            });
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
            sr.startListening(i);
        } catch (Throwable t) {
            DebugLog.add("Wake fallback error: " + t);
            if (fbRunning) fbH.postDelayed(() -> fbListen(ctx, onWake), 2000);
        }
    }

    /** Downloads and unpacks the small English speech model (about 40 MB) once. */
    public static synchronized void downloadModel(Context c) throws Exception {
        if (hasModel(c)) return;
        Exception last = null;
        for (int attempt = 0; attempt < 4; attempt++) {
            String url = MODEL_URLS[attempt % MODEL_URLS.length];
            try {
                DebugLog.add("Wake model: download try " + (attempt + 1) + " from " + url.substring(8, url.indexOf('/', 8)));
                fetch(c, url);
                DebugLog.add("Wake model: downloaded and unpacked");
                return;
            } catch (Exception e) {
                last = e;
                DebugLog.add("Wake model: try " + (attempt + 1) + " failed: " + e);
                try {
                    Thread.sleep(1500);
                } catch (InterruptedException ignored) {
                }
            }
        }
        throw last == null ? new Exception("download failed") : last;
    }

    private static void fetch(Context c, String url) throws Exception {
        File dir = modelDir(c);
        deleteRec(dir);
        dir.mkdirs();
        Request req = new Request.Builder().url(url).build();
        try (Response r = GeminiRest.HTTP.newBuilder().readTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
                .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS).build().newCall(req).execute()) {
            if (!r.isSuccessful() || r.body() == null) throw new Exception("HTTP " + r.code());
            try (InputStream in = r.body().byteStream(); ZipInputStream z = new ZipInputStream(in)) {
                ZipEntry e;
                byte[] buf = new byte[65536];
                while ((e = z.getNextEntry()) != null) {
                    String name = e.getName();
                    int slash = name.indexOf('/');
                    String rel = slash >= 0 ? name.substring(slash + 1) : name; // drop the top folder
                    if (rel.isEmpty()) continue;
                    File out = new File(dir, rel);
                    if (!out.getCanonicalPath().startsWith(dir.getCanonicalPath())) continue;
                    if (e.isDirectory()) {
                        out.mkdirs();
                        continue;
                    }
                    if (out.getParentFile() != null) out.getParentFile().mkdirs();
                    try (FileOutputStream fo = new FileOutputStream(out)) {
                        int n;
                        while ((n = z.read(buf)) > 0) fo.write(buf, 0, n);
                    }
                }
            }
        }
        if (!new File(dir, "am").exists()) {
            deleteRec(dir);
            throw new Exception("speech model was not unpacked correctly");
        }
        new File(dir, ".ok").createNewFile();
    }

    private static void deleteRec(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRec(k);
        f.delete();
    }

    public static synchronized void start(final Context ctx, final Runnable onWake) {
        if (running) return;
        running = true;
        thread = new Thread(() -> {
            Model model = null;
            Recognizer rec = null;
            AudioRecord ar = null;
            boolean fired = false;
            try {
                LibVosk.setLogLevel(LogLevel.WARNINGS);
                model = new Model(modelDir(ctx).getAbsolutePath());
                rec = new Recognizer(model, 16000.0f);
                int buf = Math.max(AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT), 8192);
                ar = new AudioRecord(MediaRecorder.AudioSource.MIC, 16000,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf * 2);
                if (ar.getState() != AudioRecord.STATE_INITIALIZED) throw new Exception("microphone is busy or not allowed");
                ar.startRecording();
                fails = 0;
                Bus.log("Wake: listening for Hey Mira / Hey Jarvis");
                short[] b = new short[2000];
                String lastShown = "";
                int bad = 0;
                while (running) {
                    int n = ar.read(b, 0, b.length);
                    if (n < 0) {
                        if (++bad > 25) throw new Exception("microphone read error " + n);
                        try {
                            Thread.sleep(20);
                        } catch (InterruptedException ignored) {
                        }
                        continue;
                    }
                    bad = 0;
                    if (n == 0) continue;
                    for (int i = 0; i < n; i++) {
                        int v = b[i] * 2; // a little extra gain helps quiet voices
                        b[i] = (short) Math.max(-32768, Math.min(32767, v));
                    }
                    boolean fin = rec.acceptWaveForm(b, n);
                    String json = fin ? rec.getResult() : rec.getPartialResult();
                    String said = said(json);
                    if (fin && !said.isEmpty()) Bus.log("HEARD: " + said);
                    else if (!said.isEmpty() && !said.equals(lastShown)) {
                        lastShown = said;
                        Bus.Ui u = Bus.ui;
                        if (u != null) u.onLog("Wake hears: " + said);
                    }
                    if (matches(said)) {
                        fired = true;
                        break;
                    }
                }
            } catch (Throwable t) {
                Bus.log("Wake word error: " + t);
                fails++;
                if (t.getMessage() != null && t.getMessage().toLowerCase(Locale.ROOT).contains("model")) {
                    deleteRec(modelDir(ctx)); // broken download: fetch it again next time
                }
            } finally {
                running = false;
                try {
                    if (ar != null) {
                        ar.stop();
                        ar.release();
                    }
                } catch (Exception ignored) {
                }
                try {
                    if (rec != null) rec.close();
                    if (model != null) model.close();
                } catch (Throwable ignored) {
                }
            }
            if (fired) onWake.run();
        }, "mira-wake");
        thread.setDaemon(true);
        thread.start();
    }

    public static void stop() {
        stopFallback();
        running = false;
        Thread t = thread;
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(2000);
            } catch (InterruptedException ignored) {
            }
        }
    }

    private static String said(String json) {
        if (json == null) return "";
        try {
            JSONObject o = new JSONObject(json);
            return (o.optString("partial") + " " + o.optString("text")).toLowerCase(Locale.ROOT).trim();
        } catch (Exception e) {
            return "";
        }
    }

    private static final String[] HEY = {"hey", "hay", "hi", "hello", "okay", "ok", "a", "he", "hate"};
    private static final String[] NAMES = {"mira", "meera", "mirror", "mia", "maria", "mirah", "mera", "mara", "mirra",
            "miller", "murray", "mere", "jarvis", "jarvish", "jarvas", "service", "jervis", "javis", "jarves"};

    /**
     * Fuzzy: "hey" + something that sounds like Mira / Jarvis, or just the name on its own. The small speech model does not
     * know the word "Mira", so it often splits it ("me ra", "my ra") or mishears it; those are joined and compared too.
     */
    static boolean matches(String said) {
        if (said == null || said.isEmpty()) return false;
        String[] w = said.replaceAll("[^a-z ]", " ").trim().split("\\s+");
        for (int i = 0; i < w.length; i++) {
            if (isName(w[i], true)) return true; // the name alone is enough (strong, not shy)
            if (i + 1 < w.length && isName(w[i] + w[i + 1], true)) return true;
            if (i + 1 < w.length && in(HEY, w[i])) {
                if (isName(w[i + 1], false)) return true;
                if (isName(w[i + 1] + (i + 2 < w.length ? w[i + 2] : ""), false)) return true;
                if (isName(w[i + 1] + (i + 2 < w.length ? w[i + 2] : ""), true)) return true;
            }
        }
        return false;
    }

    private static boolean in(String[] arr, String x) {
        for (String a : arr) if (a.equals(x)) return true;
        return false;
    }

    private static boolean isName(String w, boolean alone) {
        if (w.length() < 3) return false;
        if (alone) {
            return w.equals("mira") || w.equals("meera") || w.equals("jarvis") || w.equals("jarvish") || w.equals("jervis")
                    || w.equals("myra") || w.equals("mera") || w.equals("mirror") || w.equals("jarves") || w.equals("service");
        }
        if (in(NAMES, w)) return true;
        return lev(w, "mira") <= 1 || lev(w, "jarvis") <= 1;
    }

    private static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }
}
