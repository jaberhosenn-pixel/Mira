package com.markvi.jarvis;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import org.json.JSONObject;
import org.vosk.LibVosk;
import org.vosk.LogLevel;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import okhttp3.Request;
import okhttp3.Response;

/** Always-on "Hey Mira" / "Hey Jarvis" listener. Runs fully on the phone (Vosk), free, no account. */
public final class WakeEngine {
    private WakeEngine() {}

    private static final String MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip";

    private static volatile boolean running;
    private static Thread thread;

    public static File modelDir(Context c) {
        return new File(c.getFilesDir(), "vosk-model");
    }

    public static boolean hasModel(Context c) {
        return new File(modelDir(c), ".ok").exists();
    }

    public static boolean isRunning() {
        return running;
    }

    /** Downloads and unpacks the small English speech model (about 40 MB) once. */
    public static synchronized void downloadModel(Context c) throws Exception {
        if (hasModel(c)) return;
        File dir = modelDir(c);
        deleteRec(dir);
        dir.mkdirs();
        Request req = new Request.Builder().url(MODEL_URL).build();
        try (Response r = GeminiRest.HTTP.newBuilder().readTimeout(120, java.util.concurrent.TimeUnit.SECONDS).build().newCall(req).execute()) {
            if (!r.isSuccessful() || r.body() == null) throw new Exception("model download failed: HTTP " + r.code());
            try (InputStream in = r.body().byteStream(); ZipInputStream z = new ZipInputStream(in)) {
                ZipEntry e;
                byte[] buf = new byte[65536];
                while ((e = z.getNextEntry()) != null) {
                    String name = e.getName();
                    int slash = name.indexOf('/');
                    String rel = slash >= 0 ? name.substring(slash + 1) : name; // drop the top folder
                    if (rel.isEmpty()) continue;
                    File out = new File(dir, rel);
                    if (!out.getCanonicalPath().startsWith(dir.getCanonicalPath())) continue;
                    if (e.isDirectory()) {
                        out.mkdirs();
                        continue;
                    }
                    if (out.getParentFile() != null) out.getParentFile().mkdirs();
                    try (FileOutputStream fo = new FileOutputStream(out)) {
                        int n;
                        while ((n = z.read(buf)) > 0) fo.write(buf, 0, n);
                    }
                }
            }
        }
        if (!new File(dir, "am").exists()) {
            deleteRec(dir);
            throw new Exception("speech model was not unpacked correctly");
        }
        new File(dir, ".ok").createNewFile();
    }

    private static void deleteRec(File f) {
        File[] kids = f.listFiles();
        if (kids != null) for (File k : kids) deleteRec(k);
        f.delete();
    }

    public static synchronized void start(final Context ctx, final Runnable onWake) {
        if (running) return;
        running = true;
        thread = new Thread(() -> {
            Model model = null;
            Recognizer rec = null;
            AudioRecord ar = null;
            boolean fired = false;
            try {
                LibVosk.setLogLevel(LogLevel.WARNINGS);
                model = new Model(modelDir(ctx).getAbsolutePath());
                rec = new Recognizer(model, 16000.0f);
                int buf = Math.max(AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT), 8192);
                ar = new AudioRecord(MediaRecorder.AudioSource.MIC, 16000,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, buf * 2);
                if (ar.getState() != AudioRecord.STATE_INITIALIZED) throw new Exception("microphone is busy or not allowed");
                ar.startRecording();
                short[] b = new short[2000];
                while (running) {
                    int n = ar.read(b, 0, b.length);
                    if (n <= 0) continue;
                    for (int i = 0; i < n; i++) {
                        int v = b[i] * 2; // a little extra gain helps quiet voices
                        b[i] = (short) Math.max(-32768, Math.min(32767, v));
                    }
                    boolean fin = rec.acceptWaveForm(b, n);
                    String json = fin ? rec.getResult() : rec.getPartialResult();
                    String said = said(json);
                    if (fin && !said.isEmpty()) Bus.log("HEARD: " + said);
                    if (matches(said)) {
                        fired = true;
                        break;
                    }
                }
            } catch (Throwable t) {
                Bus.log("Wake word error: " + t.getMessage());
                if (t.getMessage() != null && t.getMessage().toLowerCase(Locale.ROOT).contains("model")) {
                    deleteRec(modelDir(ctx)); // broken download: fetch it again next time
                }
            } finally {
                running = false;
                try {
                    if (ar != null) {
                        ar.stop();
                        ar.release();
                    }
                } catch (Exception ignored) {
                }
                try {
                    if (rec != null) rec.close();
                    if (model != null) model.close();
                } catch (Throwable ignored) {
                }
            }
            if (fired) onWake.run();
        }, "mira-wake");
        thread.setDaemon(true);
        thread.start();
    }

    public static void stop() {
        running = false;
        Thread t = thread;
        if (t != null && t != Thread.currentThread()) {
            try {
                t.join(2000);
            } catch (InterruptedException ignored) {
            }
        }
    }

    private static String said(String json) {
        if (json == null) return "";
        try {
            JSONObject o = new JSONObject(json);
            return (o.optString("partial") + " " + o.optString("text")).toLowerCase(Locale.ROOT).trim();
        } catch (Exception e) {
            return "";
        }
    }

    private static final String[] HEY = {"hey", "hay", "hi", "hello", "okay", "ok", "a", "he", "hate"};
    private static final String[] NAMES = {"mira", "meera", "mirror", "mia", "maria", "mirah", "mera", "mara", "mirra",
            "miller", "murray", "mere", "jarvis", "jarvish", "jarvas", "service", "jervis", "javis", "jarves"};

    /** Fuzzy: "hey" + something that sounds like Mira / Jarvis, or just the name on its own. */
    static boolean matches(String said) {
        if (said == null || said.isEmpty()) return false;
        String[] w = said.replaceAll("[^a-z ]", " ").trim().split("\\s+");
        for (int i = 0; i < w.length; i++) {
            if (isName(w[i], true)) return true; // the name alone is enough (strong, not shy)
            if (i + 1 < w.length && in(HEY, w[i]) && isName(w[i + 1], false)) return true;
        }
        return false;
    }

    private static boolean in(String[] arr, String x) {
        for (String a : arr) if (a.equals(x)) return true;
        return false;
    }

    private static boolean isName(String w, boolean alone) {
        if (w.length() < 3) return false;
        if (alone) {
            return w.equals("mira") || w.equals("meera") || w.equals("jarvis") || w.equals("jarvish") || w.equals("jervis");
        }
        if (in(NAMES, w)) return true;
        return lev(w, "mira") <= 1 || lev(w, "jarvis") <= 1;
    }

    private static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }
}
