package com.markvi.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.ArrayList;

/** The separate Earth tab: a real 3D globe that zooms into places, with live distance from the phone's GPS. */
public class EarthActivity extends Activity {
    private static EarthActivity cur;
    private static final ArrayList<String> PENDING = new ArrayList<>();

    private WebView web;
    private boolean ready;
    private LocationManager lm;
    private LocationListener ll;

    /** Sends a command to the Earth page, opening the page first when needed. */
    static synchronized void send(Context c, JSONObject cmd) {
        final String s = cmd.toString();
        final EarthActivity a = cur;
        if (a != null && a.ready) {
            a.run(s);
            return;
        }
        PENDING.add(s);
        if (a == null) {
            try {
                Util.launch(c, new Intent(c, EarthActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));
            } catch (Throwable t) {
                DebugLog.add("Could not open Earth: " + t);
            }
        }
    }

    static void closeIfOpen() {
        final EarthActivity a = cur;
        if (a != null) a.runOnUiThread(() -> a.finish());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        cur = this;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                getWindow().setAttributes(lp);
            }
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                            | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        } catch (Throwable ignored) {
        }
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        web = new WebView(this);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.setBackgroundColor(Color.BLACK);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setCacheMode(WebSettings.LOAD_DEFAULT);
        ws.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "EarthNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/earth.html");
    }

    private void run(final String cmd) {
        runOnUiThread(() -> {
            try {
                web.evaluateJavascript("window.earthCmd && earthCmd(" + JSONObject.quote(cmd) + ")", null);
            } catch (Throwable t) {
                DebugLog.add("Earth command failed: " + t);
            }
        });
    }

    private void startTracking() {
        try {
            boolean ok = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            if (!ok) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 31);
                return;
            }
            lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            ll = new LocationListener() {
                @Override
                public void onLocationChanged(Location l) {
                    EarthTools.fix = l;
                    web.evaluateJavascript("window.earthLive && earthLive(" + l.getLatitude() + "," + l.getLongitude() + ")", null);
                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {
                }

                @Override
                public void onProviderEnabled(String provider) {
                }

                @Override
                public void onProviderDisabled(String provider) {
                }
            };
            for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                try {
                    if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 2000L, 3f, ll, Looper.getMainLooper());
                } catch (Throwable t) {
                    DebugLog.add("Earth tracking (" + p + "): " + t);
                }
            }
        } catch (Throwable t) {
            DebugLog.add("Earth tracking failed: " + t);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 31 && res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) startTracking();
    }

    @Override
    protected void onDestroy() {
        try {
            if (lm != null && ll != null) lm.removeUpdates(ll);
        } catch (Throwable ignored) {
        }
        if (cur == this) cur = null;
        ready = false;
        try {
            web.destroy();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    private final class Bridge {
        @JavascriptInterface
        public void ready() {
            runOnUiThread(() -> {
                ready = true;
                ArrayList<String> copy;
                synchronized (EarthActivity.class) {
                    copy = new ArrayList<>(PENDING);
                    PENDING.clear();
                }
                for (String s : copy) run(s);
                startTracking();
            });
        }

        @JavascriptInterface
        public String lastFix() {
            double[] p = EarthTools.userPos(EarthActivity.this);
            return p == null ? "" : "{\"lat\":" + p[0] + ",\"lng\":" + p[1] + "}";
        }

        @JavascriptInterface
        public void close() {
            runOnUiThread(() -> EarthActivity.this.finish());
        }
    }
}
