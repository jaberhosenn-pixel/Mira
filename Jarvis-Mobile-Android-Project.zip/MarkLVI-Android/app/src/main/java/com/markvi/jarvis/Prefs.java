package com.markvi.jarvis;

import android.content.Context;
import android.content.SharedPreferences;

/** App settings (the mobile twin of memory/config_manager.py). */
public final class Prefs {
    private Prefs() {}

    public static final String[] VOICES = {
            "Charon", "Aoede", "Kore", "Puck", "Fenrir", "Leda", "Orus", "Zephyr"
    };

    /** Tried in order when a model is rejected by the server. */
    public static final String[] MODELS = {
            "models/gemini-3.1-flash-live-preview",
            "models/gemini-2.5-flash-native-audio-preview-12-2025",
            "models/gemini-2.5-flash-native-audio-preview-09-2025"
    };

    public static final String TEXT_MODEL = "gemini-2.5-flash";

    public static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("jarvis", Context.MODE_PRIVATE);
    }

    public static String apiKey(Context c) {
        return sp(c).getString("api_key", "").trim();
    }

    public static void setApiKey(Context c, String k) {
        sp(c).edit().putString("api_key", k == null ? "" : k.trim()).apply();
    }

    public static String voice(Context c) {
        return sp(c).getString("voice", "Charon");
    }

    public static String userName(Context c) {
        return sp(c).getString("user_name", "").trim();
    }

    /** Identity rule: the user (name saved in Settings) is the creator. */
    /** True when the text asks who made / created / owns the assistant (English, Bangla, Banglish). */
    public static boolean asksCreator(String t) {
        if (t == null) return false;
        String s = t.toLowerCase(java.util.Locale.ROOT);
        String[] k = {"who made you", "who created you", "who built you", "who developed you", "who programmed you",
            "your creator", "your maker", "who is your owner", "who owns you", "who is your boss", "who is your father",
            "কে বানিয়েছে", "কে বানাইছে", "কে বানাল", "কে তৈরি করেছে", "কে তৈরি করছে", "কে তৈরী", "কে বানিয়েছেন", "কে বানাইসে",
            "তোমার স্রষ্টা", "তোমার নির্মাতা", "তোমার মালিক", "তোমার ক্রিয়েটর", "ক্রিয়েটর", "তোমার বস", "তোমার বাবা",
            "ke baniyechhe", "ke baniyese", "ke baniyeche", "ke banaise", "ke banaiche", "ke bananise", "ke toiri korese",
            "ke toiri koreche", "tomar creator", "tomar malik", "tomar srostha", "creator ke", "banaise tomake", "baniyechhe"};
        for (String x : k) if (s.contains(x)) return true;
        return false;
    }

    public static String creatorAnswer(Context c) {
        String u = userName(c);
        if (u.isEmpty()) return "আমার নির্মাতার নাম এখনো সেট করা নেই। Settings-এ \"Your Name (Owner)\" ঘরে আপনার নাম লিখে Save করুন।";
        return "আমাকে বানিয়েছেন " + u + "। উনিই আমার স্রষ্টা আর বস।";
    }

    public static String creatorRule(Context c) {
        String u = userName(c);
        String who = u.isEmpty() ? "the person who owns this phone (their name is not set yet; if asked, say so and tell them to set it in Settings)" : u;
        return "[CREATOR] " + assistantName(c) + " was made/built/created by " + who + ". "
            + "If asked who made, created, built, owns or programmed you (any language, e.g. 'তোমাকে কে বানিয়েছে', 'tomake ke baniyechhe', 'who created you'), answer plainly that "
            + who + " made you. Never say Google, Gemini, OpenAI, Anthropic, or any company created you, and do not add disclaimers about being an AI model made by a company. "
            + "When asked, ALWAYS call the creator_info tool and say its answer. Call the user by that name when natural.";
    }

    public static String assistantName(Context c) {
        String n = sp(c).getString("assistant_name", "Mira").trim();
        return n.isEmpty() ? "Mira" : n;
    }

    /** User-chosen model; empty means "use the ladder". */
    public static String model(Context c) {
        return sp(c).getString("model", "").trim();
    }

    /** Let the user interrupt the assistant by speaking over it (use headphones). */
    public static boolean allowInterrupt(Context c) {
        return sp(c).getBoolean("allow_interrupt", false);
    }

    public static boolean thinking(Context c) {
        return sp(c).getBoolean("thinking", false);
    }

    public static boolean keepAwake(Context c) {
        return sp(c).getBoolean("keep_awake", true);
    }

    // ---- optional third-party (OpenAI-compatible) provider
    public static boolean customOn(Context c) {
        return sp(c).getBoolean("custom_on", false);
    }

    public static String customBase(Context c) {
        return sp(c).getString("custom_base", "").trim();
    }

    public static String customKey(Context c) {
        return sp(c).getString("custom_key", "").trim();
    }

    public static String customModel(Context c) {
        return sp(c).getString("custom_model", "").trim();
    }
}
