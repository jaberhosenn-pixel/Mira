package com.markvi.jarvis;

import android.content.Context;
import android.content.SharedPreferences;

/** App settings (the mobile twin of memory/config_manager.py). */
public final class Prefs {
    private Prefs() {}

    public static final String[] VOICES = {
            "Charon", "Aoede", "Kore", "Puck", "Fenrir", "Leda", "Orus", "Zephyr"
    };

    /** Tried in order when a model is rejected by the server. */
    public static final String[] MODELS = {
            "models/gemini-3.1-flash-live-preview",
            "models/gemini-2.5-flash-native-audio-preview-12-2025",
            "models/gemini-2.5-flash-native-audio-preview-09-2025"
    };

    public static final String TEXT_MODEL = "gemini-2.5-flash";

    public static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("jarvis", Context.MODE_PRIVATE);
    }

    public static String apiKey(Context c) {
        return sp(c).getString("api_key", "").trim();
    }

    public static void setApiKey(Context c, String k) {
        sp(c).edit().putString("api_key", k == null ? "" : k.trim()).apply();
    }

    public static String voice(Context c) {
        return sp(c).getString("voice", "Charon");
    }

    public static String assistantName(Context c) {
        String n = sp(c).getString("assistant_name", "Mira").trim();
        return n.isEmpty() ? "Mira" : n;
    }

    /** User-chosen model; empty means "use the ladder". */
    public static String model(Context c) {
        return sp(c).getString("model", "").trim();
    }

    /** Let the user interrupt the assistant by speaking over it (use headphones). */
    public static boolean allowInterrupt(Context c) {
        return sp(c).getBoolean("allow_interrupt", false);
    }

    public static boolean thinking(Context c) {
        return sp(c).getBoolean("thinking", false);
    }

    public static boolean keepAwake(Context c) {
        return sp(c).getBoolean("keep_awake", true);
    }

    // ---- optional third-party (OpenAI-compatible) provider
    public static boolean customOn(Context c) {
        return sp(c).getBoolean("custom_on", false);
    }

    public static String customBase(Context c) {
        return sp(c).getString("custom_base", "").trim();
    }

    public static String customKey(Context c) {
        return sp(c).getString("custom_key", "").trim();
    }

    public static String customModel(Context c) {
        return sp(c).getString("custom_model", "").trim();
    }
}
