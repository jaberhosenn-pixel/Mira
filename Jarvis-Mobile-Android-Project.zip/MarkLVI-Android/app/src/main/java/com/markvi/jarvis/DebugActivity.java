package com.markvi.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/** Debugger: live log, crash report, and a one-tap self-test of everything Mira depends on. */
public class DebugActivity extends Activity {

    private TextView out;
    private ScrollView scroll;
    private volatile boolean testing;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#05080d"));
        getWindow().setNavigationBarColor(Color.parseColor("#05080d"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#05080d"));
        int p = dp(12);
        root.setPadding(p, dp(32), p, p);

        TextView t = new TextView(this);
        t.setText("Mira 10 Ultra · Debugger");
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(t);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(btn("🧹 Clean all", "#C62828", v -> {
            DebugLog.clear();
            DebugLog.clearCrash(this);
            refresh();
            Toast.makeText(this, "Cleaned", Toast.LENGTH_SHORT).show();
        }));
        row.addView(btn("Self-test", "#00B8D4", v -> selfTest()));
        row.addView(btn("Wake model", "#00796B", v -> wakeTest()));
        row.addView(btn("Accessibility", "#6A1B9A", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        row.addView(btn("App info", "#6A1B9A", v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                android.net.Uri.parse("package:" + getPackageName())))));
        row.addView(btn("Refresh", "#37474F", v -> refresh()));
        row.addView(btn("Copy", "#37474F", v -> copy()));
        row.addView(btn("Share", "#37474F", v -> share()));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(row);
        root.addView(hs);

        scroll = new ScrollView(this);
        out = new TextView(this);
        out.setTextColor(Color.parseColor("#B8D8E0"));
        out.setTextSize(11);
        out.setTypeface(Typeface.MONOSPACE);
        out.setTextIsSelectable(true);
        out.setPadding(0, dp(10), 0, dp(10));
        scroll.addView(out);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private Button btn(String text, String color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(color));
        g.setCornerRadius(dp(10));
        b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(40));
        lp.rightMargin = dp(6);
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        b.setPadding(dp(14), 0, dp(14), 0);
        b.setOnClickListener(l);
        return b;
    }

    private void refresh() {
        String crash = DebugLog.lastCrash(this);
        String text = (crash.isEmpty() ? "" : "=== LAST CRASH ===\n" + crash + "\n\n")
                + "=== LOG ===\n" + DebugLog.dump();
        out.setText(text);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void copy() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("mira-debug", out.getText()));
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, out.getText().toString());
        startActivity(Intent.createChooser(i, "Share debug log"));
    }

    private void line(final String s) {
        DebugLog.add(s);
        runOnUiThread(this::refresh);
    }

    private boolean has(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private static String yn(boolean b) {
        return b ? "OK" : "MISSING";
    }

    private void wakeTest() {
        if (testing) return;
        testing = true;
        final Context c = getApplicationContext();
        new Thread(() -> {
            try {
                long t0 = System.currentTimeMillis();
                line("Wake model: downloading (about 40 MB) ...");
                WakeEngine.downloadModel(c);
                line("Wake model: ready in " + (System.currentTimeMillis() - t0) / 1000 + " s. Now switch Hey Mira ON in Settings.");
            } catch (Throwable t) {
                line("Wake model: FAILED -> " + t);
            } finally {
                testing = false;
            }
        }, "mira-wakemodel").start();
    }

    private void selfTest() {
        if (testing) return;
        testing = true;
        final Context c = getApplicationContext();
        new Thread(() -> {
            try {
                DebugLog.clear();
                DebugLog.clearCrash(c);
                line("---- SELF-TEST ---- (Mira 10 Ultra)");
                line("Device: " + Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
                line("Permissions: mic " + yn(has(Manifest.permission.RECORD_AUDIO)) + ", camera " + yn(has(Manifest.permission.CAMERA))
                        + ", contacts " + yn(has(Manifest.permission.READ_CONTACTS)) + ", call " + yn(has(Manifest.permission.CALL_PHONE))
                        + ", sms " + yn(has(Manifest.permission.SEND_SMS)) + ", location "
                        + yn(has(Manifest.permission.ACCESS_FINE_LOCATION) || has(Manifest.permission.ACCESS_COARSE_LOCATION)));
                line("More permissions: calendar " + yn(has(Manifest.permission.READ_CALENDAR) && has(Manifest.permission.WRITE_CALENDAR))
                        + ", answer calls " + yn(has(Manifest.permission.ANSWER_PHONE_CALLS)) + ", phone state " + yn(has(Manifest.permission.READ_PHONE_STATE))
                        + ", call log " + yn(has(Manifest.permission.READ_CALL_LOG)));
                line("Special: accessibility " + yn(JarvisAccessibility.get() != null)
                        + ", notification access " + yn(NotifCatcher.hasAccess(c))
                        + ", overlay " + yn(Settings.canDrawOverlays(c))
                        + ", all files " + yn(Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()));
                if (JarvisAccessibility.get() == null) {
                    line("!! Accessibility is OFF: Mira cannot press Send or type in other apps. Tap 'Accessibility' above, turn Mira ON. If it is greyed out: tap 'App info', top-right menu (3 dots) -> 'Allow restricted settings', then try again.");
                }
                line("Wake word: model " + (WakeEngine.hasModel(c) ? "downloaded" : "NOT downloaded")
                        + ", listening " + WakeEngine.isRunning());
                line("Voice: " + Prefs.voice(c) + ", live model: " + (Prefs.model(c).isEmpty() ? "auto" : Prefs.model(c)));

                String key = Prefs.apiKey(c);
                if (key.isEmpty()) {
                    line("API key: MISSING. Paste it in Mira Settings, then run the test again.");
                    return;
                }
                line("API key: set (" + key.length() + " characters)");

                long t0 = System.currentTimeMillis();
                try {
                    String r = GeminiRest.generate(c, "Reply with the single word OK.");
                    line("Text model: OK in " + (System.currentTimeMillis() - t0) + " ms -> " + GeminiRest.abbreviate(r, 40));
                } catch (Exception e) {
                    line("Text model: FAILED -> " + GeminiRest.abbreviate(String.valueOf(e.getMessage()), 200));
                }

                t0 = System.currentTimeMillis();
                String tts = VoiceTts.probe(c, Prefs.voice(c));
                line("Voice (Gemini TTS): " + tts + " in " + (System.currentTimeMillis() - t0) + " ms");

                line("Live voice: " + liveProbe(key));
            } catch (Throwable t) {
                line("Self-test crashed: " + t);
            } finally {
                line("---- END ----");
                testing = false;
            }
        }, "mira-selftest").start();
    }

    /** Opens the Gemini Live socket exactly like a session would and waits for the server's "ready". */
    private String liveProbe(String key) {
        final CountDownLatch done = new CountDownLatch(1);
        final String[] result = {"no answer in 10 s"};
        String model = Prefs.model(this).isEmpty() ? Prefs.MODELS[0] : Prefs.model(this);
        if (!model.startsWith("models/")) model = "models/" + model;
        final String m = model;
        Request req = new Request.Builder().url("wss://generativelanguage.googleapis.com/ws/"
                + "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + key).build();
        WebSocket ws = GeminiRest.HTTP.newWebSocket(req, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket w, Response r) {
                w.send(J.obj("setup", J.obj("model", m,
                        "generationConfig", J.obj("responseModalities", J.arr("AUDIO")))).toString());
            }

            @Override
            public void onMessage(WebSocket w, String text) {
                if (text.contains("setupComplete")) result[0] = "OK (" + m + ")";
                else result[0] = "server said: " + GeminiRest.abbreviate(text, 160);
                done.countDown();
            }

            @Override
            public void onMessage(WebSocket w, okio.ByteString bytes) {
                String text = bytes.utf8();
                if (text.contains("setupComplete")) result[0] = "OK (" + m + ")";
                else result[0] = "server said: " + GeminiRest.abbreviate(text, 160);
                done.countDown();
            }

            @Override
            public void onFailure(WebSocket w, Throwable t, Response r) {
                result[0] = "FAILED -> " + t.getClass().getSimpleName() + ": " + t.getMessage() + (r != null ? " (HTTP " + r.code() + ")" : "");
                done.countDown();
            }

            @Override
            public void onClosed(WebSocket w, int code, String reason) {
                if (done.getCount() > 0) {
                    result[0] = "closed " + code + " " + reason;
                    done.countDown();
                }
            }
        });
        try {
            done.await(10, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        try {
            ws.close(1000, "test");
        } catch (Exception ignored) {
        }
        return result[0];
    }
}
