package com.markvi.jarvis;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import static com.markvi.jarvis.Tools.reg;
import static com.markvi.jarvis.Tools.schema;

/**
 * Serious mode: heavy jobs (websites, design, research, lead lists) go to the user's third-party provider.
 * Normal mode always uses Gemini. Files land in Downloads/Mira/<Websites|Research|Leads|Other>.
 */
public final class SeriousMode {
    private SeriousMode() {}

    private static final String BASE_PROMPT = "\n\n[SERIOUS MODE] You are now working as a professional assistant on a substantial job "
            + "(web development, web design, research, lead lists, writing). Do the whole job properly, not a sample.\n"
            + "RULES:\n"
            + "- Act ONLY on what the user asks. Never send messages, delete anything or do anything extra on your own.\n"
            + "- NEW BIG JOB: first reply with a short plan (3 to 5 bullet lines: what you will make, the steps, the file you will save) "
            + "and ask 'Shall I start?'. Do not start until the user says yes / ok / শুরু করো. Small requests (a quick answer, a small edit) need no plan.\n"
            + "- SAVING: only when the user asks to save, or when a finished file is the point of the job. Use save_file; files go to the phone's Downloads folder. "
            + "Give a project name so the work can be continued later.\n"
            + "- CHANGING EXISTING WORK ('make the colour blue', 'change the phone number'): use edit_file on the saved file (find/replace), "
            + "do not rewrite the whole file. Read it first with file_controller (action read) if you need to see it.\n"
            + "- Website / page / design: ONE complete, modern, mobile-friendly, self-contained HTML file (inline CSS and JS, no placeholders), saved as .html. "
            + "Re-read what you wrote for broken links, missing tags and mobile layout before saving.\n"
            + "- Research: gather facts (use web_search), compare, write a clear structured report with headings and sources. Say plainly what you could not verify.\n"
            + "- LEAD LISTS (businesses of a niche in a city): for local businesses call maps_leads (reads Google Maps like a scraper extension, scores each lead 0-100, saves CSV + Excel "
            + "and a separate no-website list). For web-wide results call search_leads (Google Search). find_leads is a quick Gemini-only version. Tell the user the screen must stay on during a Maps scan. Use extract_contacts for one specific site. Never type contact details from memory.\n"
            + "- Reading sources: web_search for facts, fetch_page to read a page.\n"
            + "- Documents: PDF -> make_pdf, Word -> make_word, a bundle of saved files -> zip_files, Excel -> make_excel (all saved to Downloads).\n"
            + "- Other lists / tables: save as .csv with save_file. If the user asks for Excel, call make_excel with the CSV text. "
            + "If they ask for Google Sheets, say you cannot send to Google directly and give them the CSV or Excel file to import. "
            + "Leads: only PUBLIC business information (name, website, public business email/phone, city). Never invent data: leave a cell empty if unknown.\n"
            + "- FACEBOOK CONTENT: when asked for posts, captions, ideas or a content calendar, write ready-to-post text in the user's language (hook line, body, call to action, 5-8 hashtags, "
            + "and a one-line image/video idea per post). Offer 3 variants for a single post; for a calendar give a day-by-day table. Save as .md/.docx/.pdf only if asked.\n"
            + "- SENDING EMAIL / MESSENGER: when the user dictates a recipient (and subject and body) and says to send, call send_message right away with exactly their words "
            + "(platform email with subject, or messenger). Do not ask for confirmation, do not rewrite or add text. Report the result honestly (never say 'sent' unless status=done; 'unverified' means Send was pressed). "
            + "Sending the same email to many people from a leads file: use send_email_batch.\n"
            + "- WEBSITE PREVIEW: after saving a .html site, call preview_website so the user sees it inside Mira. Also when they say 'show/preview it'.\n"
            + "- DAILY LEAD UPDATE: only when the user asks, call schedule_daily_leads (on/off) with niche, city, count and time. It runs by itself every day and notifies with a file of NEW leads only.\n"
            + "- READING DOCUMENTS: to read a PDF/Word/Excel/text file the user names, find it in Downloads (file_controller list) and open it with file_processor, then summarise or answer from it; quote only what is really in it.\n"
            + "- GOOGLE CALENDAR: calendar_list to read upcoming events, calendar_add to add one directly (no form), calendar_delete to remove one. Dates are 'YYYY-MM-DD HH:MM' local; work out relative days like 'tomorrow 5pm' from today's date.\n"
            + "- GMAIL: gmail_recent reads recent Gmail notifications only (not the whole inbox: say so). email_draft opens an unsent draft. To send, use send_message (platform email).\n"
            + "- LEAD EMAILS: draft_lead_emails writes personalised drafts for a saved leads CSV (nothing is sent); open_email_draft shows one in Gmail. Only send them one by one if the user asks. Never fake claims or urgency.\n"
            + "- BACKUP: backup_data saves everything to Downloads (keys excluded unless asked); restore_data restores the newest backup, only on a clear request.\n"
            + "- CALLS (only on the user's command): incoming_call says who is calling; answer_call / reject_call; decline_with_message sends a busy SMS or WhatsApp after declining; "
            + "decline_with_voice declines and sends Mira's voice saying the user is busy as a WhatsApp audio message (best for voice); answer_and_say_busy answers and plays Mira's voice saying the user is busy, then hangs up. WhatsApp calls: whatsapp_call_action is unreliable, say so. Never answer or decline by yourself.\n"
            + "- INSTALLING APPS: install_app installs a free app from Play Store by itself (needs Accessibility). Never buy paid apps.\n"
            + "- APP AUTOMATION: ui_flow runs a whole list of screen steps (open app, tap text, type, send...) by itself; use it for jobs in any app, retry at most twice with corrected text.\n"
            + "- Never hand the last tap (Send, Install...) to the user: if a tool could not press it, finish it yourself with ui_flow using the words on screen, retry twice, then explain the blocker.\n"
            + "- SCREEN AGENT: screen_agent looks at the screen and does any on-screen goal step by step (press Send, install, open, like); use it when ui_flow or normal tools fail.\n"
            + "- When finished: reply in 1 to 3 short sentences saying what you made, the file name, and what the user can do next. Do not paste the whole file into the reply.\n"
            + "- If a request is unclear, ask one short question instead of guessing.";

    static String prompt(Context c) {
        StringBuilder sb = new StringBuilder(BASE_PROMPT);
        sb.append("\n\n").append(Prefs.creatorRule(c));
        JSONArray h = history(c);
        if (h.length() > 0) {
            sb.append("\n\nPROJECTS AND FILES ALREADY SAVED (newest first; continue from these when the user refers to earlier work):\n");
            for (int i = 0; i < h.length() && i < 12; i++) {
                JSONObject f = h.optJSONObject(i);
                sb.append("- [").append(f.optString("project", "-")).append("] ").append(f.optString("path")).append('\n');
            }
        }
        return sb.toString();
    }

    public static boolean active(Context c) {
        return Prefs.sp(c).getBoolean("serious_active", false);
    }

    public static void set(Context c, boolean on) {
        Prefs.sp(c).edit().putBoolean("serious_active", on).apply();
        DebugLog.add("Serious mode " + (on ? "ON" : "OFF"));
    }

    static boolean providerReady(Context c) {
        return Prefs.customOn(c) && !Prefs.customBase(c).isEmpty() && !Prefs.customKey(c).isEmpty();
    }

    // ---- spoken / typed switch phrases
    private static final String[] ON = {"serious mode", "সিরিয়াস মোড", "সিরিয়াস মুড", "সিরিয়াস মোডে", "সিরিয়াস মুডে"};
    private static final String[] OFF = {"serious mode off", "exit serious", "stop serious", "leave serious", "normal mode",
            "off serious", "serious off", "disable serious", "সিরিয়াস মোড বন্ধ", "সিরিয়াস মুড বন্ধ", "সিরিয়াস মোড অফ", "সিরিয়াস মুড অফ", "নরমাল মোড", "সাধারণ মোড"};

    /** Returns null when the text is not a mode switch, else the reply (and the remaining task, if any, in rest[0]). */
    public static String handleSwitch(Context c, String text, String[] rest) {
        String low = text.toLowerCase(Locale.ROOT);
        for (String o : OFF) {
            if (low.contains(o)) {
                set(c, false);
                return "Serious mode is off. Back to normal.";
            }
        }
        for (String o : ON) {
            int i = low.indexOf(o);
            if (i >= 0) {
                if (!providerReady(c)) {
                    return "Serious mode needs an AI provider. Open Settings, switch on Another API provider and add the Base URL and API key.";
                }
                set(c, true);
                String after = (text.substring(0, i) + " " + text.substring(Math.min(text.length(), i + o.length()))).trim();
                after = after.replaceAll("(?i)^((hey|হেই)[ ,]*)?(mira|মিরা|মীরা)?[ ,]*(on|turn on|go to|go)?[ ,]*", "").replaceAll("(?i)(যাও|jao|go|on|চালু করো|চালু)\\s*$", "").trim();
                rest[0] = after.length() > 6 ? after : "";
                return rest[0].isEmpty() ? "Serious mode is on. Tell me the job." : "";
            }
        }
        return null;
    }

    /** Runs a job on the serious provider in the background (service + wake lock), then notifies the user. */
    public static String run(Context c, String job) throws Exception {
        if (!providerReady(c)) throw new Exception("Serious mode needs the AI provider (Settings > Another API provider).");
        SeriousService.begin(c);
        try {
            String out = CustomAgent.chat(c, job, prompt(c), 7000);
            long tk = CustomAgent.lastJobTokens();
            if (tk > 0) out = out + "\n(≈" + tk + " tokens used)";
            try {
                Util.notifyAlert(c, 4711, "Mira · Serious mode", out.length() > 140 ? out.substring(0, 140) + "…" : out);
            } catch (Throwable ignored) {
            }
            return out;
        } finally {
            SeriousService.end(c);
        }
    }

    // ---- files
    /** Set by preview_website; the HUD picks it up and shows the page. */
    public static volatile String pendingPreview = null;

    /** Reads a text file (max 2 MB) but only from inside the Downloads folder. */
    public static String readText(String path) {
        try {
            if (path == null || path.isEmpty()) return null;
            File f = new File(path).getCanonicalFile();
            if (!f.isFile() || f.length() > 2_000_000) return null;
            if (!f.getPath().startsWith(root().getCanonicalPath() + File.separator)) return null;
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            }
            return bo.toString("UTF-8");
        } catch (Exception e) {
            return null;
        }
    }

    public static File root() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
    }

    private static File indexFile(Context c) {
        return new File(c.getFilesDir(), "serious_index.json");
    }

    private static synchronized JSONArray readIndex(Context c) {
        try (java.io.FileInputStream in = new java.io.FileInputStream(indexFile(c))) {
            byte[] b = new byte[(int) indexFile(c).length()];
            int n = in.read(b);
            return new JSONArray(new String(b, 0, Math.max(0, n), "UTF-8"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private static synchronized void addIndex(Context c, File f, String project) {
        try {
            JSONArray old = readIndex(c), now = new JSONArray();
            now.put(J.obj("name", f.getName(), "path", f.getAbsolutePath(), "project", project, "time", System.currentTimeMillis()));
            for (int i = 0; i < old.length() && now.length() < 200; i++) {
                JSONObject o = old.optJSONObject(i);
                if (o != null && !f.getAbsolutePath().equals(o.optString("path"))) now.put(o);
            }
            try (FileOutputStream fo = new FileOutputStream(indexFile(c))) {
                fo.write(now.toString().getBytes("UTF-8"));
            }
        } catch (Exception e) {
            DebugLog.add("index write failed: " + e);
        }
    }

    private static File uniqueFile(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name, ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 2; i < 500; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists()) return f;
        }
        return new File(dir, base + "-" + System.currentTimeMillis() + ext);
    }

    /** Writes bytes to Downloads (or the app's own folder if storage is not allowed). Returns the saved file. */
    static File saveBytes(Context c, String name, byte[] data, String project) throws Exception {
        return store(c, clean(name, "mira-file-" + System.currentTimeMillis()), data, false, clean(project, "general"));
    }

    private static File store(Context c, String name, byte[] data, boolean overwrite, String project) throws Exception {
        File dir = root();
        File f = overwrite ? new File(dir, name) : uniqueFile(dir, name);
        try {
            dir.mkdirs();
            try (FileOutputStream fo = new FileOutputStream(f)) {
                fo.write(data);
            }
        } catch (Exception e) {
            dir = new File(c.getExternalFilesDir(null), "Mira");
            dir.mkdirs();
            f = overwrite ? new File(dir, name) : uniqueFile(dir, name);
            try (FileOutputStream fo = new FileOutputStream(f)) {
                fo.write(data);
            }
        }
        addIndex(c, f, project);
        DebugLog.add("Saved file: " + f.getAbsolutePath() + " (" + f.length() + " bytes)");
        return f;
    }

    private static String clean(String s, String dflt) {
        String t = s == null ? "" : s.replaceAll("[^A-Za-z0-9._\\-\\u0980-\\u09FF ]", "_").trim();
        return t.isEmpty() ? dflt : t;
    }

    static void register() {
        reg("save_file",
                "Saves a finished work product (website .html, report .md/.html, leads .csv) into the phone's Downloads folder. "
                        + "Give the COMPLETE content and a short project name.",
                schema("filename,content",
                        "filename:STRING:file name with extension, e.g. landing.html",
                        "content:STRING:the complete file content",
                        "project:STRING:short project name, e.g. cafe-website",
                        "overwrite:BOOLEAN:true to replace a file with the same name"),
                (c, a) -> {
                    String name = clean(a.optString("filename"), "mira-" + System.currentTimeMillis() + ".txt");
                    String content = a.optString("content");
                    if (content.isEmpty()) return J.fail("content is empty");
                    File f = store(c, name, content.getBytes("UTF-8"), a.optBoolean("overwrite", false), clean(a.optString("project"), "general"));
                    return J.ok("saved_to", f.getAbsolutePath());
                });

        reg("edit_file",
                "Changes part of a file Mira saved earlier: replaces the exact text 'find' with 'replace' (all occurrences). "
                        + "Use for small changes like a colour or a phone number. Read the file first if unsure of the exact text.",
                schema("path,find,replace",
                        "path:STRING:full path of the file",
                        "find:STRING:exact text to replace",
                        "replace:STRING:new text"),
                (c, a) -> {
                    File f = new File(a.optString("path"));
                    if (!f.exists()) return J.fail("file not found: " + f.getAbsolutePath());
                    String find = a.optString("find");
                    if (find.isEmpty()) return J.fail("find is empty");
                    byte[] b = new byte[(int) f.length()];
                    try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
                        int n = in.read(b);
                        b = java.util.Arrays.copyOf(b, Math.max(0, n));
                    }
                    String text = new String(b, "UTF-8");
                    int count = 0, idx = 0;
                    while ((idx = text.indexOf(find, idx)) >= 0) {
                        count++;
                        idx += find.length();
                    }
                    if (count == 0) return J.fail("the text to replace was not found; read the file and copy the exact text");
                    try (FileOutputStream fo = new FileOutputStream(f)) {
                        fo.write(text.replace(find, a.optString("replace")).getBytes("UTF-8"));
                    }
                    DebugLog.add("Edited file: " + f.getName() + " (" + count + " change" + (count > 1 ? "s" : "") + ")");
                    return J.ok("changes", count, "file", f.getAbsolutePath());
                });

        reg("make_excel",
                "Turns CSV text into an Excel (.xlsx) file saved in Downloads. Give the CSV text (first row = headers).",
                schema("filename,csv",
                        "filename:STRING:name ending in .xlsx",
                        "csv:STRING:the CSV text",
                        "project:STRING:short project name"),
                (c, a) -> {
                    String name = clean(a.optString("filename"), "mira-" + System.currentTimeMillis() + ".xlsx");
                    if (!name.toLowerCase(Locale.ROOT).endsWith(".xlsx")) name = name + ".xlsx";
                    String csv = a.optString("csv");
                    if (csv.trim().isEmpty()) return J.fail("csv is empty");
                    File f = store(c, name, XlsxWriter.fromCsv(csv), false, clean(a.optString("project"), "general"));
                    return J.ok("saved_to", f.getAbsolutePath());
                });

        reg("preview_website",
                "Shows a saved .html website inside Mira's own screen so the user can look at it. Give the saved file path.",
                schema("path", "path:STRING:full path of the saved .html file"),
                (c, a) -> {
                    String p = a.optString("path");
                    if (readText(p) == null) return J.fail("file not found or not inside Downloads: " + p);
                    pendingPreview = p;
                    return J.ok("note", "the preview is open on the user's screen");
                });

        reg("serious_mode",
                "Switches Serious mode on or off. Serious mode sends big jobs (build a website, design, research, lead lists) "
                        + "to the user's own AI provider. Use on when the user says go serious.",
                schema("action", "action:STRING:on | off"),
                (c, a) -> {
                    boolean on = !"off".equalsIgnoreCase(a.optString("action"));
                    if (on && !providerReady(c)) return J.fail("no AI provider is set up; ask the user to add one in Settings");
                    set(c, on);
                    return J.ok("serious", on);
                });

        reg("serious_task",
                "Hands a big job to Serious mode and waits for the result: build a website, design a page, research a topic, "
                        + "make a lead list. Put the whole request in task. Reply to the user briefly with what was made.",
                schema("task", "task:STRING:the full job description in the user's words"),
                (c, a) -> {
                    String task = a.optString("task");
                    if (task.isEmpty()) return J.fail("task is empty");
                    if (!providerReady(c)) return J.fail("no AI provider is set up; ask the user to add one in Settings");
                    set(c, true);
                    String out = run(c, task);
                    return J.ok("result", out);
                });
    }

    // ---- history (what Serious mode saved)
    public static JSONArray history(Context c) {
        JSONArray idx = readIndex(c), out = new JSONArray();
        for (int i = 0; i < idx.length() && out.length() < 80; i++) {
            JSONObject o = idx.optJSONObject(i);
            if (o == null) continue;
            File f = new File(o.optString("path"));
            if (!f.exists()) continue;
            out.put(J.obj("name", f.getName(), "project", o.optString("project", "general"), "folder", o.optString("project", "general"),
                    "path", f.getAbsolutePath(), "time", o.optLong("time", f.lastModified()), "size", f.length()));
        }
        return out;
    }

    public static void open(Context c, String path) throws Exception {
        File f = new File(path);
        if (!f.exists()) throw new Exception("file not found");
        String low = f.getName().toLowerCase(Locale.ROOT);
        String mime = low.endsWith(".html") || low.endsWith(".htm") ? "text/html" : low.endsWith(".csv") ? "text/csv"
                : low.endsWith(".xlsx") ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                : low.endsWith(".pdf") ? "application/pdf" : low.endsWith(".zip") ? "application/zip"
                : low.endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                : low.endsWith(".md") || low.endsWith(".txt") ? "text/plain" : "*/*";
        Uri u = androidx_free_uri(c, f);
        Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            c.startActivity(i);
        } catch (Exception e) {
            c.startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, u)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }
    }

    private static Uri androidx_free_uri(Context c, File f) {
        return MiraFileProvider.uriFor(c, f);
    }
}
