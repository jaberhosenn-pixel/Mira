window.wakeWordActive = false;
/* Native bridge: runs inside the Mira HUD WebView and swaps the browser-only demo behaviours
   for real Android ones. The Mira page itself (design, 3D head, actions grid) is untouched. */
(function () {
  'use strict';
  if (!window.Android || typeof window.Android.isNative !== 'function') return;
  const A = window.Android;

  // ---- async call plumbing ------------------------------------------------
  const pending = {};
  let seq = 0;
  function reg(fn) { const id = 'c' + (++seq); pending[id] = fn; return id; }
  window.__nativeDone = function (id, payload) {
    const f = pending[id];
    if (f) { delete pending[id]; f(payload); }
  };
  function nativeTool(name, args) {
    return new Promise(function (res) {
      const id = reg(function (p) {
        let o; try { o = JSON.parse(p); } catch (e) { o = { status: 'failed', error: String(p) }; }
        res(o);
      });
      A.tool(id, name, JSON.stringify(args || {}));
    });
  }
  function nativeText(kind, text) {
    return new Promise(function (res, rej) {
      const id = reg(function (p) {
        let o; try { o = JSON.parse(p); } catch (e) { o = { ok: false, text: String(p) }; }
        if (o.ok) res(o.text); else rej(new Error(o.text));
      });
      if (kind === 'chat') A.chat(id, text); else A.ask(id, text);
    });
  }
  window.nativeTool = nativeTool;

  let liveActive = false;
  const toast = function (m) { try { showToast(m); } catch (e) {} };

  // ---- events pushed from the native live session -------------------------
  window.__miraNative = {
    state: function (s) {
      liveActive = !(s === 'IDLE' || s === 'ERROR');
      if (s === 'SPEAKING') {
        avatarState.speaking = true;
        setAvatarStatus('SPEAKING');
      } else {
        avatarState.speaking = false;
        window.__nativeLevel = null;
        if (s === 'LISTENING') {
          isTalkingActive = true; avatarState.listening = true;
          updateTalkSwitchUI();
          setAvatarStatus('LISTENING · SPEAK NOW');
          setLiveMicTranscriptText('🔴 Live — just speak, I am listening', true);
        } else if (s === 'THINKING') {
          setAvatarStatus('THINKING');
        } else if (s === 'CONNECTING') {
          setAvatarStatus('CONNECTING');
        } else {
          isTalkingActive = false; avatarState.listening = false;
          updateTalkSwitchUI();
          setAvatarStatus(s === 'ERROR' ? 'OFFLINE' : 'ACTIVE · READY');
          setLiveMicTranscriptText('Ready — Tap "START TALKING" or Tap Mira Head to speak', false);
        }
      }
    },
    user: function (t, fin) {
      if (fin) { if (t) appendChatMessage('user', t); }
      else setLiveMicTranscriptText('🔴 Heard: "' + t + '"', true);
    },
    asst: function (t, fin) { if (fin && t) appendChatMessage('jarvis', t); },
    level: function (m, s) { window.__nativeLevel = avatarState.speaking ? s : null; },
    info: function (m) { toast(m); },
    wakeStatus: function (t) {
      let c = document.getElementById('mira-wakechip');
      if (!c) {
        c = document.createElement('div');
        c.id = 'mira-wakechip';
        c.style.cssText = 'position:fixed;left:50%;transform:translateX(-50%);bottom:84px;max-width:92vw;z-index:60;pointer-events:none;' +
          'font:10px/1.3 ui-monospace,monospace;color:#9be7f2;background:rgba(2,10,16,.7);border:1px solid rgba(103,232,249,.25);' +
          'border-radius:10px;padding:3px 9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis';
        document.body.appendChild(c);
      }
      c.textContent = String(t).replace(/^Wake( hears)?:\s*/, function (m, h) { return h ? '👂 ' : '🎙 '; });
      clearTimeout(c._t);
      c._t = setTimeout(function () { c.style.display = 'none'; }, 6000);
      c.style.display = 'block';
    },
    heard: function (t) { const e = document.getElementById('native-wake-heard'); if (e) e.textContent = 'Heard: ' + t; },
    wakeState: function (on) { window.wakeWordActive = !!on; try { window.__wakeUi && window.__wakeUi(!!on); } catch (e) {} },
    error: function (m) { toast('⚠️ ' + m); try { appendChatMessage('sys', '⚠️ ' + m); } catch (e) {} },
    memory: function (cat, key, val) {
      try {
        const text = key.replace(/_/g, ' ') + ': ' + val;
        const emb = computeSemanticVector(text + ' ' + cat);
        memories.unshift({
          id: 'm_' + Date.now(), cat: 'Project', text: text,
          ts: new Date().toISOString().slice(0, 10), vec: Array.from(emb.vec), norm: emb.norm
        });
        persistSqliteDatabase(); renderMemories();
      } catch (e) {}
    },
    ttsDone: function () {
      avatarState.speaking = false;
      if (!liveActive) setAvatarStatus('ACTIVE · READY');
    }
  };

  // ---- voice: native Gemini Live replaces browser SpeechRecognition -------
  window.startTalking = function () {
    if (isTalkingActive) return;
    isTalkingActive = true;
    avatarState.listening = true;
    avatarState.speaking = false;
    updateTalkSwitchUI();
    setAvatarStatus('CONNECTING');
    setLiveMicTranscriptText('🔴 Connecting live voice…', true);
    syncNativeSettings();
    A.liveStart();
  };
  window.stopTalking = function () {
    isTalkingActive = false;
    avatarState.listening = false;
    avatarState.speaking = false;
    window.__nativeLevel = null;
    updateTalkSwitchUI();
    setAvatarStatus('ACTIVE · READY');
    setLiveMicTranscriptText('Ready — Tap "START TALKING" or Tap Mira Head to speak', false);
    A.liveStop();
  };

  // ---- spoken replies for typed chat (device voice) ------------------------
  window.speakJarvisReply = function (text) {
    if (!text || !hudAudioEnabled || liveActive) return;
    const clean = String(text).replace(/[*#`_~]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!clean) return;
    avatarState.speaking = true;
    setAvatarStatus('SPEAKING');
    syncNativeSettings();
    A.speak(clean);
  };

  // ---- typed chat: native agent with every phone tool ----------------------
  const origSend = window.sendChatCommand;
  window.sendChatCommand = async function () {
    const inp = document.getElementById('chat-input');
    const text = ((inp && inp.value) || '').trim();
    if (!text) return;
    if (!A.getApiKey() && !getGeminiApiKey()) return origSend();
    inp.value = '';
    playHudBeep(580, 0.04);
    appendChatMessage('user', text);
    if (liveActive) { A.liveText(text); return; }
    syncNativeSettings();
    setAvatarStatus('THINKING · GEMINI');
    try {
      const reply = await nativeText('chat', text);
      appendChatMessage('jarvis', reply);
      speakJarvisReply(reply);
      if (!avatarState.speaking) setAvatarStatus('ACTIVE · READY');
    } catch (e) {
      appendChatMessage('jarvis', '⚠️ ' + e.message);
      setAvatarStatus('ACTIVE · READY');
    }
  };

  function syncNativeSettings() {
    try { A.syncSettings(getGeminiApiKey() || '', getAssistantName(), getUserName()); } catch (e) {}
  }
  const origSave = window.saveEngineConfig;
  window.saveEngineConfig = function () { origSave(); syncNativeSettings(); };
  // also sync the owner/assistant name on load and whenever the fields change,
  // so Mira knows the name even if the user never presses Save
  setTimeout(syncNativeSettings, 1500);
  ['cfg-user-name', 'cfg-assistant-name'].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) { el.addEventListener('input', syncNativeSettings); el.addEventListener('change', syncNativeSettings); }
  });

  // ---- real phone actions ---------------------------------------------------
  function report(title, r) {
    const ok = r && r.status !== 'failed' && r.status !== 'declined';
    appendChatMessage('jarvis', ok ? title + ' — ' + (r.status || 'done') : title + ' — ' + (r.error || r.status));
    return ok;
  }

  const origOpenApp = window.openNativeAndroidApp;
  window.openNativeAndroidApp = function (appKey, q) {
    const app = (typeof ANDROID_APP_SCHEMES !== 'undefined' && ANDROID_APP_SCHEMES[appKey]) || { title: appKey };
    undoStack.push({ title: 'Open Android App: ' + app.title, time: new Date().toLocaleTimeString() });
    updateUndoCounter();
    switchTab('hud');
    let p;
    if (appKey === 'youtube' && q) p = nativeTool('youtube_video', { action: 'search', query: q });
    else if (appKey === 'maps' && q) p = nativeTool('browser_control', { action: 'maps_search', query: q });
    else if (appKey === 'chrome' && q && /^https?:/i.test(q)) p = nativeTool('browser_control', { action: 'open_url', url: q });
    else p = nativeTool('open_app', { app_name: app.title });
    p.then(function (r) {
      if (!report('Opening ' + app.title, r)) origOpenApp(appKey, q);
    });
  };

  const origComms = window.launchAndroidComms;
  window.launchAndroidComms = function (mode, target, msg) {
    const t = (target || '').trim(), m = (msg || '').trim();
    let call = null, title = '';
    if (mode === 'whatsapp_msg' && t && m) { call = ['send_message', { receiver: t, message_text: m, platform: 'whatsapp' }]; title = 'WhatsApp to ' + t; }
    else if (mode === 'sms' && t && m) { call = ['send_message', { receiver: t, message_text: m, platform: 'sms' }]; title = 'SMS to ' + t; }
    else if (mode === 'phone_call' && t) { call = ['make_call', { receiver: t }]; title = 'Call ' + t; }
    if (!call) return origComms(mode, target, msg);
    undoStack.push({ title: title, time: new Date().toLocaleTimeString() });
    updateUndoCounter();
    switchTab('hud');
    nativeTool(call[0], call[1]).then(function (r) {
      if (!report(title, r)) origComms(mode, target, msg);
    });
  };

  window.toggleMobileFlashlight = async function (force) {
    const action = force === true ? 'flashlight_on' : (force === false ? 'flashlight_off' : 'flashlight_toggle');
    const r = await nativeTool('phone_settings', { action: action });
    toast(r.status === 'failed' ? '⚠️ ' + r.error : '🔦 Flashlight ' + (r.flashlight || 'toggled'));
  };

  let soundIdx = 0;
  window.cycleSoundProfile = async function () {
    const modes = [['ringer_normal', '🔔 Normal'], ['ringer_vibrate', '📳 Vibrate'], ['ringer_silent', '🔕 Silent']];
    soundIdx = (soundIdx + 1) % modes.length;
    const r = await nativeTool('phone_settings', { action: modes[soundIdx][0] });
    toast(r.status === 'failed' ? '⚠️ ' + r.error : modes[soundIdx][1]);
    appendChatMessage('jarvis', 'Sound profile: ' + modes[soundIdx][1] + (r.status === 'failed' ? ' (' + r.error + ')' : ''));
  };

  window.startQuickMobileAlarm = async function (seconds, label) {
    const s = seconds || 10;
    const r = await nativeTool('set_alarm_timer', { type: 'timer', seconds: s, label: label || 'Mira' });
    report('Timer ' + s + 's', r);
    toast('⏰ Timer set: ' + s + 's');
  };

  window.triggerPhoneVibration = function () { try { A.vibrate(60); } catch (e) {} };

  window.exportMobileNoteFile = function () {
    const feed = document.getElementById('chat-feed');
    const content = [
      '=== ' + getAssistantName().toUpperCase() + ' MOBILE REPORT ===',
      'Owner: ' + getUserName(),
      'Time: ' + new Date().toLocaleString(),
      '',
      'Stored Memories:'
    ].concat(memories.map(function (m) { return '- [' + m.cat + '] ' + m.text + ' (' + m.ts + ')'; }))
      .concat(['', 'Chat log:', feed ? feed.innerText : '']).join('\n');
    const name = getAssistantName().toLowerCase() + '_report_' + Date.now() + '.txt';
    const path = A.saveNote(name, content);
    appendChatMessage('jarvis', '📥 Saved to: ' + path);
    toast('📥 Saved: ' + name);
  };

  // ---- real hardware telemetry ---------------------------------------------
  window.updateHardwareTelemetry = async function () {
    const clockEl = document.getElementById('clock-txt');
    if (clockEl) clockEl.textContent = new Date().toTimeString().slice(0, 5);
    let s;
    try { s = JSON.parse(A.status()); } catch (e) { return; }
    const set = function (id, v) { const el = document.getElementById(id); if (el) el.textContent = v; };
    const bar = function (id, v) { const el = document.getElementById(id); if (el) el.style.width = Math.max(1, Math.min(100, v)) + '%'; };
    set('tel-cores-val', s.cores + ' Cores');
    set('tel-ram-gb', s.ramGb + ' GB');
    set('tel-heap-mb', 'Heap: ' + s.heapMb + ' MB');
    try { set('tel-frame-ms', smoothedRenderMs.toFixed(1) + ' ms/f'); } catch (e) {}
    set('tel-source-lbl', 'SOURCE: ANDROID NATIVE SENSORS (LIVE)');
    if (s.cpu >= 0) { set('metric-cpu', s.cpu + '%'); bar('bar-cpu', s.cpu); }
    set('metric-ram', s.ram + '%'); bar('bar-ram', s.ram);
    try { renderBatteryUi(s.bat, !!s.charging); } catch (e) {}
  };

  // ---- real notification filter ----------------------------------------------
  const origOpenNotifs = window.openSmartNotificationsModal;
  window.openSmartNotificationsModal = function () {
    if (!A.notificationAccess()) {
      toast('Allow Notification access for Mira, then reopen this');
      A.openNotifAccess();
      return origOpenNotifs();
    }
    try { phoneNotifications = JSON.parse(A.notifications()); } catch (e) {}
    origOpenNotifs();
    const imp = phoneNotifications.filter(function (n) { return n.isImportant; });
    const box = document.getElementById('notif-summary-text');
    if (!phoneNotifications.length) {
      if (box) box.textContent = 'এখনো কোনো নোটিফিকেশন ধরা পড়েনি। নতুন নোটিফিকেশন এলে এখানে দেখা যাবে।';
      return;
    }
    if (box) box.textContent = '…';
    const brief = imp.slice(0, 12).map(function (n) { return n.app + ' / ' + n.sender + ': ' + n.title + ' ' + n.desc; }).join('\n');
    nativeText('ask', 'এই ফোনে মোট ' + phoneNotifications.length + 'টি নোটিফিকেশন, ' + imp.length + 'টি দরকারি। বাংলায় ২টি ছোট বাক্যে সারাংশ দাও, শুধু দরকারিগুলো নিয়ে (ব্যাংক, OTP, পরিবার)। কোনো OTP কোড পড়ে শোনাবে না।\n' + (brief || '(কোনোটিই দরকারি নয়)'))
      .then(function (t) { if (box) box.textContent = t; })
      .catch(function () { if (box) box.textContent = phoneNotifications.length + 'টি নোটিফিকেশনের মধ্যে ' + imp.length + 'টি দরকারি।'; });
  };

  // ---- first-run wiring -----------------------------------------------------------
  function init() {
    try {
      const nk = A.getApiKey();
      if (nk && !localStorage.getItem('mira_gemini_api_key')) {
        localStorage.setItem('mira_gemini_api_key', nk);
        const f = document.getElementById('cfg-gemini-key');
        if (f) f.value = nk;
      }
    } catch (e) {}
    syncNativeSettings();
    try {
      A.importMemories(JSON.stringify(memories.map(function (m) { return { id: m.id, cat: m.cat, text: m.text }; })));
    } catch (e) {}
    const sv = document.getElementById('view-settings');
    if (sv && !document.getElementById('native-perm-card')) {
      const d = document.createElement('div');
      d.id = 'native-perm-card';
      d.className = 'hud-card rounded-3xl p-4 space-y-2';
      d.innerHTML = '<div class="text-xs font-semibold text-white">Phone Control Permissions</div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">All permissions in one page: microphone, contacts, calls (answer / call log), SMS, calendar, location, Accessibility, All files, Display over apps, Notification access, Battery, Exact alarms.</p>' +
        '<button class="w-full py-2.5 rounded-xl btn-minimal text-xs font-semibold" onclick="Android.openNativeSettings()">📱 Open All Permissions</button>';
      sv.appendChild(d);
    }
    if (sv && !document.getElementById('native-provider-card')) {
      const q = document.createElement('div');
      q.id = 'native-provider-card';
      q.className = 'hud-card rounded-3xl p-4 space-y-3';
      const inp = 'w-full h-9 px-3.5 rounded-xl bg-black/40 border border-white/[0.08] text-xs mono text-white focus:outline-none focus:border-cyan-400/50';
      const lbl = 'block text-[10px] font-medium uppercase tracking-wider text-slate-400 mb-1';
      q.innerHTML =
        '<div class="flex items-center justify-between gap-3"><div class="min-w-0">' +
        '<div class="text-sm font-semibold text-white">Serious mode · AI provider</div>' +
        '<p id="prov-note" class="text-[11px] text-slate-400 leading-relaxed"></p></div>' +
        '<button id="prov-switch" type="button" aria-label="toggle" style="width:50px;height:28px;border-radius:14px;position:relative;flex-shrink:0;border:0;transition:background .2s">' +
        '<span id="prov-knob" style="position:absolute;top:3px;width:22px;height:22px;border-radius:11px;background:#fff;transition:left .2s"></span></button></div>' +
        '<div id="prov-fields" class="space-y-2.5" style="display:none">' +
        '<div class="flex flex-wrap gap-1.5" id="prov-presets"></div>' +
        '<div><label class="' + lbl + '">Base URL</label><input id="prov-base" type="url" autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="https://openrouter.ai/api/v1" class="' + inp + '"></div>' +
        '<div><label class="' + lbl + '">API Key</label><input id="prov-key" type="password" autocapitalize="none" placeholder="sk-..." class="' + inp + '"></div>' +
        '<div><label class="' + lbl + '">Model <span id="prov-count" style="text-transform:none;letter-spacing:0;color:#34d399"></span></label><select id="prov-model" class="' + inp + '"><option value="">Auto (best available)</option></select></div>' +
        '<div class="flex gap-2 pt-1"><button id="prov-save" type="button" class="flex-1 py-2.5 rounded-xl hud-btn-pri text-xs font-semibold">Save</button>' +
        '<button id="prov-test" type="button" class="flex-1 py-2.5 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 text-xs font-semibold">⚡ Test</button></div>' +
        '<button id="prov-models" type="button" class="w-full py-2 rounded-xl btn-minimal text-[11px] font-semibold">🔄 Refresh model list</button>' +
        '<div class="flex gap-2"><button id="prov-serious" type="button" class="flex-1 py-2.5 rounded-xl btn-minimal text-xs font-semibold">Serious mode: OFF</button>' +
        '<button id="prov-history" type="button" class="flex-1 py-2.5 rounded-xl btn-minimal text-xs font-semibold">📁 History</button></div>' +
        '<div id="prov-result" class="mono text-[10px] text-slate-500 break-words"></div></div>';
      sv.appendChild(q);
      const $ = function (id) { return q.querySelector('#' + id); };
      let cfg = { on: false, base: '', key: '', model: '' };
      try { cfg = JSON.parse(A.getProvider()); } catch (e) {}
      $('prov-base').value = cfg.base || ''; $('prov-key').value = cfg.key || '';
      if (cfg.model) { const o0 = document.createElement('option'); o0.value = cfg.model; o0.textContent = cfg.model; $('prov-model').appendChild(o0); $('prov-model').value = cfg.model; }
      [['OpenRouter', 'https://openrouter.ai/api/v1'], ['OpenAI', 'https://api.openai.com/v1'], ['Groq', 'https://api.groq.com/openai/v1'], ['DeepSeek', 'https://api.deepseek.com/v1']].forEach(function (p) {
        const b = document.createElement('button'); b.type = 'button'; b.textContent = p[0];
        b.className = 'px-2.5 py-1 rounded-lg btn-minimal text-[10px] font-semibold';
        b.onclick = function () { $('prov-base').value = p[1]; };
        $('prov-presets').appendChild(b);
      });
      function paint() {
        const on = !!cfg.on;
        $('prov-switch').style.background = on ? '#06b6d4' : 'rgba(255,255,255,.15)';
        $('prov-knob').style.left = on ? '25px' : '3px';
        $('prov-fields').style.display = on ? 'block' : 'none';
        $('prov-note').textContent = on
          ? 'Everyday chat and voice stay on Gemini. Say "Mira, serious mode" and big jobs (websites, design, research, leads) go to this provider. Saved files go to the Downloads folder of your phone.'
          : 'Off. Everything uses Gemini (the Gemini API key above is enough).';
      }
      function save() {
        cfg.base = $('prov-base').value.trim(); cfg.key = $('prov-key').value.trim(); cfg.model = $('prov-model').value;
        try { A.setProvider(!!cfg.on, cfg.base, cfg.key, cfg.model); } catch (e) {}
      }
      $('prov-switch').onclick = function () { cfg.on = !cfg.on; save(); paint(); showToast(cfg.on ? 'Other provider ON' : 'Gemini only'); if (cfg.on && cfg.base && cfg.key) loadModels(true); };
      $('prov-save').onclick = function () {
        save();
        if (!/^https?:\/\//.test(cfg.base)) { showToast('Base URL must start with https://'); return; }
        if (!cfg.key) { showToast('Fill the API key'); return; }
        showToast('Saved'); loadModels(true);
      };
      $('prov-test').onclick = function () {
        save();
        const r = $('prov-result'); r.textContent = 'Testing...';
        const id = reg(function (p) {
          let o; try { o = JSON.parse(p); } catch (e) { o = { ok: false, text: String(p) }; }
          r.textContent = (o.ok ? '✅ Works: ' : '❌ ') + o.text;
        });
        try { A.testProvider(id); } catch (e) { r.textContent = '❌ ' + e; }
      };
      function loadModels(silent) {
        save();
        if (!/^(https?:\/\/)?[^\s\/]+\.[^\s]+/.test(cfg.base) || !cfg.key) { if (!silent) showToast('Enter the Base URL and API key first'); return; }
        const r = $('prov-result'); r.textContent = 'Looking for the models of this key...';
        const id = reg(function (p) {
          let o; try { o = JSON.parse(p); } catch (e) { o = { ok: false, text: String(p) }; }
          if (!o.ok) { $('prov-count').textContent = ''; r.textContent = '❌ ' + o.text; return; }
          let d = {}; try { d = JSON.parse(o.text); } catch (e) {}
          const ids = d.models || [], sel = $('prov-model'), keep = sel.value;
          sel.innerHTML = '';
          const a0 = document.createElement('option'); a0.value = ''; a0.textContent = 'Auto (best): ' + (d.auto || '-'); sel.appendChild(a0);
          ids.forEach(function (m) { const op = document.createElement('option'); op.value = m; op.textContent = m; sel.appendChild(op); });
          sel.value = ids.indexOf(keep) >= 0 ? keep : '';
          $('prov-count').textContent = '· ' + ids.length + ' active';
          r.textContent = '✅ ' + ids.length + ' models are active on this key. Auto picks: ' + (d.auto || '-');
          save();
        });
        try { A.listProviderModels(id); } catch (e) { r.textContent = '❌ ' + e; }
      }
      $('prov-models').onclick = function () { loadModels(false); };
      $('prov-model').onchange = function () { save(); showToast($('prov-model').value ? 'Model: ' + $('prov-model').value : 'Auto model'); };
      $('prov-key').onchange = function () { $('prov-model').value = ''; loadModels(true); };
      $('prov-base').onchange = function () { $('prov-model').value = ''; loadModels(true); };
      if (cfg.on && cfg.base && cfg.key) setTimeout(function () { loadModels(true); }, 1200);
      function paintSerious() {
        let on = false; try { on = A.isSerious(); } catch (e) {}
        const b = $('prov-serious'); b.textContent = 'Serious mode: ' + (on ? 'ON' : 'OFF');
        b.className = 'flex-1 py-2.5 rounded-xl text-xs font-semibold ' + (on ? 'hud-btn-pri' : 'btn-minimal');
        const d = document.getElementById('mira-dot'); if (d) d.style.outline = on ? '2px solid #a78bfa' : 'none';
        d && (d.style.outlineOffset = '2px');
      }
      $('prov-serious').onclick = function () {
        let on = false; try { on = A.isSerious(); } catch (e) {}
        let ok = true; try { ok = A.setSerious(!on); } catch (e) {}
        if (!ok) showToast('Add the Base URL and API key first');
        paintSerious();
      };
      $('prov-history').onclick = function () { if (window.__miraHistory) window.__miraHistory(); };
      paintSerious();
      setInterval(paintSerious, 3000);
      paint();
    }
    if (sv && !document.getElementById('native-debug-card')) {
      const g = document.createElement('div');
      g.id = 'native-debug-card';
      g.className = 'hud-card rounded-3xl p-4 space-y-2';
      g.innerHTML = '<div class="text-xs font-semibold text-white">Debugger</div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">Live log, last crash report and a one-tap self-test of the API key, voice, live connection, permissions and wake word.</p>' +
        '<button class="w-full py-2.5 rounded-xl btn-minimal text-xs font-semibold" onclick="Android.openDebug()">🛠 Open Debugger</button>';
      sv.appendChild(g);
    }
    if (sv && !document.getElementById('native-backup-card')) {
      const bk = document.createElement('div');
      bk.id = 'native-backup-card';
      bk.className = 'hud-card rounded-3xl p-4 space-y-2';
      bk.innerHTML = '<div class="text-xs font-semibold text-white">Backup &amp; Restore</div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">Saves your settings, memories, expenses and reminders as one file in Downloads (Mira-backup-DATE.json). API keys are NOT included unless you choose so. Restore uses the newest backup file.</p>' +
        '<div class="flex gap-2"><button id="bk-save" class="flex-1 py-2.5 rounded-xl btn-minimal text-xs font-semibold">Backup</button>' +
        '<button id="bk-keys" class="flex-1 py-2.5 rounded-xl btn-minimal text-xs font-semibold">Backup + keys</button>' +
        '<button id="bk-restore" class="flex-1 py-2.5 rounded-xl btn-minimal text-xs font-semibold">Restore</button></div>';
      sv.appendChild(bk);
      bk.querySelector('#bk-save').onclick = function () { window.__miraBackup(false); };
      bk.querySelector('#bk-keys').onclick = function () { window.__miraBackup(true); };
      let armed = 0;
      const rb = bk.querySelector('#bk-restore');
      rb.onclick = function () {
        if (!armed) { armed = 1; rb.textContent = 'Tap again to confirm'; setTimeout(function () { armed = 0; rb.textContent = 'Restore'; }, 4000); return; }
        armed = 0; rb.textContent = 'Restore'; window.__miraRestore();
      };
    }
    if (sv && !document.getElementById('native-sip-card')) {
      const sp = document.createElement('div');
      sp.id = 'native-sip-card';
      sp.className = 'hud-card rounded-3xl p-4 space-y-2';
      let c0 = {}; try { c0 = JSON.parse(A.getSip()); } catch (e) {}
      const inp = 'w-full h-9 px-3 rounded-xl bg-black/50 border border-white/[0.08] text-xs text-white focus:outline-none';
      sp.innerHTML = '<div class="text-xs font-semibold text-white">IP Phone (SIP) <span id="sip-st" style="font-weight:400;opacity:.6"></span></div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">Needs the SIP server, number/username and password (if any) from your IP-phone provider. Mira can then answer IP calls and speak to the caller. Leave password empty if your provider gives none.</p>' +
        '<input id="sip-server" class="' + inp + '" placeholder="SIP server (e.g. sip.provider.com)">' +
        '<input id="sip-user" class="' + inp + '" placeholder="Number / username">' +
        '<input id="sip-auth" class="' + inp + '" placeholder="Auth username (only if different)">' +
        '<input id="sip-pass" type="password" class="' + inp + '" placeholder="Password (if any)">' +
        '<div class="flex gap-2"><button id="sip-on" class="flex-1 py-2.5 rounded-xl btn-minimal text-xs font-semibold">Save &amp; Connect</button>' +
        '<button id="sip-off" class="flex-1 py-2.5 rounded-xl btn-minimal text-xs font-semibold">Disconnect</button></div>';
      sv.appendChild(sp);
      const g = function (i) { return sp.querySelector('#' + i); };
      g('sip-server').value = c0.server || ''; g('sip-user').value = c0.user || ''; g('sip-auth').value = c0.auth || ''; g('sip-pass').value = c0.pass || '';
      const paint = function () { let st = ''; try { st = A.sipStatus(); } catch (e) {} g('sip-st').textContent = '· ' + st; };
      paint(); setInterval(paint, 3000);
      const go = function (on) {
        let host = g('sip-server').value.trim(), port = 5060;
        const m = host.match(/^(.*):(\d+)$/); if (m) { host = m[1]; port = +m[2]; }
        try { A.setSip(on, host, port, g('sip-user').value, g('sip-auth').value, g('sip-pass').value); } catch (e) {}
        (window.showToast || alert)(on ? 'Connecting IP phone...' : 'IP phone off');
      };
      g('sip-on').onclick = function () { go(true); };
      g('sip-off').onclick = function () { go(false); };
    }
    if (sv && !document.getElementById('native-model-card')) {
      const m = document.createElement('div');
      m.id = 'native-model-card';
      m.className = 'hud-card rounded-3xl p-4 space-y-2';
      let cur = ''; try { cur = A.getLiveModel(); } catch (e) {}
      m.innerHTML = '<div class="text-xs font-semibold text-white">Live Voice Model</div>' +
        '<select id="native-live-model" class="w-full h-9 px-3 rounded-xl bg-black/50 border border-white/[0.08] text-xs text-white focus:outline-none">' +
        '<option value="">Auto (best available)</option>' +
        '<option value="models/gemini-3.1-flash-live-preview">Gemini 3.1 Flash Live</option>' +
        '<option value="models/gemini-2.5-flash-native-audio-preview-12-2025">Gemini 2.5 Native Audio (Dec 2025)</option>' +
        '<option value="models/gemini-2.5-flash-native-audio-preview-09-2025">Gemini 2.5 Native Audio (Sep 2025)</option></select>';
      sv.appendChild(m);
      const sel = m.querySelector('select');
      sel.value = cur || '';
      sel.onchange = function () { try { A.setLiveModel(sel.value); showToast('Model saved'); } catch (e) {} };
    }
    if (sv && !document.getElementById('mira-ver')) {
      const v = document.createElement('div');
      v.id = 'mira-ver';
      v.style.cssText = 'text-align:center;font-size:11px;letter-spacing:.14em;color:#67e8f9;opacity:.8;padding:10px 0';
      v.textContent = 'MIRA ULTRA PRO MAX';
      sv.appendChild(v);
    }
    if (sv && !document.getElementById('native-wake-card')) {
      const w = document.createElement('div');
      w.id = 'native-wake-card';
      w.className = 'hud-card rounded-3xl p-4 space-y-2';
      w.innerHTML = '<div class="flex items-center justify-between gap-3"><div class="min-w-0">' +
        '<div class="text-xs font-semibold text-white">Hey Mira wake word</div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">Say "Hey Mira" or "Hey Jarvis" any time, even with the screen locked or on the home screen. Uses the microphone in the background, so it costs some battery. Switch it off when you do not need it.</p></div>' +
        '<button id="native-wake-btn" class="px-4 py-2 rounded-xl btn-minimal text-xs font-semibold flex-shrink-0">OFF</button></div>' +
        '<div id="native-wake-heard" class="mono text-[10px] text-slate-500 truncate">Heard: (switch ON and speak)</div>';
      sv.appendChild(w);
      const btn = w.querySelector('#native-wake-btn');
      let on = false; try { on = A.isWake(); } catch (e) {}
      function paintWake(v) {
        on = v;
        btn.textContent = v ? 'ON' : 'OFF';
        btn.className = 'px-4 py-2 rounded-xl text-xs font-semibold flex-shrink-0 ' + (v ? 'hud-btn-pri' : 'btn-minimal');
      }
      window.__wakeUi = paintWake;
      paintWake(on);
      btn.onclick = function () { paintWake(!on); try { A.setWake(on); } catch (e) {} };
    }
    // ---- one tiny status dot on the hologram: green = ready / listening, red = answering ----
    (function () {
      const holo = document.getElementById('holo-canvas');
      if (!holo || document.getElementById('mira-dot')) return;
      const host = holo.parentNode;
      const d = document.createElement('div');
      d.id = 'mira-dot';
      d.style.cssText = 'position:absolute;top:6px;right:8px;width:11px;height:11px;border-radius:50%;z-index:15;' +
        'background:#34d399;box-shadow:0 0 10px #34d399;transition:background .25s,box-shadow .25s';
      host.appendChild(d);
      let pulse = 0;
      function paint(st) {
        const u = String(st || '').toUpperCase();
        let c = '#34d399';
        if (!u.includes('LISTEN') && (u.includes('SPEAK') || u.includes('THINK') || u.includes('PROCESS') || u.includes('ANSWER'))) c = '#f43f5e';
        d.style.background = c;
        d.style.boxShadow = '0 0 10px ' + c;
        d.style.animation = (u.includes('LISTEN') || c === '#f43f5e') ? 'miraDotPulse 1.1s ease-in-out infinite' : 'none';
      }
      const st = document.createElement('style');
      st.textContent = '@keyframes miraDotPulse{0%,100%{opacity:1}50%{opacity:.35}}';
      document.head.appendChild(st);
      const origStatus = window.setAvatarStatus;
      window.setAvatarStatus = function (s) { try { origStatus(s); } catch (e) {} paint(s); };
      paint(avatarState && avatarState.status);
    })();
    // ---- 8 real Gemini human voices, picked in Settings only ------------------
    const CAT = [
      ['Aoede', 'female', 'Warm, expressive and natural female (Mira default)', 'Hello! I am Mira, speaking with the Aoede voice.', 'আসসালামু আলাইকুম বস, আমি মিরা। আমি আওয়েদে ভয়েসে কথা বলছি।'],
      ['Kore', 'female', 'Crisp, clear and articulate female', 'Greetings! This is the Kore voice, clear and ready.', 'হ্যালো বস, আমি কোরে ভয়েসে কথা বলছি। বলুন, কী করতে পারি?'],
      ['Leda', 'female', 'Gentle, soft and soothing female', 'Hello! This is the Leda voice, calm and listening.', 'হ্যালো বস, আমি লেডা ভয়েসে কথা বলছি। আপনার নির্দেশের অপেক্ষায় আছি।'],
      ['Zephyr', 'female', 'Bright, energetic and lively female', 'Hi there! This is the Zephyr voice, bright and ready to talk.', 'হ্যালো বস! আমি জেফির ভয়েসে কথা বলছি। আজ কী নিয়ে কাজ করব?'],
      ['Charon', 'male', 'Deep, calm and authoritative male', 'All systems are operational. This is the Charon voice.', 'হ্যালো বস, আমি শ্যারন ভয়েসে কথা বলছি। সব সিস্টেম সচল আছে।'],
      ['Puck', 'male', 'Upbeat, friendly and conversational male', 'Hey there! This is the Puck voice, ready to help.', 'হ্যালো বস! আমি পাক ভয়েসে কথা বলছি, যেকোনো কাজের জন্য প্রস্তুত।'],
      ['Fenrir', 'male', 'Strong, resonant and tactical male', 'Standing by. This is the Fenrir voice.', 'হ্যালো বস, আমি ফেনরির ভয়েসে কথা বলছি। সিস্টেম কন্ট্রোল প্রস্তুত।'],
      ['Orus', 'male', 'Calm, steady and balanced male', 'Systems nominal. This is the Orus voice.', 'হ্যালো বস, আমি ওরাস ভয়েসে কথা বলছি। সব মডিউল স্বাভাবিক।'],
      ['Algenib', 'male', 'Gravelly, deep and heavy - most serious (Serious mode default)', 'Understood. This is the Algenib voice.', 'বুঝেছি। আমি অ্যালগেনিব ভয়েসে কথা বলছি।'],
      ['Alnilam', 'male', 'Firm, steady and commanding male', 'Understood. This is the Alnilam voice.', 'বুঝেছি। আমি অ্যালনিলাম ভয়েসে কথা বলছি।'],
      ['Rasalgethi', 'male', 'Low, measured and informative male', 'This is the Rasalgethi voice.', 'আমি রাসালগেথি ভয়েসে কথা বলছি।'],
      ['Gacrux', 'male', 'Mature, weighty and calm male', 'This is the Gacrux voice.', 'আমি গ্যাক্রাক্স ভয়েসে কথা বলছি।'],
      ['Iapetus', 'male', 'Clear, even and formal male', 'This is the Iapetus voice.', 'আমি আইয়াপেটাস ভয়েসে কথা বলছি।'],
      ['Umbriel', 'male', 'Low, easy-going and steady male', 'This is the Umbriel voice.', 'আমি আম্ব্রিয়েল ভয়েসে কথা বলছি।']
    ];
    const VM = {};
    CAT.forEach(function (v) {
      VM[v[0]] = { id: v[0], name: v[0], badge: v[0].toUpperCase() + ' · ' + v[1].toUpperCase(), gender: v[1], geminiVoice: v[0],
        pitch: 1, rate: 1, fallbackRate: 1, preferredNames: [], demoEn: v[3], demoBn: v[4], desc: v[2] };
    });
    let curVoice = 'Aoede';
    try { const sv0 = localStorage.getItem('mira_live_voice'); if (sv0 && VM[sv0]) curVoice = sv0; } catch (e) {}
    window.getCurrentVoiceModel = function () { return VM[curVoice]; };
    function applyVoice(name, demo) {
      if (!VM[name]) return;
      curVoice = name;
      try { localStorage.setItem('mira_live_voice', name); } catch (e) {}
      try { A.setVoice(name); } catch (e) {}
      renderVoices();
      if (demo) {
        const bn = /[ঀ-৿]/.test((document.getElementById('chat-input') || {}).value || '') ||
          ((localStorage.getItem('mira_lang') || '') === 'bn');
        syncNativeSettings();
        try { A.demoVoice(name, bn ? VM[name].demoBn : VM[name].demoEn); } catch (e) {}
        showToast('Playing ' + name);
      } else { showToast('Voice saved: ' + name); }
    }
    window.selectAndDemoVoiceModel = function (id, demo) {
      const name = VM[id] ? id : (id === 'female_2' ? 'Kore' : id === 'male_1' ? 'Charon' : 'Aoede');
      applyVoice(name, !!demo);
    };
    function renderVoices() {
      const sel = document.getElementById('cfg-voice-name');
      if (sel) {
        sel.innerHTML = CAT.map(function (v) { return '<option value="' + v[0] + '">' + (v[1] === 'female' ? '👩 ' : '👨 ') + v[0] + ' — ' + v[2] + '</option>'; }).join('');
        sel.value = curVoice;
        sel.onchange = function () { applyVoice(sel.value, true); };
      }
      const pill = document.getElementById('active-voice-pill');
      if (pill) pill.textContent = VM[curVoice].badge;
      const first = document.getElementById('voice-card-female_1');
      let box = document.getElementById('native-voice-grid');
      if (!box && first) {
        box = document.createElement('div');
        box.id = 'native-voice-grid';
        box.className = 'grid grid-cols-1 gap-2';
        first.parentNode.parentNode.insertBefore(box, first.parentNode);
        first.parentNode.style.display = 'none';
      }
      if (box) {
        box.innerHTML = CAT.map(function (v) {
          const on = v[0] === curVoice;
          return '<div class="rounded-2xl p-3 border flex items-center justify-between gap-2 ' +
            (on ? 'bg-cyan-500/15 border-cyan-400/50' : 'bg-white/[0.03] border-white/[0.08]') + '">' +
            '<div class="min-w-0" onclick="selectAndDemoVoiceModel(\'' + v[0] + '\', false)" style="flex:1;cursor:pointer">' +
            '<div class="text-xs font-semibold text-white">' + (v[1] === 'female' ? '👩 ' : '👨 ') + v[0] + (on ? ' ✓' : '') + '</div>' +
            '<div class="text-[10px] text-slate-400">' + v[2] + '</div></div>' +
            '<button class="px-3 py-1.5 rounded-xl hud-btn-pri text-[10px] font-semibold flex-shrink-0" onclick="selectAndDemoVoiceModel(\'' + v[0] + '\', true)">▶ Test</button></div>';
        }).join('');
      }
    }
    // ---- separate deep voice used only while Serious mode is on ---------------
    const SER = [
      ['Algenib', 'Gravelly, deep and heavy - the most serious tone (default)', 'Understood. I am treating this as a serious matter.', 'বুঝেছি। আমি বিষয়টাকে অত্যন্ত গুরুত্ব দিয়ে নিচ্ছি।'],
      ['Alnilam', 'Firm, steady and commanding', 'Understood. Proceeding with full attention.', 'বুঝেছি। পূর্ণ মনোযোগ দিয়ে কাজ শুরু করছি।'],
      ['Charon', 'Deep, calm and authoritative', 'All systems are operational. Serious mode engaged.', 'সব সিস্টেম সচল। সিরিয়াস মোড চালু।'],
      ['Rasalgethi', 'Informative, low and measured', 'This requires care. I am on it.', 'এটাতে সতর্কতা দরকার। আমি দেখছি।'],
      ['Gacrux', 'Mature, weighty and calm', 'I have the details. Let us proceed carefully.', 'আমার কাছে সব তথ্য আছে। সাবধানে এগোই।'],
      ['Orus', 'Calm, steady and balanced', 'Systems nominal. Serious mode engaged.', 'সব মডিউল স্বাভাবিক। সিরিয়াস মোড চালু।'],
      ['Fenrir', 'Strong, resonant and tactical', 'Standing by. Serious mode engaged.', 'প্রস্তুত আছি। সিরিয়াস মোড চালু।'],
      ['Iapetus', 'Clear, even and formal', 'Task received. Working on it now.', 'কাজ পেয়েছি। এখনই শুরু করছি।'],
      ['Umbriel', 'Easy-going but low and steady', 'Understood. I will handle this.', 'বুঝেছি। আমি সামলে নিচ্ছি।']
    ];
    let serVoice = 'Algenib';
    try { serVoice = A.getSeriousVoice() || 'Algenib'; } catch (e) {}
    function renderSerious() {
      let box = document.getElementById('native-serious-voice');
      if (!box) {
        const host = document.getElementById('native-voice-grid');
        if (!host) return;
        box = document.createElement('div');
        box.id = 'native-serious-voice';
        box.className = 'grid grid-cols-1 gap-2';
        box.style.marginTop = '14px';
        host.parentNode.insertBefore(box, host.nextSibling);
      }
      box.innerHTML = '<div class="text-xs font-semibold text-white" style="margin-bottom:2px">🎙 Serious mode voice (heavy, deep tone)</div>' +
        '<div class="text-[10px] text-slate-400" style="margin-bottom:6px">Used automatically only while Serious mode is on. Applies from the next voice session.</div>' +
        SER.map(function (v) {
          const on = v[0] === serVoice;
          return '<div class="rounded-2xl p-3 border flex items-center justify-between gap-2 ' +
            (on ? 'bg-rose-500/15 border-rose-400/50' : 'bg-white/[0.03] border-white/[0.08]') + '">' +
            '<div class="min-w-0" onclick="miraPickSerious(\'' + v[0] + '\', false)" style="flex:1;cursor:pointer">' +
            '<div class="text-xs font-semibold text-white">👨 ' + v[0] + (on ? ' ✓' : '') + '</div>' +
            '<div class="text-[10px] text-slate-400">' + v[1] + '</div></div>' +
            '<button class="px-3 py-1.5 rounded-xl hud-btn-pri text-[10px] font-semibold flex-shrink-0" onclick="miraPickSerious(\'' + v[0] + '\', true)">▶ Test</button></div>';
        }).join('');
    }
    window.miraPickSerious = function (name, demo) {
      const row = SER.find(function (v) { return v[0] === name; });
      if (!row) return;
      serVoice = name;
      try { A.setSeriousVoice(name); } catch (e) {}
      renderSerious();
      if (demo) {
        const bn = ((localStorage.getItem('mira_lang') || '') === 'bn');
        try { A.demoVoice(name, bn ? row[3] : row[2]); } catch (e) {}
        showToast('Playing ' + name);
      } else { showToast('Serious voice saved: ' + name); }
    };
    const _rv = renderVoices;
    renderVoices = function () { _rv(); renderSerious(); };
    renderVoices();
    try { A.setVoice(curVoice); } catch (e) {}
    try { A.pageReady(); } catch (e) {}
  }
  if (document.readyState === 'complete') setTimeout(init, 400);
  else window.addEventListener('load', function () { setTimeout(init, 400); });

  // ---- Prayer times & expense book: bottom sheets instead of plain chat text ------------------
  (function () {
    const css = document.createElement('style');
    css.textContent =
      '#mira-sheet{position:fixed;inset:0;z-index:60;display:none;align-items:flex-end;justify-content:center;background:rgba(2,5,10,.72)}' +
      '#mira-sheet.on{display:flex}' +
      '#mira-sheet .pn{width:100%;max-width:460px;max-height:88vh;overflow:auto;border-radius:28px 28px 0 0;background:linear-gradient(180deg,#121b2b,#0a1019);border:1px solid rgba(255,255,255,.08);border-bottom:0;padding:10px 18px 28px;animation:msUp .22s ease-out}' +
      '@keyframes msUp{from{transform:translateY(40px);opacity:.4}to{transform:none;opacity:1}}' +
      '#mira-sheet .gr{width:42px;height:4px;border-radius:2px;background:rgba(255,255,255,.18);margin:4px auto 14px}' +
      '#mira-sheet h3{font-size:17px;font-weight:700;color:#fff;margin:0}' +
      '#mira-sheet .sub{font-size:11px;color:#7f90a6;margin-top:2px}' +
      '#mira-sheet .x{position:absolute;right:14px;top:14px;width:32px;height:32px;border-radius:16px;background:rgba(255,255,255,.07);color:#cbd5e1;border:0;font-size:16px}' +
      '#mira-sheet .hero{margin:16px 0 12px;padding:16px;border-radius:20px;background:linear-gradient(135deg,rgba(6,182,212,.18),rgba(16,185,129,.10));border:1px solid rgba(34,211,238,.25)}' +
      '#mira-sheet .hero .k{font-size:11px;color:#7dd3fc;letter-spacing:.12em;text-transform:uppercase}' +
      '#mira-sheet .hero .v{font-size:26px;font-weight:700;color:#fff;margin-top:4px}' +
      '#mira-sheet .hero .s{font-size:12px;color:#a5b4c8;margin-top:2px}' +
      '#mira-sheet .row{display:flex;justify-content:space-between;align-items:center;padding:13px 14px;border-radius:14px;margin-bottom:6px;background:rgba(255,255,255,.035);font-size:14px;color:#dbe4f0}' +
      '#mira-sheet .row.nx{background:rgba(6,182,212,.16);border:1px solid rgba(34,211,238,.4);color:#fff;font-weight:600}' +
      '#mira-sheet .row.pt{opacity:.5}' +
      '#mira-sheet .row .t{font-variant-numeric:tabular-nums;font-weight:600}' +
      '#mira-sheet input{width:100%;height:46px;border-radius:14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:#fff;font-size:16px;padding:0 14px;outline:none}' +
      '#mira-sheet input:focus{border-color:rgba(34,211,238,.6);box-shadow:0 0 0 3px rgba(34,211,238,.12)}' +
      '#mira-sheet .chip{padding:7px 12px;border-radius:999px;font-size:12px;background:rgba(255,255,255,.06);color:#cbd5e1;border:1px solid transparent}' +
      '#mira-sheet .chip.on{background:rgba(6,182,212,.22);border-color:rgba(34,211,238,.5);color:#fff}' +
      '#mira-sheet .go{width:100%;height:46px;border-radius:14px;border:0;font-size:14px;font-weight:700;color:#04121a;background:linear-gradient(135deg,#22d3ee,#34d399)}' +
      '#mira-sheet .bars{display:flex;align-items:flex-end;gap:6px;height:64px;margin:6px 0 4px}' +
      '#mira-sheet .bars div{flex:1;border-radius:6px 6px 3px 3px;background:rgba(34,211,238,.35);min-height:3px}' +
      '#mira-sheet .bars div.today{background:linear-gradient(180deg,#22d3ee,#34d399)}' +
      '#mira-sheet .days{display:flex;gap:6px;font-size:9px;color:#7f90a6;text-align:center}' +
      '#mira-sheet .days span{flex:1}' +
      '#mira-sheet .del{border:0;background:transparent;color:#f87171;font-size:18px;padding:0 4px}';
    document.head.appendChild(css);
    const host = document.createElement('div');
    host.id = 'mira-sheet';
    host.innerHTML = '<div class="pn" style="position:relative"><button class="x" aria-label="close">✕</button><div id="ms-body"></div></div>';
    document.body.appendChild(host);
    const body = host.querySelector('#ms-body');
    let timer = null;
    function close() { host.classList.remove('on'); if (timer) { clearInterval(timer); timer = null; } }
    host.addEventListener('click', function (e) { if (e.target === host) close(); });
    host.querySelector('.x').onclick = close;
    function open() { host.classList.add('on'); }
    const esc = function (t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
    const bn = function (n) { return String(n).replace(/\d/g, function (d) { return '০১২৩৪৫৬৭৮৯'[d]; }); };

    // ---------------- prayer times
    const NAMES = [['Fajr', 'ফজর'], ['Sunrise', 'সূর্যোদয়'], ['Dhuhr', 'যোহর'], ['Asr', 'আসর'], ['Maghrib', 'মাগরিব'], ['Isha', 'এশা']];
    const FALLBACK = { Fajr: '04:52', Sunrise: '06:08', Dhuhr: '11:46', Asr: '15:45', Maghrib: '17:15', Isha: '18:33' };
    function mins(t) { const m = /(\d{1,2}):(\d{2})/.exec(t || ''); return m ? (+m[1]) * 60 + (+m[2]) : null; }
    function f12(t) { const m = mins(t); if (m === null) return '--'; const h = Math.floor(m / 60), mm = m % 60; return ((h % 12) || 12) + ':' + String(mm).padStart(2, '0') + ' ' + (h < 12 ? 'AM' : 'PM'); }
    function dur(m) { const h = Math.floor(m / 60), mm = m % 60; return (h ? bn(h) + ' ঘণ্টা ' : '') + bn(mm) + ' মিনিট'; }
    function drawPrayer(tm, live) {
      const now = new Date(), cur = now.getHours() * 60 + now.getMinutes();
      let nx = -1;
      for (let i = 0; i < NAMES.length; i++) { if (NAMES[i][0] === 'Sunrise') continue; if (mins(tm[NAMES[i][0]]) > cur) { nx = i; break; } }
      let hero;
      if (nx >= 0) hero = '<div class="k">পরবর্তী নামাজ</div><div class="v">' + NAMES[nx][1] + ' · ' + f12(tm[NAMES[nx][0]]) + '</div><div class="s">আর ' + dur(mins(tm[NAMES[nx][0]]) - cur) + ' বাকি</div>';
      else hero = '<div class="k">আজকের নামাজ শেষ</div><div class="v">ফজর · ' + f12(tm.Fajr) + '</div><div class="s">আগামীকাল ফজর</div>';
      const rows = NAMES.map(function (n, i) {
        const cls = i === nx ? 'nx' : (mins(tm[n[0]]) <= cur ? 'pt' : '');
        return '<div class="row ' + cls + '"><span>' + n[1] + ' <span style="opacity:.55;font-size:11px">' + n[0] + '</span></span><span class="t">' + f12(tm[n[0]]) + '</span></div>';
      }).join('');
      body.innerHTML = '<h3>🕌 নামাজের সময়</h3><div class="sub">ছাতক, সিলেট · ' + new Date().toLocaleDateString('bn-BD') + (live ? '' : ' · অফলাইন সময়') + '</div>' +
        '<div class="hero">' + hero + '</div>' + rows;
    }
    window.getLivePrayerTimes = async function () {
      open();
      const d = new Date(), key = 'mira_prayer_' + d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate();
      let tm = null, live = true;
      try { tm = JSON.parse(localStorage.getItem(key) || 'null'); } catch (e) {}
      if (tm) drawPrayer(tm, true); else body.innerHTML = '<h3>🕌 নামাজের সময়</h3><div class="sub">সময় আনা হচ্ছে…</div>';
      if (!tm) {
        try {
          const r = await fetch('https://api.aladhan.com/v1/timings/' + d.getDate() + '-' + (d.getMonth() + 1) + '-' + d.getFullYear() + '?latitude=25.04&longitude=91.67&method=1&school=1');
          const j = await r.json();
          if (j && j.data && j.data.timings) { tm = j.data.timings; try { localStorage.setItem(key, JSON.stringify(tm)); } catch (e) {} }
        } catch (e) {}
      }
      if (!tm) { tm = FALLBACK; live = false; }
      drawPrayer(tm, live);
      if (timer) clearInterval(timer);
      timer = setInterval(function () { drawPrayer(tm, live); }, 30000);
      try { speakJarvisReply('Ajker namajer somoy: Fajr ' + f12(tm.Fajr) + ', Dhuhr ' + f12(tm.Dhuhr) + ', Asr ' + f12(tm.Asr) + ', Maghrib ' + f12(tm.Maghrib) + ', Isha ' + f12(tm.Isha) + '.'); } catch (e) {}
    };

    // ---------------- expense book
    const CATS = ['বাজার', 'খাবার', 'যাতায়াত', 'বিল', 'মোবাইল', 'অন্যান্য'];
    let pickCat = CATS[0];
    let own = null;
    function ex() {
      try { if (typeof expenses !== 'undefined' && Array.isArray(expenses)) return expenses; } catch (e) {}
      if (!own) { try { own = JSON.parse(localStorage.getItem('mira_expenses') || '[]'); } catch (e) { own = []; } }
      return own;
    }
    function save() { try { localStorage.setItem('mira_expenses', JSON.stringify(ex())); } catch (e) {} }
    function dayStr(back) { return new Date(Date.now() - back * 864e5).toLocaleDateString(); }
    function drawExpense() {
      const list = ex(), today = dayStr(0);
      const sum = function (d) { return list.filter(function (x) { return x.date === d; }).reduce(function (a, b) { return a + (+b.amount || 0); }, 0); };
      const week = []; for (let i = 6; i >= 0; i--) week.push(sum(dayStr(i)));
      const mx = Math.max.apply(null, week.concat([1]));
      const m = new Date().getMonth(), y = new Date().getFullYear();
      let month = 0; list.forEach(function (x) { const t = new Date(x.id && /\d{10,}/.test(x.id) ? +/\d{10,}/.exec(x.id)[0] : 0); if (t.getMonth() === m && t.getFullYear() === y) month += (+x.amount || 0); });
      const dn = ['র', 'সো', 'ম', 'বু', 'বৃ', 'শু', 'শ'];
      const dl = []; for (let i = 6; i >= 0; i--) dl.push('<span>' + dn[new Date(Date.now() - i * 864e5).getDay()] + '</span>');
      const rows = list.slice(0, 25).map(function (e, i) {
        return '<div class="row"><span>' + esc(e.category) + ' <span style="opacity:.5;font-size:11px">' + esc(e.date) + '</span></span><span><span class="t">৳' + esc(e.amount) + '</span> <button class="del" data-i="' + i + '" aria-label="delete">×</button></span></div>';
      }).join('') || '<div class="sub" style="padding:10px 2px">এখনো কোনো খরচ লেখা হয়নি।</div>';
      body.innerHTML = '<h3>💰 হিসাব খাতা</h3><div class="sub">আজকের খরচ, এই সপ্তাহ আর মাস এক নজরে</div>' +
        '<div class="hero"><div class="k">আজকের মোট খরচ</div><div class="v">৳' + sum(today) + '</div><div class="s">এই মাসে মোট ৳' + month + '</div>' +
        '<div class="bars">' + week.map(function (v, i) { return '<div class="' + (i === 6 ? 'today' : '') + '" style="height:' + Math.max(5, Math.round(v / mx * 100)) + '%"></div>'; }).join('') + '</div><div class="days">' + dl.join('') + '</div></div>' +
        '<div style="display:flex;gap:8px;margin-bottom:10px"><input id="ex-amt" type="number" inputmode="decimal" placeholder="কত টাকা?" style="flex:1"></div>' +
        '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">' + CATS.map(function (c) { return '<button class="chip ' + (c === pickCat ? 'on' : '') + '" data-c="' + c + '">' + c + '</button>'; }).join('') + '</div>' +
        '<button class="go" id="ex-add">খরচ যোগ করুন</button>' +
        '<div class="sub" style="margin:18px 0 8px">সাম্প্রতিক খরচ</div>' + rows;
      body.querySelectorAll('.chip').forEach(function (b) { b.onclick = function () { pickCat = b.dataset.c; body.querySelectorAll('.chip').forEach(function (x) { x.classList.toggle('on', x === b); }); }; });
      body.querySelector('#ex-add').onclick = function () {
        const a = Number(body.querySelector('#ex-amt').value);
        if (!(a > 0)) { try { showToast('টাকার পরিমাণ লিখুন'); } catch (e) {} return; }
        ex().unshift({ id: 'exp_' + Date.now(), amount: a, category: pickCat, date: today });
        save(); drawExpense(); try { showToast('৳' + a + ' যোগ হয়েছে'); } catch (e) {}
      };
      body.querySelectorAll('.del').forEach(function (b) { b.onclick = function () { ex().splice(+b.dataset.i, 1); save(); drawExpense(); }; });
    }
    window.showExpenseTrackerModal = function () { drawExpense(); open(); };

    window.__miraPreview = function (path) {
      let html = ''; try { html = A.readSeriousFile(path); } catch (e) {}
      if (!html) { (window.showToast||alert)('Could not read the file'); return; }
      let ov = document.getElementById('mira-preview');
      if (ov) ov.remove();
      ov = document.createElement('div'); ov.id = 'mira-preview';
      ov.style.cssText = 'position:fixed;inset:0;z-index:80;background:#05080d;display:flex;flex-direction:column';
      const bar = document.createElement('div');
      bar.style.cssText = 'display:flex;gap:8px;align-items:center;padding:10px 12px;background:#0a1019;border-bottom:1px solid rgba(255,255,255,.08)';
      const nm = path.split('/').pop();
      bar.innerHTML = '<span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#cbd5e1;font-size:13px">🌐 ' + esc(nm) + '</span>' +
        '<button id="mp-ext" style="padding:7px 12px;border-radius:12px;border:0;background:rgba(255,255,255,.08);color:#e2e8f0;font-size:12px">Open in browser</button>' +
        '<button id="mp-x" style="padding:7px 12px;border-radius:12px;border:0;background:#0891b2;color:#fff;font-size:12px">Close</button>';
      const fr = document.createElement('iframe');
      fr.setAttribute('sandbox', 'allow-scripts allow-forms allow-popups');
      fr.style.cssText = 'flex:1;border:0;background:#fff;width:100%';
      fr.srcdoc = html;
      ov.appendChild(bar); ov.appendChild(fr); document.body.appendChild(ov);
      bar.querySelector('#mp-x').onclick = function () { ov.remove(); };
      bar.querySelector('#mp-ext').onclick = function () { try { A.openSeriousFile(path); } catch (e) {} };
    };


    window.__miraBackup = function (withKeys) {
      const o = {}; try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); } } catch (e) {}
      let r = ''; try { r = A.backupExport(JSON.stringify(o), !!withKeys); } catch (e) { r = 'ERR:' + e; }
      (window.showToast || alert)(r.indexOf('ERR:') === 0 ? 'Backup failed: ' + r.slice(4) : 'Backup saved in Downloads: ' + r.split('/').pop());
      return r;
    };
    // hand a copy of the page's saved data to the app, so the nightly backup can include it
    function pushLocal() {
      try {
        const o = {};
        for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); }
        A.cacheLocal(JSON.stringify(o));
      } catch (e) {}
    }
    setTimeout(pushLocal, 6000);
    setInterval(pushLocal, 120000);
    window.__miraRestore = function () {
      let r = {}; try { r = JSON.parse(A.backupRestore()); } catch (e) { r = { error: String(e) }; }
      if (r.status === 'failed' || r.error) { (window.showToast || alert)('Restore failed: ' + (r.error || '')); return; }
      try { const l = JSON.parse(r.local || '{}'); Object.keys(l).forEach(function (k) { try { localStorage.setItem(k, l[k]); } catch (e) {} }); } catch (e) {}
      (window.showToast || alert)('Restored from ' + String(r.file).split('/').pop() + ' - reloading');
      setTimeout(function () { location.reload(); }, 1400);
    };
    setInterval(function () {
      try {
        const p = A.takeBackupAction();
        if (p === 'backup') window.__miraBackup(false);
        else if (p === 'backup_keys') window.__miraBackup(true);
        else if (p === 'restore') window.__miraRestore();
      } catch (e) {}
    }, 1500);

    window.__miraHistory = function () {
      body.innerHTML = '<h3>📁 Serious mode history</h3><div class="sub">Saved in your Downloads folder · tap a file to open</div><div id="hs-list" style="margin-top:14px"></div>';
      open();
      let list = []; try { list = JSON.parse(A.seriousHistory()); } catch (e) {}
      const box = body.querySelector('#hs-list');
      if (!list.length) { box.innerHTML = '<div class="sub">Nothing saved yet. Say "Mira, serious mode" and give a job.</div>'; return; }
      list.forEach(function (f) {
        const r = document.createElement('div'); r.className = 'row'; r.style.cursor = 'pointer';
        const ic = /\.html?$/i.test(f.name) ? '🌐' : /\.csv$/i.test(f.name) ? '📊' : '📄';
        r.innerHTML = '<span style="min-width:0"><span style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + ic + ' ' + esc(f.name) + '</span><span style="opacity:.5;font-size:11px">' + esc(f.folder) + ' · ' + new Date(f.time).toLocaleString() + ' · ' + Math.max(1, Math.round(f.size / 1024)) + ' KB</span></span><span>›</span>';
        r.onclick = function () { try { if (/\.html?$/i.test(f.name) && window.__miraPreview) { const sh = document.getElementById('mira-sheet'); if (sh) sh.classList.remove('on'); window.__miraPreview(f.path); } else A.openSeriousFile(f.path); } catch (e) {} };
        box.appendChild(r);
      });
    };
    setInterval(function () { try { const p = A.takePreview(); if (p) window.__miraPreview(p); } catch (e) {} }, 1500);
    // voice-logged expenses refresh the sheet if it is open
    const origLog = window.logExpense;
    if (typeof origLog === 'function') window.logExpense = function () { const r = origLog.apply(this, arguments); if (host.classList.contains('on')) drawExpense(); return r; };
  })();
})();
