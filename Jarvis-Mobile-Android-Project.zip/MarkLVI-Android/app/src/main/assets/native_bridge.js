/* Native bridge: runs inside the Mira HUD WebView and swaps the browser-only demo behaviours
   for real Android ones. The Mira page itself (design, 3D head, actions grid) is untouched. */
(function () {
  'use strict';
  if (!window.Android || typeof window.Android.isNative !== 'function') return;
  const A = window.Android;

  // ---- async call plumbing ------------------------------------------------
  const pending = {};
  let seq = 0;
  function reg(fn) { const id = 'c' + (++seq); pending[id] = fn; return id; }
  window.__nativeDone = function (id, payload) {
    const f = pending[id];
    if (f) { delete pending[id]; f(payload); }
  };
  function nativeTool(name, args) {
    return new Promise(function (res) {
      const id = reg(function (p) {
        let o; try { o = JSON.parse(p); } catch (e) { o = { status: 'failed', error: String(p) }; }
        res(o);
      });
      A.tool(id, name, JSON.stringify(args || {}));
    });
  }
  function nativeText(kind, text) {
    return new Promise(function (res, rej) {
      const id = reg(function (p) {
        let o; try { o = JSON.parse(p); } catch (e) { o = { ok: false, text: String(p) }; }
        if (o.ok) res(o.text); else rej(new Error(o.text));
      });
      if (kind === 'chat') A.chat(id, text); else A.ask(id, text);
    });
  }
  window.nativeTool = nativeTool;

  let liveActive = false;
  const toast = function (m) { try { showToast(m); } catch (e) {} };

  // ---- events pushed from the native live session -------------------------
  window.__miraNative = {
    state: function (s) {
      liveActive = !(s === 'IDLE' || s === 'ERROR');
      if (s === 'SPEAKING') {
        avatarState.speaking = true;
        setAvatarStatus('SPEAKING');
      } else {
        avatarState.speaking = false;
        window.__nativeLevel = null;
        if (s === 'LISTENING') {
          isTalkingActive = true; avatarState.listening = true;
          updateTalkSwitchUI();
          setAvatarStatus('LISTENING · SPEAK NOW');
          setLiveMicTranscriptText('🔴 Live — just speak, I am listening', true);
        } else if (s === 'THINKING') {
          setAvatarStatus('THINKING');
        } else if (s === 'CONNECTING') {
          setAvatarStatus('CONNECTING');
        } else {
          isTalkingActive = false; avatarState.listening = false;
          updateTalkSwitchUI();
          setAvatarStatus(s === 'ERROR' ? 'OFFLINE' : 'ACTIVE · READY');
          setLiveMicTranscriptText('Ready — Tap "START TALKING" or Tap Mira Head to speak', false);
        }
      }
    },
    user: function (t, fin) {
      if (fin) { if (t) appendChatMessage('user', t); }
      else setLiveMicTranscriptText('🔴 Heard: "' + t + '"', true);
    },
    asst: function (t, fin) { if (fin && t) appendChatMessage('jarvis', t); },
    level: function (m, s) { window.__nativeLevel = avatarState.speaking ? s : null; },
    info: function (m) { toast(m); },
    heard: function (t) { const e = document.getElementById('native-wake-heard'); if (e) e.textContent = 'Heard: ' + t; },
    wakeState: function (on) { try { window.__wakeUi && window.__wakeUi(!!on); } catch (e) {} },
    error: function (m) { toast('⚠️ ' + m); try { appendChatMessage('sys', '⚠️ ' + m); } catch (e) {} },
    memory: function (cat, key, val) {
      try {
        const text = key.replace(/_/g, ' ') + ': ' + val;
        const emb = computeSemanticVector(text + ' ' + cat);
        memories.unshift({
          id: 'm_' + Date.now(), cat: 'Project', text: text,
          ts: new Date().toISOString().slice(0, 10), vec: Array.from(emb.vec), norm: emb.norm
        });
        persistSqliteDatabase(); renderMemories();
      } catch (e) {}
    },
    ttsDone: function () {
      avatarState.speaking = false;
      if (!liveActive) setAvatarStatus('ACTIVE · READY');
    }
  };

  // ---- voice: native Gemini Live replaces browser SpeechRecognition -------
  window.startTalking = function () {
    if (isTalkingActive) return;
    isTalkingActive = true;
    avatarState.listening = true;
    avatarState.speaking = false;
    updateTalkSwitchUI();
    setAvatarStatus('CONNECTING');
    setLiveMicTranscriptText('🔴 Connecting live voice…', true);
    syncNativeSettings();
    A.liveStart();
  };
  window.stopTalking = function () {
    isTalkingActive = false;
    avatarState.listening = false;
    avatarState.speaking = false;
    window.__nativeLevel = null;
    updateTalkSwitchUI();
    setAvatarStatus('ACTIVE · READY');
    setLiveMicTranscriptText('Ready — Tap "START TALKING" or Tap Mira Head to speak', false);
    A.liveStop();
  };

  // ---- spoken replies for typed chat (device voice) ------------------------
  window.speakJarvisReply = function (text) {
    if (!text || !hudAudioEnabled || liveActive) return;
    const clean = String(text).replace(/[*#`_~]/g, ' ').replace(/\s+/g, ' ').trim();
    if (!clean) return;
    avatarState.speaking = true;
    setAvatarStatus('SPEAKING');
    syncNativeSettings();
    A.speak(clean);
  };

  // ---- typed chat: native agent with every phone tool ----------------------
  const origSend = window.sendChatCommand;
  window.sendChatCommand = async function () {
    const inp = document.getElementById('chat-input');
    const text = ((inp && inp.value) || '').trim();
    if (!text) return;
    if (!A.getApiKey() && !getGeminiApiKey()) return origSend();
    inp.value = '';
    playHudBeep(580, 0.04);
    appendChatMessage('user', text);
    if (liveActive) { A.liveText(text); return; }
    syncNativeSettings();
    setAvatarStatus('THINKING · GEMINI');
    try {
      const reply = await nativeText('chat', text);
      appendChatMessage('jarvis', reply);
      speakJarvisReply(reply);
      if (!avatarState.speaking) setAvatarStatus('ACTIVE · READY');
    } catch (e) {
      appendChatMessage('jarvis', '⚠️ ' + e.message);
      setAvatarStatus('ACTIVE · READY');
    }
  };

  function syncNativeSettings() {
    try { A.syncSettings(getGeminiApiKey() || '', getAssistantName(), getUserName()); } catch (e) {}
  }
  const origSave = window.saveEngineConfig;
  window.saveEngineConfig = function () { origSave(); syncNativeSettings(); };

  // ---- real phone actions ---------------------------------------------------
  function report(title, r) {
    const ok = r && r.status !== 'failed' && r.status !== 'declined';
    appendChatMessage('jarvis', ok ? title + ' — ' + (r.status || 'done') : title + ' — ' + (r.error || r.status));
    return ok;
  }

  const origOpenApp = window.openNativeAndroidApp;
  window.openNativeAndroidApp = function (appKey, q) {
    const app = (typeof ANDROID_APP_SCHEMES !== 'undefined' && ANDROID_APP_SCHEMES[appKey]) || { title: appKey };
    undoStack.push({ title: 'Open Android App: ' + app.title, time: new Date().toLocaleTimeString() });
    updateUndoCounter();
    switchTab('hud');
    let p;
    if (appKey === 'youtube' && q) p = nativeTool('youtube_video', { action: 'search', query: q });
    else if (appKey === 'maps' && q) p = nativeTool('browser_control', { action: 'maps_search', query: q });
    else if (appKey === 'chrome' && q && /^https?:/i.test(q)) p = nativeTool('browser_control', { action: 'open_url', url: q });
    else p = nativeTool('open_app', { app_name: app.title });
    p.then(function (r) {
      if (!report('Opening ' + app.title, r)) origOpenApp(appKey, q);
    });
  };

  const origComms = window.launchAndroidComms;
  window.launchAndroidComms = function (mode, target, msg) {
    const t = (target || '').trim(), m = (msg || '').trim();
    let call = null, title = '';
    if (mode === 'whatsapp_msg' && t && m) { call = ['send_message', { receiver: t, message_text: m, platform: 'whatsapp' }]; title = 'WhatsApp to ' + t; }
    else if (mode === 'sms' && t && m) { call = ['send_message', { receiver: t, message_text: m, platform: 'sms' }]; title = 'SMS to ' + t; }
    else if (mode === 'phone_call' && t) { call = ['make_call', { receiver: t }]; title = 'Call ' + t; }
    if (!call) return origComms(mode, target, msg);
    undoStack.push({ title: title, time: new Date().toLocaleTimeString() });
    updateUndoCounter();
    switchTab('hud');
    nativeTool(call[0], call[1]).then(function (r) {
      if (!report(title, r)) origComms(mode, target, msg);
    });
  };

  window.toggleMobileFlashlight = async function (force) {
    const action = force === true ? 'flashlight_on' : (force === false ? 'flashlight_off' : 'flashlight_toggle');
    const r = await nativeTool('phone_settings', { action: action });
    toast(r.status === 'failed' ? '⚠️ ' + r.error : '🔦 Flashlight ' + (r.flashlight || 'toggled'));
  };

  let soundIdx = 0;
  window.cycleSoundProfile = async function () {
    const modes = [['ringer_normal', '🔔 Normal'], ['ringer_vibrate', '📳 Vibrate'], ['ringer_silent', '🔕 Silent']];
    soundIdx = (soundIdx + 1) % modes.length;
    const r = await nativeTool('phone_settings', { action: modes[soundIdx][0] });
    toast(r.status === 'failed' ? '⚠️ ' + r.error : modes[soundIdx][1]);
    appendChatMessage('jarvis', 'Sound profile: ' + modes[soundIdx][1] + (r.status === 'failed' ? ' (' + r.error + ')' : ''));
  };

  window.startQuickMobileAlarm = async function (seconds, label) {
    const s = seconds || 10;
    const r = await nativeTool('set_alarm_timer', { type: 'timer', seconds: s, label: label || 'Mira' });
    report('Timer ' + s + 's', r);
    toast('⏰ Timer set: ' + s + 's');
  };

  window.triggerPhoneVibration = function () { try { A.vibrate(60); } catch (e) {} };

  window.exportMobileNoteFile = function () {
    const feed = document.getElementById('chat-feed');
    const content = [
      '=== ' + getAssistantName().toUpperCase() + ' MOBILE REPORT ===',
      'Owner: ' + getUserName(),
      'Time: ' + new Date().toLocaleString(),
      '',
      'Stored Memories:'
    ].concat(memories.map(function (m) { return '- [' + m.cat + '] ' + m.text + ' (' + m.ts + ')'; }))
      .concat(['', 'Chat log:', feed ? feed.innerText : '']).join('\n');
    const name = getAssistantName().toLowerCase() + '_report_' + Date.now() + '.txt';
    const path = A.saveNote(name, content);
    appendChatMessage('jarvis', '📥 Saved to: ' + path);
    toast('📥 Saved: ' + name);
  };

  // ---- real hardware telemetry ---------------------------------------------
  window.updateHardwareTelemetry = async function () {
    const clockEl = document.getElementById('clock-txt');
    if (clockEl) clockEl.textContent = new Date().toTimeString().slice(0, 5);
    let s;
    try { s = JSON.parse(A.status()); } catch (e) { return; }
    const set = function (id, v) { const el = document.getElementById(id); if (el) el.textContent = v; };
    const bar = function (id, v) { const el = document.getElementById(id); if (el) el.style.width = Math.max(1, Math.min(100, v)) + '%'; };
    set('tel-cores-val', s.cores + ' Cores');
    set('tel-ram-gb', s.ramGb + ' GB');
    set('tel-heap-mb', 'Heap: ' + s.heapMb + ' MB');
    try { set('tel-frame-ms', smoothedRenderMs.toFixed(1) + ' ms/f'); } catch (e) {}
    set('tel-source-lbl', 'SOURCE: ANDROID NATIVE SENSORS (LIVE)');
    if (s.cpu >= 0) { set('metric-cpu', s.cpu + '%'); bar('bar-cpu', s.cpu); }
    set('metric-ram', s.ram + '%'); bar('bar-ram', s.ram);
    try { renderBatteryUi(s.bat, !!s.charging); } catch (e) {}
  };

  // ---- real notification filter ----------------------------------------------
  const origOpenNotifs = window.openSmartNotificationsModal;
  window.openSmartNotificationsModal = function () {
    if (!A.notificationAccess()) {
      toast('Allow Notification access for Mira, then reopen this');
      A.openNotifAccess();
      return origOpenNotifs();
    }
    try { phoneNotifications = JSON.parse(A.notifications()); } catch (e) {}
    origOpenNotifs();
    const imp = phoneNotifications.filter(function (n) { return n.isImportant; });
    const box = document.getElementById('notif-summary-text');
    if (!phoneNotifications.length) {
      if (box) box.textContent = 'এখনো কোনো নোটিফিকেশন ধরা পড়েনি। নতুন নোটিফিকেশন এলে এখানে দেখা যাবে।';
      return;
    }
    if (box) box.textContent = '…';
    const brief = imp.slice(0, 12).map(function (n) { return n.app + ' / ' + n.sender + ': ' + n.title + ' ' + n.desc; }).join('\n');
    nativeText('ask', 'এই ফোনে মোট ' + phoneNotifications.length + 'টি নোটিফিকেশন, ' + imp.length + 'টি দরকারি। বাংলায় ২টি ছোট বাক্যে সারাংশ দাও, শুধু দরকারিগুলো নিয়ে (ব্যাংক, OTP, পরিবার)। কোনো OTP কোড পড়ে শোনাবে না।\n' + (brief || '(কোনোটিই দরকারি নয়)'))
      .then(function (t) { if (box) box.textContent = t; })
      .catch(function () { if (box) box.textContent = phoneNotifications.length + 'টি নোটিফিকেশনের মধ্যে ' + imp.length + 'টি দরকারি।'; });
  };

  // ---- first-run wiring -----------------------------------------------------------
  function init() {
    try {
      const nk = A.getApiKey();
      if (nk && !localStorage.getItem('mira_gemini_api_key')) {
        localStorage.setItem('mira_gemini_api_key', nk);
        const f = document.getElementById('cfg-gemini-key');
        if (f) f.value = nk;
      }
    } catch (e) {}
    syncNativeSettings();
    try {
      A.importMemories(JSON.stringify(memories.map(function (m) { return { id: m.id, cat: m.cat, text: m.text }; })));
    } catch (e) {}
    const sv = document.getElementById('view-settings');
    if (sv && !document.getElementById('native-perm-card')) {
      const d = document.createElement('div');
      d.id = 'native-perm-card';
      d.className = 'hud-card rounded-3xl p-4 space-y-2';
      d.innerHTML = '<div class="text-xs font-semibold text-white">Phone Control Permissions</div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">Accessibility (taps, typing, screenshots), All files, Display over apps, Notification access, Battery, Exact alarms.</p>' +
        '<button class="w-full py-2.5 rounded-xl btn-minimal text-xs font-semibold" onclick="Android.openNativeSettings()">📱 Open Native Permissions</button>';
      sv.appendChild(d);
    }
    if (sv && !document.getElementById('native-debug-card')) {
      const g = document.createElement('div');
      g.id = 'native-debug-card';
      g.className = 'hud-card rounded-3xl p-4 space-y-2';
      g.innerHTML = '<div class="text-xs font-semibold text-white">Debugger</div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">Live log, last crash report and a one-tap self-test of the API key, voice, live connection, permissions and wake word.</p>' +
        '<button class="w-full py-2.5 rounded-xl btn-minimal text-xs font-semibold" onclick="Android.openDebug()">🛠 Open Debugger</button>';
      sv.appendChild(g);
    }
    if (sv && !document.getElementById('native-model-card')) {
      const m = document.createElement('div');
      m.id = 'native-model-card';
      m.className = 'hud-card rounded-3xl p-4 space-y-2';
      let cur = ''; try { cur = A.getLiveModel(); } catch (e) {}
      m.innerHTML = '<div class="text-xs font-semibold text-white">Live Voice Model</div>' +
        '<select id="native-live-model" class="w-full h-9 px-3 rounded-xl bg-black/50 border border-white/[0.08] text-xs text-white focus:outline-none">' +
        '<option value="">Auto (best available)</option>' +
        '<option value="models/gemini-3.1-flash-live-preview">Gemini 3.1 Flash Live</option>' +
        '<option value="models/gemini-2.5-flash-native-audio-preview-12-2025">Gemini 2.5 Native Audio (Dec 2025)</option>' +
        '<option value="models/gemini-2.5-flash-native-audio-preview-09-2025">Gemini 2.5 Native Audio (Sep 2025)</option></select>';
      sv.appendChild(m);
      const sel = m.querySelector('select');
      sel.value = cur || '';
      sel.onchange = function () { try { A.setLiveModel(sel.value); showToast('Model saved'); } catch (e) {} };
    }
    if (sv && !document.getElementById('native-wake-card')) {
      const w = document.createElement('div');
      w.id = 'native-wake-card';
      w.className = 'hud-card rounded-3xl p-4 space-y-2';
      w.innerHTML = '<div class="flex items-center justify-between gap-3"><div class="min-w-0">' +
        '<div class="text-xs font-semibold text-white">Hey Mira wake word</div>' +
        '<p class="text-[11px] text-slate-400 leading-relaxed">Say "Hey Mira" or "Hey Jarvis" any time, even with the screen locked or on the home screen. Uses the microphone in the background, so it costs some battery. Switch it off when you do not need it.</p></div>' +
        '<button id="native-wake-btn" class="px-4 py-2 rounded-xl btn-minimal text-xs font-semibold flex-shrink-0">OFF</button></div>' +
        '<div id="native-wake-heard" class="mono text-[10px] text-slate-500 truncate">Heard: (switch ON and speak)</div>';
      sv.appendChild(w);
      const btn = w.querySelector('#native-wake-btn');
      let on = false; try { on = A.isWake(); } catch (e) {}
      function paintWake(v) {
        on = v;
        btn.textContent = v ? 'ON' : 'OFF';
        btn.className = 'px-4 py-2 rounded-xl text-xs font-semibold flex-shrink-0 ' + (v ? 'hud-btn-pri' : 'btn-minimal');
      }
      window.__wakeUi = paintWake;
      paintWake(on);
      btn.onclick = function () { paintWake(!on); try { A.setWake(on); } catch (e) {} };
    }
    // ---- one tiny status dot on the hologram: green = ready / listening, red = answering ----
    (function () {
      const holo = document.getElementById('holo-canvas');
      if (!holo || document.getElementById('mira-dot')) return;
      const host = holo.parentNode;
      const d = document.createElement('div');
      d.id = 'mira-dot';
      d.style.cssText = 'position:absolute;top:6px;right:8px;width:11px;height:11px;border-radius:50%;z-index:15;' +
        'background:#34d399;box-shadow:0 0 10px #34d399;transition:background .25s,box-shadow .25s';
      host.appendChild(d);
      let pulse = 0;
      function paint(st) {
        const u = String(st || '').toUpperCase();
        let c = '#34d399';
        if (!u.includes('LISTEN') && (u.includes('SPEAK') || u.includes('THINK') || u.includes('PROCESS') || u.includes('ANSWER'))) c = '#f43f5e';
        d.style.background = c;
        d.style.boxShadow = '0 0 10px ' + c;
        d.style.animation = (u.includes('LISTEN') || c === '#f43f5e') ? 'miraDotPulse 1.1s ease-in-out infinite' : 'none';
      }
      const st = document.createElement('style');
      st.textContent = '@keyframes miraDotPulse{0%,100%{opacity:1}50%{opacity:.35}}';
      document.head.appendChild(st);
      const origStatus = window.setAvatarStatus;
      window.setAvatarStatus = function (s) { try { origStatus(s); } catch (e) {} paint(s); };
      paint(avatarState && avatarState.status);
    })();
    // ---- 8 real Gemini human voices, picked in Settings only ------------------
    const CAT = [
      ['Aoede', 'female', 'Warm, expressive and natural female (Mira default)', 'Hello! I am Mira, speaking with the Aoede voice.', 'আসসালামু আলাইকুম বস, আমি মিরা। আমি আওয়েদে ভয়েসে কথা বলছি।'],
      ['Kore', 'female', 'Crisp, clear and articulate female', 'Greetings! This is the Kore voice, clear and ready.', 'হ্যালো বস, আমি কোরে ভয়েসে কথা বলছি। বলুন, কী করতে পারি?'],
      ['Leda', 'female', 'Gentle, soft and soothing female', 'Hello! This is the Leda voice, calm and listening.', 'হ্যালো বস, আমি লেডা ভয়েসে কথা বলছি। আপনার নির্দেশের অপেক্ষায় আছি।'],
      ['Zephyr', 'female', 'Bright, energetic and lively female', 'Hi there! This is the Zephyr voice, bright and ready to talk.', 'হ্যালো বস! আমি জেফির ভয়েসে কথা বলছি। আজ কী নিয়ে কাজ করব?'],
      ['Charon', 'male', 'Deep, calm and authoritative male', 'All systems are operational. This is the Charon voice.', 'হ্যালো বস, আমি শ্যারন ভয়েসে কথা বলছি। সব সিস্টেম সচল আছে।'],
      ['Puck', 'male', 'Upbeat, friendly and conversational male', 'Hey there! This is the Puck voice, ready to help.', 'হ্যালো বস! আমি পাক ভয়েসে কথা বলছি, যেকোনো কাজের জন্য প্রস্তুত।'],
      ['Fenrir', 'male', 'Strong, resonant and tactical male', 'Standing by. This is the Fenrir voice.', 'হ্যালো বস, আমি ফেনরির ভয়েসে কথা বলছি। সিস্টেম কন্ট্রোল প্রস্তুত।'],
      ['Orus', 'male', 'Calm, steady and balanced male', 'Systems nominal. This is the Orus voice.', 'হ্যালো বস, আমি ওরাস ভয়েসে কথা বলছি। সব মডিউল স্বাভাবিক।']
    ];
    const VM = {};
    CAT.forEach(function (v) {
      VM[v[0]] = { id: v[0], name: v[0], badge: v[0].toUpperCase() + ' · ' + v[1].toUpperCase(), gender: v[1], geminiVoice: v[0],
        pitch: 1, rate: 1, fallbackRate: 1, preferredNames: [], demoEn: v[3], demoBn: v[4], desc: v[2] };
    });
    let curVoice = 'Aoede';
    try { const sv0 = localStorage.getItem('mira_live_voice'); if (sv0 && VM[sv0]) curVoice = sv0; } catch (e) {}
    window.getCurrentVoiceModel = function () { return VM[curVoice]; };
    function applyVoice(name, demo) {
      if (!VM[name]) return;
      curVoice = name;
      try { localStorage.setItem('mira_live_voice', name); } catch (e) {}
      try { A.setVoice(name); } catch (e) {}
      renderVoices();
      if (demo) {
        const bn = /[ঀ-৿]/.test((document.getElementById('chat-input') || {}).value || '') ||
          ((localStorage.getItem('mira_lang') || '') === 'bn');
        syncNativeSettings();
        try { A.demoVoice(name, bn ? VM[name].demoBn : VM[name].demoEn); } catch (e) {}
        showToast('Playing ' + name);
      } else { showToast('Voice saved: ' + name); }
    }
    window.selectAndDemoVoiceModel = function (id, demo) {
      const name = VM[id] ? id : (id === 'female_2' ? 'Kore' : id === 'male_1' ? 'Charon' : 'Aoede');
      applyVoice(name, !!demo);
    };
    function renderVoices() {
      const sel = document.getElementById('cfg-voice-name');
      if (sel) {
        sel.innerHTML = CAT.map(function (v) { return '<option value="' + v[0] + '">' + (v[1] === 'female' ? '👩 ' : '👨 ') + v[0] + ' — ' + v[2] + '</option>'; }).join('');
        sel.value = curVoice;
        sel.onchange = function () { applyVoice(sel.value, true); };
      }
      const pill = document.getElementById('active-voice-pill');
      if (pill) pill.textContent = VM[curVoice].badge;
      const first = document.getElementById('voice-card-female_1');
      let box = document.getElementById('native-voice-grid');
      if (!box && first) {
        box = document.createElement('div');
        box.id = 'native-voice-grid';
        box.className = 'grid grid-cols-1 gap-2';
        first.parentNode.parentNode.insertBefore(box, first.parentNode);
        first.parentNode.style.display = 'none';
      }
      if (box) {
        box.innerHTML = CAT.map(function (v) {
          const on = v[0] === curVoice;
          return '<div class="rounded-2xl p-3 border flex items-center justify-between gap-2 ' +
            (on ? 'bg-cyan-500/15 border-cyan-400/50' : 'bg-white/[0.03] border-white/[0.08]') + '">' +
            '<div class="min-w-0" onclick="selectAndDemoVoiceModel(\'' + v[0] + '\', false)" style="flex:1;cursor:pointer">' +
            '<div class="text-xs font-semibold text-white">' + (v[1] === 'female' ? '👩 ' : '👨 ') + v[0] + (on ? ' ✓' : '') + '</div>' +
            '<div class="text-[10px] text-slate-400">' + v[2] + '</div></div>' +
            '<button class="px-3 py-1.5 rounded-xl hud-btn-pri text-[10px] font-semibold flex-shrink-0" onclick="selectAndDemoVoiceModel(\'' + v[0] + '\', true)">▶ Test</button></div>';
        }).join('');
      }
    }
    renderVoices();
    try { A.setVoice(curVoice); } catch (e) {}
    try { A.pageReady(); } catch (e) {}
  }
  if (document.readyState === 'complete') setTimeout(init, 400);
  else window.addEventListener('load', function () { setTimeout(init, 400); });
})();
